package com.magialuama.horrorverse;

import com.mojang.logging.LogUtils;
import java.util.*;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;

/** Regista dell'universo horror: presenza autonoma delle entità, eventi dell'Osservatore, reazioni e prove. Un giro al secondo per giocatore. */
public final class Director {
    private Director() {}
    private static final Logger LOG = LogUtils.getLogger();
    static final class PS {
        long sec; long nextObs; final long[] nextSight = new long[6]; long nextSign; final List<BlockPos> trail = new ArrayList<>();
        boolean sleeping; int cave; int trial; BlockPos[] traces = new BlockPos[0]; int found; long deadline; BlockPos tower; long lastJump;
    }
    static final Map<UUID, PS> ST = new HashMap<>();

    @SubscribeEvent public static void onTick(ServerTickEvent.Post e) {
        MinecraftServer s = e.getServer();
        if (s.getTickCount() % 20 != 0) return;
        for (ServerPlayer p : new ArrayList<>(s.getPlayerList().getPlayers())) {
            try { tick(p, (ServerLevel) p.level()); } catch (Throwable t) { LOG.warn("HorrorVerse: errore nel direttore", t); }
        }
    }

    private static boolean fightActive(ServerPlayer p, ServerLevel lv) {
        return !lv.getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(100.0), x -> x.mode != HorrorBoss.PRESENCE && p.getUUID().equals(x.focus)).isEmpty();
    }
    private static double rate(ServerPlayer p) { return Config.rate(p); }

    private static void tick(ServerPlayer p, ServerLevel lv) {
        PS st = ST.computeIfAbsent(p.getUUID(), k -> new PS());
        st.sec++;
        if (st.sec % 60 == 0) { Progress.addCtr(p, "min", 1); Progress.updateChapter(p); }
        if (st.sec % 30 == 0) { st.trail.add(p.blockPosition()); if (st.trail.size() > 40) st.trail.remove(0); }
        boolean fight = fightActive(p, lv);
        maintenance(p, lv, st, fight);
        if (!Config.PRESENCE.get() || fight || lv.dimension() != Level.OVERWORLD || Pocket.inside(p) || Progress.flag(p, "corrotto.lost")) return;
        reactions(p, lv, st);
        ambient(p, lv, st);
        spawns(p, lv, st);
        trials(p, lv, st);
    }

    private static void maintenance(ServerPlayer p, ServerLevel lv, PS st, boolean fight) {
        if (p.hasEffect(ModEffects.PIAGA) && st.sec % 2 == 0) Fx.hurt(p, lv.damageSources().magic(), 1.0f);
        if (p.hasEffect(ModEffects.SGUARDO) && st.sec % 3 == 0) Fx.soundTo(p, ModSounds.HEARTBEAT.get(), 0.7f, 1.0f);
        if (!fight && st.sec % 10 == 0) { Fx.cleanItems(p, "hv_locked"); Fx.removeDecoys(p); }
        if (st.sec % 5 == 0 && p.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.ELMO_ANTIVIRUS.get()) && p.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.CORAZZA_ANTIVIRUS.get())
                && p.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.GAMBALI_ANTIVIRUS.get()) && p.getItemBySlot(EquipmentSlot.FEET).is(ModItems.STIVALI_ANTIVIRUS.get())) Fx.grant(p, "armatura_antivirus");
        if (st.sec % 5 == 0 && Progress.flag(p, "oss.calmo") && Progress.flag(p, "steve.truce") && Progress.flag(p, "e404.finale")) Fx.grant(p, "fine_storia");
    }

    // ------------------------------------------------------------ reazioni alle azioni del giocatore
    public static void react(ServerPlayer p, ServerLevel lv, String what) {
        if (!Config.PRESENCE.get() || Progress.chapter(p) < 1 || Progress.minutes(p) < 5 || !Fx.cd(p.getUUID(), "react." + what, p.tickCount, 20 * 600)) return;
        if (p.getRandom().nextFloat() > 0.5f * rate(p)) return;
        switch (what) {
            case "diamond" -> { Fx.sound(lv, p.getX(), p.getY(), p.getZ(), ModSounds.FOOTSTEPS.get(), 0.5f, 0.8f); Fx.bar(p, "Qualcuno ha visto cosa hai trovato."); }
            case "spawner" -> { Fx.soundTo(p, ModSounds.HEARTBEAT.get(), 0.8f, 1.0f); Fx.afflict(p, ModEffects.SGUARDO, 300, 0); }
            case "sleep" -> Fx.say(p, Kind.OSSERVATORE, "Ti ho guardato dormire.");
            default -> { }
        }
    }
    public static void onPlayerDeath(ServerPlayer p, ServerLevel lv) {
        for (HorrorBoss b : lv.getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(100.0)))
            if (b.mode == HorrorBoss.FIGHT && p.getUUID().equals(b.focus) && b.kind == Kind.ENTITY404 && b.lvl() == 3 && b.d == 1) {
                Fx.explode(lv, b, p.getX(), p.getY(), p.getZ(), 3.0f);
                Fx.info(p, ChatFormatting.GREEN, "Hai perso la sfida: a casa tua senti un'esplosione lontana (solo narrativa, nessun blocco danneggiato).");
            }
        if (Config.PRESENCE.get() && Fx.cd(p.getUUID(), "react.death", p.tickCount, 20 * 300)) lv.getServer().execute(() -> Fx.say(p, Kind.OSSERVATORE, "Era prevedibile."));
    }
    private static void reactions(ServerPlayer p, ServerLevel lv, PS st) {
        boolean sl = p.isSleeping();
        if (!sl && st.sleeping) react(p, lv, "sleep");
        st.sleeping = sl;
        if (p.getY() < 0.0) st.cave++; else st.cave = 0;
        if (st.cave > 0 && st.cave % 240 == 0 && p.getRandom().nextFloat() < 0.6f * rate(p)) { Fx.soundTo(p, ModSounds.HEARTBEAT.get(), 0.6f, 0.9f); Fx.sound(lv, p.getX() - 2, p.getY(), p.getZ() - 2, ModSounds.FOOTSTEPS.get(), 0.3f, 1.0f); }
        if (st.sec % 5 == 0 && p.getY() < 50.0) {
            BlockPos o = p.blockPosition();
            for (BlockPos q : BlockPos.betweenClosed(o.offset(-4, -3, -4), o.offset(4, 3, 4))) if (lv.getBlockState(q).is(Blocks.SPAWNER)) { react(p, lv, "spawner"); break; }
        }
    }

    // ------------------------------------------------------------ eventi ambientali (l'Osservatore tormenta per divertimento)
    private static void ambient(ServerPlayer p, ServerLevel lv, PS st) {
        if (Progress.minutes(p) < 3) return;
        if (st.nextObs == 0) st.nextObs = st.sec + 60 + p.getRandom().nextInt(120);
        if (st.sec < st.nextObs) return;
        double calm = Progress.flag(p, "oss.calmo") ? 3.0 : 1.0;
        st.nextObs = st.sec + (long) ((60 + p.getRandom().nextInt(180)) * calm / rate(p));
        double x = p.getX(), y = p.getY(), z = p.getZ();
        Vec3 back = p.getLookAngle().multiply(-1.0, 0.0, -1.0).normalize().scale(3.0);
        switch (p.getRandom().nextInt(10)) {
            case 0 -> Fx.sound(lv, x + back.x, y, z + back.z, ModSounds.FOOTSTEPS.get(), 0.7f, 1.0f);
            case 1 -> Fx.sound(lv, x + 4, y, z - 3, ModSounds.DOOR_CREAK.get(), 0.8f, 1.0f);
            case 2 -> Fx.sound(lv, x - 5, y, z + 4, SoundEvents.CREEPER_PRIMED, 0.8f, 1.0f);
            case 3 -> Fx.soundTo(p, ModSounds.THUNDER_FAR.get(), 0.8f, 1.0f);
            case 4 -> { Fx.soundTo(p, ModSounds.HEARTBEAT.get(), 0.9f, 1.0f); Fx.afflict(p, ModEffects.SGUARDO, 300, 0); }
            case 5 -> { if (Config.SHAKE.get() && !Progress.flag(p, "noshake")) Fx.afflict(p, MobEffects.DARKNESS, 140, 0); Fx.soundTo(p, ModSounds.DRONE_LOW.get(), 0.6f, 1.0f); }
            case 6 -> p.sendSystemMessage(Component.translatable("multiplayer.player.joined", Component.literal(new String[]{"Osservatore", "Steve", "404"}[p.getRandom().nextInt(3)])).withStyle(ChatFormatting.YELLOW));
            case 7 -> { Fx.soundTo(p, new SoundPick().get(p), 0.6f, 1.0f); Fx.bar(p, new String[]{"Non sono io che sono arrivato.", "Sei tu che sei entrato.", "...", "Ti ho visto."}[p.getRandom().nextInt(4)]); }
            case 8 -> spawnPresence(p, lv, Kind.OSSERVATORE);
            default -> jumpscare(p, lv, st);
        }
    }
    private static final class SoundPick { net.minecraft.sounds.SoundEvent get(ServerPlayer p) { return switch (p.getRandom().nextInt(3)) { case 0 -> ModSounds.WHISPER_A.get(); case 1 -> ModSounds.WHISPER_B.get(); default -> ModSounds.WHISPER_C.get(); }; } }

    private static void jumpscare(ServerPlayer p, ServerLevel lv, PS st) {
        if (!Config.JUMPSCARE.get() || Progress.flag(p, "nojump") || Config.profile(p) == 0 || Progress.minutes(p) < 30) return;
        if (st.sec - st.lastJump < Config.JUMPSCARE_COOLDOWN_MINUTES.get() * 60L) return;
        st.lastJump = st.sec;
        Fx.soundTo(p, ModSounds.JUMPSCARE.get(), 1.0f, 1.0f);
        Fx.title(p, "▌▌▌", "");
        if (Config.SHAKE.get() && !Progress.flag(p, "noshake")) { Fx.afflict(p, MobEffects.NAUSEA, 80, 0); Fx.afflict(p, MobEffects.DARKNESS, 60, 0); }
        Fx.grant(p, "jumpscare");
    }

    // ------------------------------------------------------------ apparizioni delle entità (ordine narrativo)
    private static void spawns(ServerPlayer p, ServerLevel lv, PS st) {
        int ch = Progress.chapter(p);
        // anticipazioni di Entity 404: numeri verdi e piccoli segni, prima della sua vera introduzione
        if (ch >= 2 && ch < 5 && st.sec > 600) {
            if (st.nextSign == 0) st.nextSign = st.sec + 600 + p.getRandom().nextInt(900);
            if (st.sec >= st.nextSign) {
                st.nextSign = st.sec + (long) ((900 + p.getRandom().nextInt(900)) / rate(p));
                Fx.info(p, ChatFormatting.GREEN, String.valueOf(400 + p.getRandom().nextInt(10)) + " " + (100 + p.getRandom().nextInt(900)));
                Fx.sound(lv, p.getX(), p.getY(), p.getZ(), ModSounds.GLITCH.get(), 0.4f, 1.0f);
                if (p.getRandom().nextInt(3) == 0) swapHotbar(p);
                Lore.unlock(p, "e404.1");
            }
        }
        for (Kind k : Kind.values()) {
            if (k == Kind.OSSERVATORE) continue;                                  // gestito da ambient()
            if (Config.NARRATIVE_ORDER.get() && ch < k.chapter) continue;
            if (k == Kind.CUSTODE && Progress.flag(p, "custode.dead")) continue;
            long due = st.nextSight[k.ordinal()];
            if (due == 0) { st.nextSight[k.ordinal()] = st.sec + 90 + p.getRandom().nextInt(240); continue; }
            if (st.sec < due) continue;
            double mult = (k == Kind.CUSTODE && Progress.flag(p, "custode.spared")) ? 3.0 : 1.0;
            long min = Config.PRESENCE_MIN_MINUTES.get() * 60L, max = Math.max(min + 60, Config.PRESENCE_MAX_MINUTES.get() * 60L);
            st.nextSight[k.ordinal()] = st.sec + (long) ((min + p.getRandom().nextInt((int) (max - min))) * mult / rate(p));
            if ((k == Kind.CUSTODE || k == Kind.ENTITY404) && !Fx.isNight(lv) && p.getRandom().nextFloat() > 0.25f) { st.nextSight[k.ordinal()] = st.sec + 120; continue; }
            spawnPresence(p, lv, k);
        }
    }
    static void spawnPresence(ServerPlayer p, ServerLevel lv, Kind k) {
        if (!lv.getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(120.0), x -> x.kind == k).isEmpty()) return;
        for (int i = 0; i < 12; i++) {
            Vec3 v = Fx.ring(lv, p.position(), 22.0, 38.0);
            BlockPos bp = BlockPos.containing(v.x, v.y, v.z);
            if (!lv.getFluidState(bp).isEmpty() || lv.getBlockState(bp.below()).isAir() || !lv.getBlockState(bp).isAir()) continue;
            HorrorBoss b = Fx.spawn(lv, ModEntities.of(k), v.x, v.y, v.z);
            if (b == null) return;
            b.setLvl(Brains.nextLevel(p, k));
            if (k == Kind.OSSERVATORE || k == Kind.ENTITY404 || k == Kind.CUSTODE || k == Kind.MAGO) b.setNoAi(true);
            Fx.particles(lv, ParticleTypes.SMOKE, v.x, v.y + 1, v.z, 20, 0.3, 0.8, 0.3, 0.02);
            return;
        }
    }
    private static void swapHotbar(ServerPlayer p) {
        int a = p.getRandom().nextInt(9), b = p.getRandom().nextInt(9);
        if (a == b) return;
        ItemStack x = p.getInventory().getItem(a), y = p.getInventory().getItem(b);
        if (x.isEmpty() && y.isEmpty()) return;
        p.getInventory().setItem(a, y); p.getInventory().setItem(b, x);
        Fx.bar(p, "Hai l'impressione che qualcosa nel tuo zaino sia cambiato.");
    }

    // ------------------------------------------------------------ prove dell'Osservatore (attenzione e osservazione)
    private static BlockPos surface(ServerLevel lv, BlockPos q) {
        return new BlockPos(q.getX(), lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, q.getX(), q.getZ()), q.getZ());
    }
    private static void trials(ServerPlayer p, ServerLevel lv, PS st) {
        int sights = Progress.ctr(p, "sight.osservatore");
        if (st.trial == 0) {
            if (!Progress.flag(p, "oss.t1") && sights >= 3 && st.trail.size() >= 8) {
                List<BlockPos> far = new ArrayList<>();
                for (BlockPos q : st.trail) if (q.distSqr(p.blockPosition()) > 625 && lv.hasChunkAt(q)) far.add(q);
                if (far.size() < 3) return;
                Collections.shuffle(far);
                st.traces = new BlockPos[3];
                for (int i = 0; i < 3; i++) { BlockPos s = surface(lv, far.get(i)); st.traces[i] = s; lv.setBlock(s, ModBlocks.TRACCIA_OSSERVATORE.get().defaultBlockState(), 3); }
                st.found = 0; st.trial = 1;
                Fx.say(p, Kind.OSSERVATORE, "Ricordo tre dei tuoi passi. Trovali: " + hint(p, st.traces) + ".");
            } else if (Progress.flag(p, "oss.t1") && !Progress.flag(p, "oss.t2") && sights >= 5 && st.trail.size() >= 8) {
                BlockPos far = null;
                for (BlockPos q : st.trail) if (q.distSqr(p.blockPosition()) > 1600 && lv.hasChunkAt(q)) far = q;
                if (far == null) return;
                BlockPos s = surface(lv, far); st.traces = new BlockPos[]{s}; lv.setBlock(s, ModBlocks.OCCHIO_OSSERVATORE.get().defaultBlockState(), 3);
                st.trial = 2; st.deadline = st.sec + 180;
                Fx.say(p, Kind.OSSERVATORE, "Un evento sta per compiersi, " + hint(p, st.traces) + ". Interrompilo prima che finisca. Hai tre minuti.");
            } else if (Progress.flag(p, "oss.t2") && !Progress.flag(p, "oss.t3") && sights >= 7) {
                Vec3 v = Fx.ring(lv, p.position(), 50.0, 70.0);
                BlockPos o = BlockPos.containing(v.x, v.y, v.z);
                if (!lv.hasChunkAt(o)) return;
                Structures.build(lv, o, 4, p.getRandom());
                st.tower = o.above(15); st.trial = 3;
                Fx.say(p, Kind.OSSERVATORE, "C'è un posto da cui vedo tutto: " + hint(p, new BlockPos[]{o}) + ". Salici.");
            }
        } else if (st.trial == 2 && st.sec > st.deadline) {
            if (st.traces.length > 0 && lv.getBlockState(st.traces[0]).is(ModBlocks.OCCHIO_OSSERVATORE.get())) lv.removeBlock(st.traces[0], false);
            st.trial = 0; st.traces = new BlockPos[0];
            Fx.soundTo(p, ModSounds.HEARTBEAT.get(), 1.0f, 0.8f); Fx.afflict(p, MobEffects.DARKNESS, 200, 0);
            Fx.say(p, Kind.OSSERVATORE, "Troppo tardi. Ci riproveremo.");
        } else if (st.trial == 3 && st.tower != null && p.distanceToSqr(st.tower.getX(), st.tower.getY(), st.tower.getZ()) < 25.0) {
            Progress.setFlag(p, "oss.t3", true); Progress.setFlag(p, "oss.calmo", true); st.trial = 0;
            Lore.unlock(p, "oss.5"); Fx.grant(p, "osservatore_torre");
            Fx.say(p, Kind.OSSERVATORE, "Sei arrivato fin qui. Divertente. Per un po' ti lascerò in pace.");
        }
    }
    private static String hint(ServerPlayer p, BlockPos[] ps) {
        StringBuilder sb = new StringBuilder();
        for (BlockPos q : ps) {
            double dx = q.getX() - p.getX(), dz = q.getZ() - p.getZ();
            sb.append(Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? "est" : "ovest") : (dz > 0 ? "sud" : "nord")).append(" (~").append((int) Math.sqrt(dx * dx + dz * dz)).append(" blocchi); ");
        }
        return sb.toString();
    }
    public static void traceBroken(ServerPlayer p, ServerLevel lv, BlockPos pos, BlockState state) {
        PS st = ST.get(p.getUUID());
        if (st == null) return;
        for (BlockPos q : st.traces) if (q.equals(pos)) {
            if (st.trial == 1 && state.is(ModBlocks.TRACCIA_OSSERVATORE.get())) {
                st.found++; Fx.bar(p, "Traccia " + st.found + "/3"); Fx.sound(lv, p.getX(), p.getY(), p.getZ(), ModSounds.FOOTSTEPS.get(), 0.5f, 0.7f);
                if (st.found >= 3) { Progress.setFlag(p, "oss.t1", true); st.trial = 0; Lore.unlock(p, "oss.4"); Fx.grant(p, "osservatore_tracce"); Fx.say(p, Kind.OSSERVATORE, "Hai seguito le tue stesse orme."); }
            } else if (st.trial == 2 && state.is(ModBlocks.OCCHIO_OSSERVATORE.get())) {
                Progress.setFlag(p, "oss.t2", true); st.trial = 0; Fx.grant(p, "osservatore_interrotto");
                Fx.say(p, Kind.OSSERVATORE, "Hai interrotto qualcosa che non capisci. Non è finita.");
            }
        }
    }
}
