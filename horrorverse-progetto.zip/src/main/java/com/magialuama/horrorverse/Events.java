package com.magialuama.horrorverse;

import java.util.*;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;

/** Eventi di gioco del mod (danni, morti, chat, oggetti, blocchi). */
public final class Events {
    private Events() {}
    /** perle valide lanciate e non ancora risolte: {conteggio, tick} */
    static final Map<UUID, int[]> PEARLS = new HashMap<>();

    // ---------------------------------------------------------------- danni
    @SubscribeEvent public static void onDamage(LivingIncomingDamageEvent e) {
        LivingEntity t = e.getEntity();
        if (t.level().isClientSide()) return;
        if (t instanceof HorrorBoss b) { Vuln.boss(e, b); return; }
        if (t instanceof Minion m) { Vuln.minion(e, m); return; }
        if (t instanceof ServerPlayer p) {
            if (p.hasEffect(ModEffects.CORRUZIONE)) e.setAmount(e.getAmount() * 1.5f);        // cuori corrotti
            if (p.hasEffect(ModEffects.SCUDO_EDEN) && e.getSource().getEntity() instanceof HorrorBoss) e.setAmount(e.getAmount() * 0.8f);
        }
    }

    @SubscribeEvent public static void onDeath(LivingDeathEvent e) {
        LivingEntity t = e.getEntity();
        if (t.level().isClientSide()) return;
        ServerLevel lv = (ServerLevel) t.level();
        if (t instanceof Minion m) {
            for (String part : m.type.drops.split(";")) {
                if (part.isEmpty()) continue;
                String[] a = part.split(":");
                if (m.getRandom().nextFloat() > Float.parseFloat(a[1]) * (1.0f + 0.0f)) continue;
                int n = Integer.parseInt(a[2]) + m.getRandom().nextInt(Integer.parseInt(a[3]) - Integer.parseInt(a[2]) + 1);
                var d = Reg.BY_ID.get(a[0]);
                if (d != null) Containers.dropItemStack(lv, m.getX(), m.getY() + 0.5, m.getZ(), new ItemStack(d.get(), n));
            }
        } else if (t instanceof ServerPlayer p) Director.onPlayerDeath(p, lv);
    }

    // ---------------------------------------------------------------- uscita dal mondo
    @SubscribeEvent public static void onLeave(EntityLeaveLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        if (e.getEntity() instanceof HorrorBoss b && b.level() instanceof ServerLevel lv) { try { b.cleanup(lv); } catch (Throwable ignored) { } }
    }

    // ---------------------------------------------------------------- giocatore
    @SubscribeEvent public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        Fx.grant(p, "radice");
        if (!Progress.flag(p, "diario")) { Progress.setFlag(p, "diario", true); Rewards.give(p, "diario_mondo", 1); Fx.info(p, ChatFormatting.GOLD, "Un diario è apparso nel tuo inventario. Non ricordi di averlo preso."); }
        int now = (int) (System.currentTimeMillis() / 60000L), last = Progress.ctr(p, "lastseen");
        if (last > 0 && now - last > 60 * 24 * 2 && Config.PRESENCE.get()) {
            ServerLevel lv = (ServerLevel) p.level();
            lv.getServer().execute(() -> { Fx.sound(lv, p.getX(), p.getY(), p.getZ(), ModSounds.HEARTBEAT.get(), 0.6f, 0.9f); Fx.say(p, Kind.OSSERVATORE, "Bentornato. Ti stavo aspettando."); });
        }
        Progress.setCtr(p, "lastseen", now);
    }
    @SubscribeEvent public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) { Progress.setCtr(p, "lastseen", (int) (System.currentTimeMillis() / 60000L)); Fx.removeDecoys(p); Fx.cleanItems(p, "hv_locked"); }
    }
    @SubscribeEvent public static void onClone(PlayerEvent.Clone e) { Progress.copy(e.getOriginal(), e.getEntity()); }

    // ---------------------------------------------------------------- chat
    private static final String[] NEG = {"stupido", "muori", "mostro", "odio", "schifo", "brutto", "vattene", "idiota", "ti uccido"};
    private static final String[] POS = {"amico", "grazie", "scusa", "ti voglio bene", "bravo", "gentile", "perdon", "benvenuto"};
    private static final String[][] CAT = {
        {"capisco", "soffri", "ferito", "dolore", "non è colpa tua", "non e colpa tua"},
        {"scusa", "mi dispiace", "perdono", "perdonami"},
        {"vendetta non serve", "non serve", "smettila", "un altro modo", "pace", "fermati", "non porta"},
        {"non sei solo", "ti aiuto", "insieme", "resto", "ti ascolto", "amico"}};

    @SubscribeEvent public static void onChat(ServerChatEvent e) {
        ServerPlayer p = e.getPlayer();
        String msg = e.getRawText().toLowerCase(Locale.ROOT);
        p.level().getServer().execute(() -> chat(p, msg));
    }
    private static void chat(ServerPlayer p, String msg) {
        ServerLevel lv = (ServerLevel) p.level();
        for (HorrorBoss b : lv.getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(40.0))) {
            if (b.kind == Kind.CUSTODE && b.mode == HorrorBoss.CHOICE) {
                if (msg.contains("risparmia")) Brains.choose(b, lv, p, true);
                else if (msg.contains("uccidi")) Brains.choose(b, lv, p, false);
            } else if (b.kind == Kind.CORROTTO && b.mode == HorrorBoss.PRESENCE) {
                int d = 0;
                for (String w : NEG) if (msg.contains(w)) d -= 12;
                for (String w : POS) if (msg.contains(w)) d += 8;
                if (d != 0) { Brains.setTrust(p, Brains.trust(p) + d); b.say(p, d > 0 ? "Grazie... davvero." : "Non dire così, ti prego."); }
            } else if (b.kind == Kind.ENTITY404 && b.mode == HorrorBoss.FIGHT && b.lvl() == 6 && b.d == 1) dialogue(b, lv, p, msg);
        }
    }
    private static void dialogue(HorrorBoss b, ServerLevel lv, ServerPlayer p, String msg) {
        Minion clone = null;
        for (Minion m : lv.getEntitiesOfClass(Minion.class, b.getBoundingBox().inflate(60.0))) if (m.type == MinionType.CLONE_VENDICATIVO) clone = m;
        if (clone == null) return;
        for (String w : NEG) if (msg.contains(w)) { b.c = Math.max(0, b.c - 30); Fx.info(p, ChatFormatting.GREEN, "<Clone> Anche tu. Come tutti."); return; }
        if (msg.length() < 15) { Fx.info(p, ChatFormatting.GREEN, "<Clone> Una parola non basta."); return; }
        int mask = b.mem.getOrDefault("cat", 0), gained = 0;
        for (int i = 0; i < CAT.length; i++) {
            if ((mask & (1 << i)) != 0) continue;
            for (String w : CAT[i]) if (msg.contains(w)) { mask |= 1 << i; gained++; break; }
        }
        b.mem.put("cat", mask);
        b.c = Math.min(100, b.c + gained * 25);
        if (gained == 0) { Fx.info(p, ChatFormatting.GREEN, "<Clone> Non basta. Dimmi che capisci, che ti dispiace, che esiste un altro modo, che non sono solo."); return; }
        Fx.info(p, ChatFormatting.GREEN, "<Clone> ... continua. (" + b.c + "%)");
        if (b.c >= 100 && Config.ALLIANCES.get()) {
            Progress.setFlag(p, "clone.ally", true);
            Fx.info(p, ChatFormatting.GREEN, "<Clone> Forse hai ragione. La vendetta non ha ridato niente a nessuno. Combatterò con te.");
            Fx.grant(p, "e404_clone_alleato");
            Rewards.give(p, "nucleo_corrotto", 1);
            clone.discard();
        }
    }

    // ---------------------------------------------------------------- interazioni
    @SubscribeEvent public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer p)) return;
        ServerLevel lv = (ServerLevel) p.level();
        Entity t = e.getTarget(); ItemStack s = e.getItemStack();
        if (t instanceof HorrorBoss b) {
            if (b.kind == Kind.CUSTODE && b.mode == HorrorBoss.FIGHT && b.lvl() == 2 && p.distanceToSqr(b) < 16.0) Fights.touch(b, p);
            else if (b.kind == Kind.CORROTTO && b.mode == HorrorBoss.PRESENCE) {
                boolean ok = s.has(DataComponents.FOOD) || s.is(Fx.FLOWERS);
                if (!ok) { b.say(p, "Grazie per essere qui."); return; }
                s.shrink(1); Brains.setTrust(p, Brains.trust(p) + 15);
                Fx.particles(lv, ParticleTypes.HAPPY_VILLAGER, b.getX(), b.getY() + 1.5, b.getZ(), 10, 0.4, 0.4, 0.4, 0.0);
                b.say(p, "Per me? Che gentile..."); Fx.grant(p, "corrotto_amico");
            } else if (b.kind == Kind.STEVE) {
                if (b.mode == HorrorBoss.FIGHT) Fights.stevePay(b, p, s);
                else if (!s.isEmpty() && Fx.cd(p.getUUID(), "trade", p.tickCount, 1200)) {
                    s.shrink(1);
                    ItemStack give = switch (b.getRandom().nextInt(4)) { case 0 -> new ItemStack(Items.BREAD, 3); case 1 -> new ItemStack(Items.TORCH, 6); case 2 -> new ItemStack(Items.ARROW, 8); default -> new ItemStack(Items.COOKED_BEEF, 2); };
                    Fx.give(p, give); b.say(p, "Uno scambio onesto."); Fx.grant(p, "steve_scambio");
                    if (Progress.addCtr(p, "meet.steve", 1) >= 2) Lore.unlock(p, "ste.2");
                }
            } else if (b.kind == Kind.MAGO && b.mode == HorrorBoss.PRESENCE && s.is(Items.GOLD_INGOT) && s.getCount() >= 3) {
                s.shrink(3); Rewards.give(p, "runa_antica", 1); Progress.setFlag(p, "mago.pact", true);
                b.say(p, "Un patto. L'oro è sempre un buon inizio."); Fx.grant(p, "mago_patto");
            }
            return;
        }
        if (t.getType() == EntityTypes.ENDERMAN && s.is(ModItems.PERLA_RITUALE.get())) ritual(p, lv, t, s);
    }
    private static void ritual(ServerPlayer p, ServerLevel lv, Entity en, ItemStack s) {
        if (Progress.level(p, Kind.CUSTODE) < 3) { Fx.bar(p, "Non sai ancora cosa stai facendo..."); return; }
        if (Progress.flag(p, "custode.dead")) { Fx.info(p, ChatFormatting.GRAY, "Il rituale si dissolve: non c'è più nessuno a cui appartenga."); return; }
        if (!Brains.canFight(p, lv, Kind.CUSTODE)) { Fx.bar(p, "Il rituale non risponde (difficoltà Pacifica o pausa dopo uno scontro)."); return; }
        s.shrink(1); en.discard();
        Fx.particles(lv, ParticleTypes.PORTAL, en.getX(), en.getY() + 1, en.getZ(), 80, 0.6, 1.2, 0.6, 0.6);
        HorrorBoss b = Fx.spawn(lv, ModEntities.CUSTODE.get(), en.getX(), en.getY(), en.getZ());
        if (b != null) { b.setLvl(5); b.startFight(p, lv); }
    }

    @SubscribeEvent public static void onUse(PlayerInteractEvent.RightClickItem e) {
        if (e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getItemStack(); ServerLevel lv = (ServerLevel) p.level(); Item it = s.getItem();
        if (blocked(p, s)) { e.setCanceled(true); return; }
        if (it == Items.ENDER_PEARL && Fx.marked(s, "hv_pearl")) { PEARLS.merge(p.getUUID(), new int[]{1, p.tickCount}, (o, n) -> new int[]{o[0] + 1, p.tickCount}); return; }
        if (it == ModItems.SCETTRO_ELETTRICO.get() && Fx.cd(p.getUUID(), "scettro", p.tickCount, 40)) {
            Vec3 hit = p.pick(30.0, 0.0f, false).getLocation();
            Fx.bolt(lv, hit.x, hit.y, hit.z);
            for (LivingEntity v : lv.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(hit, hit).inflate(3.0), x -> x != p && !(x instanceof HorrorBoss))) Fx.hurt(v, lv.damageSources().lightningBolt(), 6.0f);
        } else if (it == ModItems.BASTONE_MAGO.get() && Fx.cd(p.getUUID(), "bastone", p.tickCount, 20)) {
            Vec3 a = p.getEyePosition(), dir = p.getLookAngle();
            Fx.beam(lv, a, a.add(dir.scale(20.0)), ParticleTypes.WITCH);
            for (int i = 1; i < 20; i++) {
                Vec3 q = a.add(dir.scale(i));
                List<LivingEntity> hit = lv.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(q, q).inflate(0.7), x -> x != p && !(x instanceof HorrorBoss));
                if (!hit.isEmpty()) { Fx.hurt(hit.get(0), lv.damageSources().magic(), 7.0f); break; }
            }
        } else if (it == ModItems.ARTEFATTO_ANTIOSCURITA.get()) {
            boolean used = false;
            for (HorrorBoss b : lv.getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(14.0)))
                if (b.kind == Kind.CORROTTO && b.mode == HorrorBoss.FIGHT && b.lvl() >= 3) { Fights.artifact(b, lv, p); used = true; }
            if (!used) { Fx.purify(p); Fx.bar(p, "L'artefatto pulsa e si spegne: qui non c'è oscurità da contrastare."); }
            else s.shrink(1);
            Fx.grant(p, "corrotto_purificato");
        } else if (it == ModItems.CRISTALLO_PURIFICAZIONE.get()) {
            Fx.purify(p); s.shrink(1); Fx.bar(p, "Sei stato purificato."); Fx.grant(p, "corrotto_purificato");
            Fx.particles(lv, ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 40, 0.5, 1, 0.5, 0.1);
        } else if (it == ModItems.FIALA_CONTENIMENTO.get()) {
            p.removeEffect(ModEffects.PIAGA);
            for (HorrorBoss b : lv.getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(40.0)))
                if (b.kind == Kind.ENTITY404 && b.mode == HorrorBoss.FIGHT && b.lvl() == 3) { b.a = Math.max(0, b.a - 5); b.say(p, "La piaga... rallenta?!"); }
            for (Minion m : lv.getEntitiesOfClass(Minion.class, p.getBoundingBox().inflate(10.0))) if (m.type == MinionType.ZOMBIE_VERDE) m.discard();
            s.shrink(1); Fx.bar(p, "La piaga è contenuta, per ora.");
        } else if (it == ModItems.CHIAVE_DIMENSIONE.get() && Config.POCKET.get() && Fx.cd(p.getUUID(), "chiave", p.tickCount, 200)) Pocket.enter(p, lv);
        else if (it == ModItems.DIARIO_MONDO.get() && Fx.cd(p.getUUID(), "diario", p.tickCount, 20)) Lore.diary(p);
    }
    private static boolean blocked(ServerPlayer p, ItemStack s) {
        if (Fx.marked(s, "hv_locked")) { Fx.bar(p, "L'oggetto è stato sottratto dall'oscurità (bloccato fino alla fine dello scontro)."); return true; }
        if (Fx.marked(s, "hv_corrupt")) { Fx.bar(p, "L'oggetto è corrotto: usa un Cristallo di Purificazione."); return true; }
        return false;
    }
    @SubscribeEvent public static void onUseBlock(PlayerInteractEvent.RightClickBlock e) {
        if (e.getEntity() instanceof ServerPlayer p && blocked(p, e.getItemStack())) e.setCanceled(true);
    }
    @SubscribeEvent public static void onAttack(AttackEntityEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = p.getMainHandItem();
        if (blocked(p, s) || (p.hasEffect(ModEffects.MALEDIZIONE_RUNICA) && s.is(ItemTags.SWORDS))) e.setCanceled(true);
    }

    @SubscribeEvent public static void onEat(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.level().isClientSide()) return;
        Item it = e.getItem().getItem();
        if (it == ModItems.FRUTTO_EDEN.get()) { p.addEffect(new MobEffectInstance(ModEffects.SCUDO_EDEN, 6000, 0)); p.removeEffect(ModEffects.CORRUZIONE); p.removeEffect(ModEffects.PIAGA); Fx.grant(p, "frutto_eden"); }
        else if (it == ModItems.MELA_OSCURA.get()) {
            Fx.afflict(p, ModEffects.CORRUZIONE, 1200, 0);
            for (HorrorBoss b : ((ServerLevel) p.level()).getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(40.0))) if (b.kind == Kind.CORROTTO && b.mode == HorrorBoss.FIGHT) b.c += 25;
        }
        else if (it == ModItems.CARNE_VERDE.get()) { Fx.afflict(p, MobEffects.POISON, 200, 0); Fx.afflict(p, MobEffects.HUNGER, 300, 0); }
        else if (it == ModItems.PANE_PALLIDO.get()) p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
        else if (it == ModItems.ZUPPA_OMBRA.get()) p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0));
        else if (it == ModItems.BACCHE_SPETTRALI.get()) p.addEffect(new MobEffectInstance(MobEffects.SPEED, 400, 0));
        else if (it == ModItems.BISCOTTO_RUNICO.get()) p.addEffect(new MobEffectInstance(MobEffects.JUMP_BOOST, 600, 1));
    }

    @SubscribeEvent public static void onProjectile(ProjectileImpactEvent e) {
        Projectile pr = e.getProjectile();
        if (pr.level().isClientSide() || pr.getType() != EntityTypes.ENDER_PEARL) return;
        HitResult r = e.getRayTraceResult();
        if (!(r instanceof EntityHitResult hit) || !(hit.getEntity() instanceof HorrorBoss b)) return;
        if (b.kind != Kind.CUSTODE || b.lvl() != 5 || b.mode != HorrorBoss.FIGHT || !(pr.getOwner() instanceof ServerPlayer p)) return;
        e.setCanceled(true); pr.discard();
        int[] pend = PEARLS.get(p.getUUID());
        if (b.a == 2 && pend != null && pend[0] > 0 && p.tickCount - pend[1] < 400) { pend[0]--; Fights.pearlHit(b, (ServerLevel) p.level(), p); }
        else Fx.bar(p, "Perla non valida: usa una perla del Custode mentre è fermo.");
    }

    // ---------------------------------------------------------------- blocchi
    @SubscribeEvent public static void onBreak(BreakBlockEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p) || p.level().isClientSide()) return;
        ServerLevel lv = (ServerLevel) p.level(); BlockState st = e.getState(); BlockPos pos = e.getPos();
        if (blocked(p, p.getMainHandItem())) { e.setCanceled(true); return; }
        if (st.is(ModBlocks.RUNA_PILASTRO.get()) || st.is(ModBlocks.GENERATORE_ARCANO.get()) || st.is(ModBlocks.PIEDISTALLO_BASTONE.get()) || st.is(Blocks.CHEST)) {
            for (HorrorBoss b : lv.getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(80.0))) {
                if (b.mode != HorrorBoss.FIGHT) continue;
                if (st.is(ModBlocks.PIEDISTALLO_BASTONE.get()) && b.marks.contains(pos)) Fights.pedestalBroken(b, lv, p);
                else if (!st.is(Blocks.CHEST) && b.marks.contains(pos)) Fights.runeBroken(b, lv, p, pos);
                else if (st.is(Blocks.CHEST) && b.depots.contains(pos)) lv.getServer().execute(() -> Fights.depotBroken(b, lv, p));
            }
        } else if (st.is(ModBlocks.CUORE_404.get()) && Pocket.inside(p)) { e.setCanceled(true); lv.removeBlock(pos, false); Pocket.heartBroken(p); }
        else if (st.is(ModBlocks.TRACCIA_OSSERVATORE.get()) || st.is(ModBlocks.OCCHIO_OSSERVATORE.get())) Director.traceBroken(p, lv, pos, st);
        else if (st.is(Fx.DIAMOND_ORES)) Director.react(p, lv, "diamond");
        else if (st.is(Blocks.SPAWNER)) Director.react(p, lv, "spawner");
    }
    @SubscribeEvent public static void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.level().isClientSide() || !e.getPlacedBlock().is(ModBlocks.STATUA_DESTINO.get())) return;
        for (HorrorBoss b : ((ServerLevel) p.level()).getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(80.0)))
            if (b.kind == Kind.ENTITY404 && b.mode == HorrorBoss.FIGHT && b.lvl() == 7) { b.statues.add(e.getPos()); Fx.bar(p, "Statua del Destino piazzata (" + b.statues.size() + "/5)"); }
    }
}
