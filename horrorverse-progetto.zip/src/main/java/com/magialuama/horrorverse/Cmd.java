package com.magialuama.horrorverse;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** Comandi /horror: impostazioni per il giocatore + strumenti di debug (solo in Creativa o con comandiDebug=true). */
public final class Cmd {
    private Cmd() {}
    private static boolean debug(CommandSourceStack s) {
        ServerPlayer p = s.getPlayer();
        if (Config.DEBUG_CMDS.get() || (p != null && p.isCreative())) return true;
        s.sendFailure(Component.literal("Comando di debug: serve la modalità Creativa (o comandiDebug=true nel config)."));
        return false;
    }
    private static int ok(CommandSourceStack s, String msg) { s.sendSuccess(() -> Component.literal(msg), false); return 1; }

    @SubscribeEvent public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("horror")
            .then(Commands.literal("status").executes(c -> {
                ServerPlayer p = c.getSource().getPlayer(); if (p == null) return 0;
                StringBuilder sb = new StringBuilder("Capitolo " + Progress.chapter(p) + "/5 — " + Progress.minutes(p) + " min di gioco — profilo " + new String[]{"leggero", "standard", "intenso"}[Config.profile(p)] + "\n");
                for (Kind k : Kind.values()) sb.append(k.nameIt).append(": livello ").append(Progress.level(p, k)).append("/").append(k.maxLevel).append("  ");
                return ok(c.getSource(), sb.toString());
            }))
            .then(Commands.literal("diario").executes(c -> { ServerPlayer p = c.getSource().getPlayer(); if (p != null) Lore.diary(p); return 1; }))
            .then(Commands.literal("intensita").then(Commands.argument("livello", StringArgumentType.word()).executes(c -> {
                ServerPlayer p = c.getSource().getPlayer(); if (p == null) return 0;
                String v = StringArgumentType.getString(c, "livello");
                int n = v.startsWith("l") ? 1 : v.startsWith("i") ? 3 : 2;
                Progress.setCtr(p, "profile", n);
                return ok(c.getSource(), "Profilo horror: " + v + " (leggero | standard | intenso)");
            })))
            .then(Commands.literal("jumpscare").then(Commands.argument("stato", StringArgumentType.word()).executes(c -> {
                ServerPlayer p = c.getSource().getPlayer(); if (p == null) return 0;
                boolean on = StringArgumentType.getString(c, "stato").equals("on");
                Progress.setFlag(p, "nojump", !on);
                return ok(c.getSource(), "Jumpscare " + (on ? "attivi" : "disattivati"));
            })))
            .then(Commands.literal("scuotimento").then(Commands.argument("stato", StringArgumentType.word()).executes(c -> {
                ServerPlayer p = c.getSource().getPlayer(); if (p == null) return 0;
                boolean on = StringArgumentType.getString(c, "stato").equals("on");
                Progress.setFlag(p, "noshake", !on);
                return ok(c.getSource(), "Effetti invasivi (nausea/oscurità) " + (on ? "attivi" : "disattivati"));
            })))
            .then(Commands.literal("scelta").then(Commands.argument("scelta", StringArgumentType.word()).executes(c -> {
                ServerPlayer p = c.getSource().getPlayer(); if (p == null) return 0;
                ServerLevel lv = (ServerLevel) p.level();
                for (HorrorBoss b : lv.getEntitiesOfClass(HorrorBoss.class, p.getBoundingBox().inflate(40.0)))
                    if (b.kind == Kind.CUSTODE && b.mode == HorrorBoss.CHOICE) Brains.choose(b, lv, p, StringArgumentType.getString(c, "scelta").startsWith("r"));
                return 1;
            })))
            .then(Commands.literal("ritorno").executes(c -> {
                ServerPlayer p = c.getSource().getPlayer();
                if (p != null && Pocket.inside(p)) { Pocket.leave(p); Fx.afflict(p, net.minecraft.world.effect.MobEffects.WEAKNESS, 1200, 0); }
                return 1;
            }))
            .then(Commands.literal("recupera").then(Commands.argument("giocatore", EntityArgument.player()).executes(c -> {
                if (!debug(c.getSource())) return 0;
                ServerPlayer t = EntityArgument.getPlayer(c, "giocatore");
                Progress.setFlag(t, "corrotto.lost", false); t.setGameMode(GameType.SURVIVAL);
                return ok(c.getSource(), t.getName().getString() + " è stato recuperato.");
            })))
            .then(Commands.literal("capitolo").then(Commands.argument("n", IntegerArgumentType.integer(1, 5)).executes(c -> {
                if (!debug(c.getSource())) return 0;
                ServerPlayer p = c.getSource().getPlayer(); if (p == null) return 0;
                Progress.setCtr(p, "chapter", IntegerArgumentType.getInteger(c, "n"));
                return ok(c.getSource(), "Capitolo impostato.");
            })))
            .then(Commands.literal("reset").executes(c -> {
                if (!debug(c.getSource())) return 0;
                ServerPlayer p = c.getSource().getPlayer(); if (p != null) Progress.wipe(p);
                return ok(c.getSource(), "Progressi azzerati.");
            }))
            .then(Commands.literal("summon")
                .then(Commands.argument("entita", StringArgumentType.word()).then(Commands.argument("livello", IntegerArgumentType.integer(1, 7)).executes(c -> {
                    if (!debug(c.getSource())) return 0;
                    ServerPlayer p = c.getSource().getPlayer(); if (p == null) return 0;
                    ServerLevel lv = (ServerLevel) p.level();
                    String id = StringArgumentType.getString(c, "entita");
                    for (Kind k : Kind.values()) if (k.id.equals(id)) {
                        Vec3 v = Fx.ring(lv, p.position(), 8.0, 12.0);
                        HorrorBoss b = Fx.spawn(lv, ModEntities.of(k), v.x, v.y, v.z);
                        if (b == null) return 0;
                        b.setLvl(Math.min(k.maxLevel, IntegerArgumentType.getInteger(c, "livello")));
                        if (k == Kind.OSSERVATORE) return 1;
                        b.startFight(p, lv);
                        return ok(c.getSource(), k.nameIt + " livello " + b.lvl() + " evocato.");
                    }
                    return ok(c.getSource(), "Entità: osservatore, steve, custode, uomo_magico, corrotto, entity_404");
                }))))
            .then(Commands.literal("minion").then(Commands.argument("id", StringArgumentType.word()).executes(c -> {
                if (!debug(c.getSource())) return 0;
                ServerPlayer p = c.getSource().getPlayer(); if (p == null) return 0;
                for (MinionType t : MinionType.values()) if (t.id.equals(StringArgumentType.getString(c, "id"))) {
                    Vec3 v = Fx.ring((ServerLevel) p.level(), p.position(), 4.0, 6.0);
                    Fx.spawn((ServerLevel) p.level(), ModEntities.MINIONS.get(t).get(), v.x, v.y, v.z);
                    return ok(c.getSource(), t.nameIt + " evocato.");
                }
                return ok(c.getSource(), "Id non valido.");
            }))));
    }
}
