package com.magialuama.horrorverse;

import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModSounds {
    private ModSounds() {}
    public static final DeferredHolder<SoundEvent, SoundEvent> HEARTBEAT = Reg.sound("heartbeat");
    public static final DeferredHolder<SoundEvent, SoundEvent> FOOTSTEPS = Reg.sound("footsteps");
    public static final DeferredHolder<SoundEvent, SoundEvent> WHISPER_A = Reg.sound("whisper_a");
    public static final DeferredHolder<SoundEvent, SoundEvent> WHISPER_B = Reg.sound("whisper_b");
    public static final DeferredHolder<SoundEvent, SoundEvent> WHISPER_C = Reg.sound("whisper_c");
    public static final DeferredHolder<SoundEvent, SoundEvent> DRONE_LOW = Reg.sound("drone_low");
    public static final DeferredHolder<SoundEvent, SoundEvent> DOOR_CREAK = Reg.sound("door_creak");
    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER_FAR = Reg.sound("thunder_far");
    public static final DeferredHolder<SoundEvent, SoundEvent> JUMPSCARE = Reg.sound("jumpscare");
    public static final DeferredHolder<SoundEvent, SoundEvent> GLITCH = Reg.sound("glitch");
    public static final DeferredHolder<SoundEvent, SoundEvent> STATIC_BURST = Reg.sound("static_burst");
    public static final DeferredHolder<SoundEvent, SoundEvent> BELL_TOLL = Reg.sound("bell_toll");
    public static final DeferredHolder<SoundEvent, SoundEvent> RUNE_CHIME = Reg.sound("rune_chime");
    public static final DeferredHolder<SoundEvent, SoundEvent> MAGIC_CAST = Reg.sound("magic_cast");
    public static final DeferredHolder<SoundEvent, SoundEvent> TELEPORT_BLIP = Reg.sound("teleport_blip");
    public static final DeferredHolder<SoundEvent, SoundEvent> STATUE_GRIND = Reg.sound("statue_grind");
    public static final DeferredHolder<SoundEvent, SoundEvent> VICTORY_STING = Reg.sound("victory_sting");
    public static final DeferredHolder<SoundEvent, SoundEvent> DEFEAT_STING = Reg.sound("defeat_sting");
    public static final DeferredHolder<SoundEvent, SoundEvent> AMBIENT_NIGHT_A = Reg.sound("ambient_night_a");
    public static final DeferredHolder<SoundEvent, SoundEvent> AMBIENT_NIGHT_B = Reg.sound("ambient_night_b");
    public static final DeferredHolder<SoundEvent, SoundEvent> THEME_CUSTODE = Reg.sound("theme_custode");
    public static final DeferredHolder<SoundEvent, SoundEvent> THEME_CORROTTO = Reg.sound("theme_corrotto");
    public static final DeferredHolder<SoundEvent, SoundEvent> THEME_404 = Reg.sound("theme_404");
    public static final DeferredHolder<SoundEvent, SoundEvent> THEME_MAGO = Reg.sound("theme_mago");
    public static final DeferredHolder<SoundEvent, SoundEvent> THEME_STEVE = Reg.sound("theme_steve");
    public static final DeferredHolder<SoundEvent, SoundEvent> THEME_OSSERVATORE = Reg.sound("theme_osservatore");
    public static DeferredHolder<SoundEvent, SoundEvent> theme(Kind k) {
        return switch (k) {
            case CUSTODE -> THEME_CUSTODE; case CORROTTO -> THEME_CORROTTO; case ENTITY404 -> THEME_404;
            case MAGO -> THEME_MAGO; case STEVE -> THEME_STEVE; case OSSERVATORE -> THEME_OSSERVATORE;
        };
    }
    public static void init() { }
}
