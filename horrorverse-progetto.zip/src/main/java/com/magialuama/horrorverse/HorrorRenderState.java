package com.magialuama.horrorverse;

import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;

public class HorrorRenderState extends HumanoidRenderState {
    public Identifier tex;
}
