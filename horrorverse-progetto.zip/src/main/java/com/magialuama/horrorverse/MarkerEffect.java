package com.magialuama.horrorverse;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Effetto "marcatore": la logica è gestita dagli eventi del mod. */
public class MarkerEffect extends MobEffect {
    public MarkerEffect(MobEffectCategory category, int color) { super(category, color); }
}
