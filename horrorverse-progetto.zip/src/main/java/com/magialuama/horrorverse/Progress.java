package com.magialuama.horrorverse;

import java.util.ArrayList;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Progressi del giocatore salvati come tag dell'entità (visibili con /tag @s list, sopravvivono alla morte). */
public final class Progress {
    private Progress() {}

    private static String lvPrefix(Kind k) { return "hv.lv." + k.id + "."; }

    private static int readNum(Player p, String prefix) {
        int best = 0;
        for (String t : new ArrayList<>(p.entityTags())) {
            if (t.startsWith(prefix)) {
                try { best = Math.max(best, Integer.parseInt(t.substring(prefix.length()))); } catch (NumberFormatException ignored) { }
            }
        }
        return best;
    }
    private static void writeNum(Player p, String prefix, int v) {
        for (String t : new ArrayList<>(p.entityTags())) if (t.startsWith(prefix)) p.removeTag(t);
        if (v > 0) p.addTag(prefix + v);
    }

    public static int level(Player p, Kind k) { return readNum(p, lvPrefix(k)); }
    public static void setLevel(Player p, Kind k, int lv) { if (lv > level(p, k)) writeNum(p, lvPrefix(k), lv); }
    public static void resetLevel(Player p, Kind k, int lv) { writeNum(p, lvPrefix(k), lv); }

    public static boolean flag(Player p, String f) { return p.entityTags().contains("hv.f." + f); }
    public static void setFlag(Player p, String f, boolean on) { if (on) p.addTag("hv.f." + f); else p.removeTag("hv.f." + f); }

    public static int ctr(Player p, String key) { return readNum(p, "hv.c." + key + "."); }
    public static void setCtr(Player p, String key, int v) { writeNum(p, "hv.c." + key + ".", v); }
    public static int addCtr(Player p, String key, int d) { int v = ctr(p, key) + d; setCtr(p, key, v); return v; }

    public static int chapter(Player p) { return Math.max(1, ctr(p, "chapter")); }
    public static int minutes(Player p) { return ctr(p, "min"); }

    /** Capitolo narrativo: 1 Osservatore+Steve, 2 Custode, 3 Uomo Magico, 4 Corrotto, 5 Entity 404. */
    public static void updateChapter(ServerPlayer p) {
        int ch = chapter(p); double m = minutes(p) * Config.CHAPTER_SPEED.get();
        int target = ch;
        if (ch < 2 && m >= 20) target = 2;
        if (ch < 3 && m >= 60 && (level(p, Kind.CUSTODE) >= 1 || m >= 150)) target = Math.max(target, 3);
        if (ch < 4 && m >= 100 && (level(p, Kind.MAGO) >= 1 || m >= 250)) target = Math.max(target, 4);
        if (ch < 5 && m >= 160 && (level(p, Kind.CORROTTO) >= 2 || m >= 400)) target = Math.max(target, 5);
        if (target > ch) {
            setCtr(p, "chapter", target);
            String[] n = {"", "", "Il Custode dagli Occhi Bianchi comincia a farsi vedere.", "Rune e libri strani: l'Uomo Magico è vicino.",
                    "Un viaggiatore gentile da un altro universo si avvicina.", "Qualcosa di verde corrompe i messaggi. Entity 404 è vicino."};
            Fx.info(p, net.minecraft.ChatFormatting.DARK_GRAY, "— " + n[Math.min(target, 5)] + " —");
        }
    }

    public static void copy(Player from, Player to) {
        for (String t : new ArrayList<>(from.entityTags())) if (t.startsWith("hv.")) to.addTag(t);
    }
    public static void wipe(Player p) {
        for (String t : new ArrayList<>(p.entityTags())) if (t.startsWith("hv.")) p.removeTag(t);
    }
}
