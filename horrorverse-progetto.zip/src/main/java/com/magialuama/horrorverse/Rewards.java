package com.magialuama.horrorverse;

import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredItem;

/** Ricompense, avanzamento di livello, lore e achievement alla fine di una boss fight. */
public final class Rewards {
    private Rewards() {}

    static void give(ServerPlayer p, String id, int n) {
        DeferredItem<? extends Item> d = Reg.BY_ID.get(id);
        if (d != null) Fx.give(p, new ItemStack(d.get(), n));
    }
    private static final String[][] ADV = {
        /*CUSTODE*/ {"", "custode_prima_prova", "custode_contatto", "custode_scettro", "custode_supremo", "custode_rituale"},
        /*CORROTTO*/ {"", "corrotto_statue", "corrotto_oscurita", "corrotto_corruzione", "corrotto_indebolito", "corrotto_dio"},
        /*E404*/ {"", "e404_troll", "e404_skin", "e404_piaga", "e404_demone", "e404_cucciolo", "e404_signore", "e404_apocalisse"},
        /*MAGO*/ {"", "mago_apprendista", "mago_illusioni", "mago_rune", "mago_arcimago", "mago_dio"},
        /*STEVE*/ {"", "steve_sconosciuto", "steve_sopravvissuto", "steve_maestro", "steve_veterano", "steve_perfetto"}};
    private static final String[][] LORE = {
        {"", "cus.2", "cus.3", "", "cus.4", "cus.6"},
        {"", "cor.2", "cor.3", "cor.4", "", "cor.5"},
        {"", "e404.2", "e404.3", "e404.4", "e404.5", "", "e404.6", ""},
        {"", "mag.2", "mag.3", "mag.4", "", "mag.5"},
        {"", "", "ste.3", "", "ste.4", "ste.5"}};
    private static int row(Kind k) { return switch (k) { case CUSTODE -> 0; case CORROTTO -> 1; case ENTITY404 -> 2; case MAGO -> 3; default -> 4; }; }

    /** @return true se l'entità deve restare (scelta del Custode). */
    public static boolean victory(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        Kind k = b.kind; int L = b.lvl();
        if (k == Kind.CUSTODE && L == 4) {
            b.mode = HorrorBoss.CHOICE; b.fightTick = 0; b.setNoAi(true); b.setHealth(b.getMaxHealth());
            Fx.say(p, k, "...Basta. Hai vinto. Uccidimi, o lasciami andare.");
            Fx.info(p, ChatFormatting.YELLOW, "Scegli: scrivi in chat «risparmia» oppure «uccidi» (o usa /horror scelta risparmia|uccidi).");
            return true;
        }
        if (k == Kind.OSSERVATORE) return false;
        Progress.setLevel(p, k, L);
        int r = row(k);
        if (r < ADV.length && L < ADV[r].length) {
            if (!ADV[r][L].isEmpty()) Fx.grant(p, ADV[r][L]);
            if (L < LORE[r].length && !LORE[r][L].isEmpty()) Lore.unlock(p, LORE[r][L]);
        }
        reward(k, L, p);
        Fx.soundTo(p, ModSounds.VICTORY_STING.get(), 0.8f, 1.0f);
        Fx.title(p, "Vittoria", k.nameIt + " — " + Lore.levelName(k, L));
        return false;
    }

    private static void reward(Kind k, int L, ServerPlayer p) {
        switch (k) {
            case CUSTODE -> {
                switch (L) {
                    case 1 -> { give(p, "frammento_occhio_bianco", 2); Fx.say(p, k, "Una prova superata. Non è che l'inizio."); }
                    case 2 -> { give(p, "frammento_occhio_bianco", 3); Fx.say(p, k, "Mi hai toccato. Nessuno lo faceva da... da quando."); }
                    case 3 -> { give(p, "scettro_elettrico", 1); give(p, "frammento_occhio_bianco", 2); Fx.say(p, k, "Prendi lo scettro. Ti servirà."); }
                    default -> { give(p, "occhio_bianco", 1); Fx.say(p, k, "Il limite... è stato superato. Era questo che temevo."); }
                }
            }
            case CORROTTO -> {
                switch (L) {
                    case 1 -> { give(p, "cristallo_luce", 2); Fx.say(p, k, "Scusami... io non volevo."); }
                    case 2 -> { give(p, "cristallo_luce", 3); Fx.say(p, k, "Aiutami. Qualcosa mi consuma."); }
                    case 3 -> { give(p, "artefatto_antioscurita", 2); give(p, "cristallo_luce", 3); }
                    case 4 -> { give(p, "cristallo_purificazione", 1); give(p, "artefatto_antioscurita", 1); }
                    default -> { give(p, "cristallo_purificazione", 2); Fx.say(p, k, "Grazie. Sono... ancora io?"); }
                }
                Progress.setCtr(p, "trust", 61 + 20);   // dopo lo scontro è di nuovo capace di fidarsi
            }
            case ENTITY404 -> {
                switch (L) {
                    case 1 -> give(p, "frammento_verde", 3);
                    case 2 -> { give(p, "frammento_verde", 5); give(p, "nucleo_corrotto", 1); }
                    case 3 -> { give(p, "nucleo_corrotto", 2); give(p, "fiala_contenimento", 2); }
                    case 4 -> { give(p, "nucleo_corrotto", 3); give(p, "chiave_dimensione", 1); }
                    case 5 -> give(p, "nucleo_corrotto", 4);
                    case 6 -> give(p, "nucleo_corrotto", 6);
                    default -> { Fx.title(p, "FINE", "Entity 404 è stato sconfitto"); Progress.setFlag(p, "e404.finale", true); }
                }
            }
            case MAGO -> {
                switch (L) {
                    case 1 -> give(p, "runa_antica", 1);
                    case 2 -> { give(p, "runa_antica", 1); give(p, "biscotto_runico", 3); }
                    case 3 -> give(p, "runa_antica", 2);
                    case 4 -> { give(p, "runa_antica", 2); give(p, "spada_runica", 1); }
                    default -> { give(p, "bastone_mago", 1); Fx.say(p, k, "Il bastone è in frantumi. Quanta fatica avrei evitato... se non l'avessi mai preso."); }
                }
            }
            case STEVE -> {
                switch (L) {
                    case 1 -> { give(p, "pane_pallido", 4); Fx.say(p, k, "Non male. Ti lascio queste."); }
                    case 2 -> give(p, "bacche_spettrali", 6);
                    case 3 -> give(p, "lingotto_spettrale", 2);
                    case 4 -> give(p, "lingotto_spettrale", 3);
                    default -> {
                        Progress.setFlag(p, "steve.truce", true);
                        give(p, "frutto_eden", 1);
                        Fx.say(p, k, "Sei pronto. Non sei solo: la tregua è tra noi.");
                        Fx.grant(p, "steve_tregua");
                    }
                }
            }
            default -> { }
        }
    }
}
