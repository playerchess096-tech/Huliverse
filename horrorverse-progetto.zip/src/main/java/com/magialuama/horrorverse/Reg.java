package com.magialuama.horrorverse;

import java.util.*;
import java.util.function.Function;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.RegisterEvent;

public final class Reg {
    private Reg() {}
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(HorrorVerse.MODID);
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(HorrorVerse.MODID);
    public static final DeferredRegister.Entities ENTITIES = DeferredRegister.createEntities(HorrorVerse.MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, HorrorVerse.MODID);
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(Registries.MOB_EFFECT, HorrorVerse.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HorrorVerse.MODID);

    public static final List<DeferredItem<? extends Item>> TAB_ITEMS = new ArrayList<>();
    public static final Map<String, DeferredItem<? extends Item>> BY_ID = new HashMap<>();

    public static DeferredItem<Item> item(String id, Function<Item.Properties, Item> factory) {
        DeferredItem<Item> d = ITEMS.registerItem(id, factory);
        TAB_ITEMS.add(d); BY_ID.put(id, d);
        return d;
    }

    public static net.neoforged.neoforge.registries.DeferredHolder<SoundEvent, SoundEvent> sound(String id) {
        return SOUNDS.register(id, () -> SoundEvent.createVariableRangeEvent(Fx.id(id)));
    }

    public static final java.util.function.Supplier<CreativeModeTab> TAB = TABS.register("principale", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.horrorverse"))
            .icon(() -> new ItemStack(ModItems.OCCHIO_BIANCO.get()))
            .displayItems((params, out) -> { for (DeferredItem<? extends Item> i : TAB_ITEMS) out.accept(i.get()); })
            .build());

    public static void register(IEventBus bus) {
        ModBlocks.init(); ModItems.init(); ModEffects.init(); ModSounds.init(); ModEntities.init(); Structures.init();
        BLOCKS.register(bus); ITEMS.register(bus); ENTITIES.register(bus); SOUNDS.register(bus);
        EFFECTS.register(bus); TABS.register(bus);
        bus.addListener(Reg::registerFeatureTypes);
    }

    /** In 26.3 una Feature è un'interfaccia: nel registro FEATURE_TYPE si registra solo il suo MapCodec. */
    private static void registerFeatureTypes(RegisterEvent e) {
        e.register(BuiltInRegistries.FEATURE_TYPE.key(), Fx.id("struct"), () -> Structures.Struct.CODEC);
    }
}
