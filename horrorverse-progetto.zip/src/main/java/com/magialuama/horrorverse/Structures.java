package com.magialuama.horrorverse;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.chunk.ChunkGenerator;

/** Strutture e "macchie di bioma" generate da codice (registrate come Feature, piazzate tramite biome modifier). */
public final class Structures {
    private Structures() {}
    public static void init() { }

    public static boolean isTemp(BlockState s) {
        return s.is(ModBlocks.RUNA_PILASTRO.get()) || s.is(ModBlocks.GENERATORE_ARCANO.get()) || s.is(ModBlocks.PIEDISTALLO_BASTONE.get())
                || s.is(ModBlocks.CUBO_VERDE.get()) || s.is(ModBlocks.OCCHIO_OSSERVATORE.get()) || s.is(ModBlocks.TRACCIA_OSSERVATORE.get());
    }

    /**
     * Feature del mod (Minecraft 26.3: Feature è un'interfaccia, la configurazione sta nei campi del record).
     * Nei JSON di worldgen/feature si scrive: {"type": "horrorverse:struct", "kind": N}.
     */
    public record Struct(int kind) implements Feature {
        public static final MapCodec<Struct> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
                Codec.INT.fieldOf("kind").forGetter(Struct::kind)).apply(i, Struct::new));

        @Override public MapCodec<Struct> codec() { return CODEC; }

        @Override public boolean place(WorldGenLevel lv, ChunkGenerator generator, RandomSource random, BlockPos o) {
            if (kind == ORE) return ore(lv, o, random);
            if (!Config.STRUCTURES.get()) return false;
            if (lv.getBlockState(o.below()).isAir() || !lv.getFluidState(o).isEmpty() || !lv.getFluidState(o.below()).isEmpty()) return false;
            build(lv, o, kind, random);
            return true;
        }
    }

    /** kind 7: piccolo filone di minerale spettrale (tag creati per nome, cosi' non dipendono dalle costanti Java). */
    public static final int ORE = 7;
    private static final TagKey<Block> STONE_REPLACEABLES = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("minecraft", "stone_ore_replaceables"));
    private static final TagKey<Block> DEEPSLATE_REPLACEABLES = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("minecraft", "deepslate_ore_replaceables"));

    private static boolean ore(WorldGenLevel lv, BlockPos o, RandomSource r) {
        int placed = 0;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int i = 0; i < 6; i++) {
            m.set(o.getX() + r.nextInt(3) - 1, o.getY() + r.nextInt(3) - 1, o.getZ() + r.nextInt(3) - 1);
            BlockState st = lv.getBlockState(m);
            if (st.is(STONE_REPLACEABLES) || st.is(DEEPSLATE_REPLACEABLES)) {
                lv.setBlock(m, ModBlocks.MINERALE_SPETTRALE.get().defaultBlockState(), 2);
                placed++;
            }
        }
        return placed > 0;
    }

    /** Il letto del rifugio: in 26.3 i letti sono cambiati, quindi si cerca per nome e, se manca, si ripiega su lana rossa. */
    private static void bed(LevelAccessor lv, BlockPos pos) {
        for (String name : new String[] {"red_bed", "red_wool_bed"}) {
            var b = BuiltInRegistries.BLOCK.getOptional(Identifier.fromNamespaceAndPath("minecraft", name));
            if (b.isPresent()) { lv.setBlock(pos, b.get().defaultBlockState(), 2); return; }
        }
        set(lv, pos, Blocks.RED_WOOL);
    }

    private static void set(LevelAccessor lv, BlockPos p, Block b) { lv.setBlock(p, b.defaultBlockState(), 2); }
    private static void chest(LevelAccessor lv, BlockPos p, ItemStack... items) {
        lv.setBlock(p, Blocks.CHEST.defaultBlockState(), 2);
        if (lv.getBlockEntity(p) instanceof Container c) for (int i = 0; i < items.length; i++) c.setItem(i * 2 % c.getContainerSize(), items[i]);
    }
    private static ItemStack st(String id, int n) { return new ItemStack(Reg.BY_ID.get(id).get(), n); }

    /** kind: 0 altare, 1 torre del mago, 2 santuario, 3 rifugio, 4 torre dell'osservatore, 5 landa, 6 macchia */
    public static void build(LevelAccessor lv, BlockPos o, int kind, RandomSource r) {
        switch (kind) {
            case 0 -> {
                for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d <= 4.2) set(lv, o.offset(dx, -1, dz), d > 3.0 ? Blocks.STONE_BRICKS : Blocks.POLISHED_BLACKSTONE);
                    if (d <= 4.2) for (int y = 0; y < 5; y++) lv.setBlock(o.offset(dx, y, dz), Blocks.AIR.defaultBlockState(), 2);
                }
                for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) for (int y = 0; y < 4; y++) set(lv, o.offset(sx * 3, y, sz * 3), ModBlocks.PIETRA_RITUALE.get());
                set(lv, o, ModBlocks.PIETRA_RITUALE.get());
                chest(lv, o.above(), st("frammento_occhio_bianco", 2), st("diario_mondo", 1), new ItemStack(Items.ENDER_PEARL, 1));
                lv.setBlock(o.above(2), Blocks.SOUL_LANTERN.defaultBlockState(), 2);
            }
            case 1 -> {
                for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int y = -1; y < 11; y++) {
                    boolean wall = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                    BlockPos q = o.offset(dx, y, dz);
                    if (y == -1 || y == 10) set(lv, q, Blocks.STONE_BRICKS);
                    else if (wall) set(lv, q, (y % 4 == 3 && (dx == 0 || dz == 0)) ? Blocks.GLASS : Blocks.STONE_BRICKS);
                    else lv.setBlock(q, Blocks.AIR.defaultBlockState(), 2);
                }
                lv.setBlock(o.offset(0, 0, -2), Blocks.AIR.defaultBlockState(), 2); lv.setBlock(o.offset(0, 1, -2), Blocks.AIR.defaultBlockState(), 2);
                set(lv, o.offset(-1, 0, 1), Blocks.BOOKSHELF); set(lv, o.offset(-1, 1, 1), Blocks.BOOKSHELF); set(lv, o.offset(1, 0, 1), Blocks.BOOKSHELF);
                for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) set(lv, o.offset(sx * 2, 11, sz * 2), ModBlocks.RUNA_PILASTRO.get());
                chest(lv, o.offset(0, 0, 0), st("runa_antica", 1), new ItemStack(Items.BOOK, 2), new ItemStack(Items.AMETHYST_SHARD, 4));
            }
            case 2 -> {
                for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) if (r.nextInt(3) != 0) set(lv, o.offset(dx, -1, dz), r.nextBoolean() ? ModBlocks.BLOCCO_OSCURO.get() : Blocks.BLACKSTONE);
                for (int i = 0; i < 6; i++) { int px = r.nextInt(9) - 4, pz = r.nextInt(9) - 4, h = 2 + r.nextInt(4); for (int y = 0; y < h; y++) set(lv, o.offset(px, y, pz), ModBlocks.BLOCCO_OSCURO.get()); }
                chest(lv, o, st("cristallo_luce", 2), new ItemStack(Items.GLOWSTONE_DUST, 6));
            }
            case 3 -> {
                for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) for (int y = -1; y <= 3; y++) {
                    BlockPos q = o.offset(dx, y, dz);
                    boolean wall = Math.abs(dx) == 3 || Math.abs(dz) == 3;
                    if (y == -1) set(lv, q, Blocks.OAK_PLANKS);
                    else if (y == 3) set(lv, q, Blocks.OAK_SLAB);
                    else if (wall) set(lv, q, (Math.abs(dx) == 3 && Math.abs(dz) == 3) ? Blocks.OAK_LOG : Blocks.OAK_PLANKS);
                    else lv.setBlock(q, Blocks.AIR.defaultBlockState(), 2);
                }
                lv.setBlock(o.offset(0, 0, -3), Blocks.AIR.defaultBlockState(), 2); lv.setBlock(o.offset(0, 1, -3), Blocks.AIR.defaultBlockState(), 2);
                set(lv, o.offset(-2, 0, 2), Blocks.CRAFTING_TABLE); set(lv, o.offset(-1, 0, 2), Blocks.FURNACE);
                bed(lv, o.offset(2, 0, 2));
                chest(lv, o.offset(2, 0, -2), new ItemStack(Items.BREAD, 6), new ItemStack(Items.TORCH, 16), new ItemStack(Items.IRON_INGOT, 4), new ItemStack(Items.ARROW, 12));
                lv.setBlock(o.offset(0, 2, 0), Blocks.LANTERN.defaultBlockState(), 2);
            }
            case 4 -> {
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) for (int y = -1; y <= 14; y++) {
                    boolean wall = Math.abs(dx) == 1 || Math.abs(dz) == 1;
                    BlockPos q = o.offset(dx, y, dz);
                    if (y == -1 || y == 14) set(lv, q, Blocks.BLACKSTONE);
                    else if (wall) set(lv, q, Blocks.POLISHED_BLACKSTONE_BRICKS);
                    else lv.setBlock(q, Blocks.AIR.defaultBlockState(), 2);
                }
                lv.setBlock(o.offset(0, 0, -1), Blocks.AIR.defaultBlockState(), 2); lv.setBlock(o.offset(0, 1, -1), Blocks.AIR.defaultBlockState(), 2);
                set(lv, o.offset(0, 15, 0), ModBlocks.OCCHIO_OSSERVATORE.get());
                for (int y = 0; y < 14; y += 3) lv.setBlock(o.offset(0, y, 0), Blocks.LADDER.defaultBlockState(), 2);
            }
            case 5 -> patch(lv, o, 12, r, Blocks.COARSE_DIRT, Blocks.GRAVEL, false);
            default -> patch(lv, o, 10, r, ModBlocks.BLOCCO_ORGANICO.get(), Blocks.MOSS_BLOCK, true);
        }
    }

    private static void patch(LevelAccessor lv, BlockPos o, int rad, RandomSource r, Block a, Block b2, boolean green) {
        for (int dx = -rad; dx <= rad; dx++) for (int dz = -rad; dz <= rad; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > rad || r.nextDouble() < d / (rad * 1.4)) continue;
            int x = o.getX() + dx, z = o.getZ() + dz, y = lv.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
            BlockPos g = new BlockPos(x, y, z);
            BlockState s = lv.getBlockState(g);
            if (s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.DIRT) || s.is(Blocks.SAND) || s.is(Blocks.PODZOL) || s.is(Blocks.COARSE_DIRT)) {
                lv.setBlock(g, (r.nextInt(3) == 0 ? b2 : a).defaultBlockState(), 2);
                BlockState up = lv.getBlockState(g.above());
                if (up.is(Blocks.SHORT_GRASS) || up.is(Blocks.TALL_GRASS) || up.is(Blocks.FERN)) lv.setBlock(g.above(), Blocks.AIR.defaultBlockState(), 2);
            }
        }
        if (!green) for (int i = 0; i < 3; i++) {   // alberi morti
            int x = o.getX() + r.nextInt(rad * 2) - rad, z = o.getZ() + r.nextInt(rad * 2) - rad, y = lv.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
            int h = 3 + r.nextInt(3);
            for (int k = 0; k < h; k++) lv.setBlock(new BlockPos(x, y + k, z), Blocks.STRIPPED_OAK_LOG.defaultBlockState(), 2);
        }
    }
}
