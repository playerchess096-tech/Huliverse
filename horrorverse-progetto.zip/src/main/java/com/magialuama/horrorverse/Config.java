package com.magialuama.horrorverse;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class Config {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue PROFILE;            // 0 leggero, 1 standard, 2 intenso
    public static final ModConfigSpec.DoubleValue EVENT_RATE, HEALTH_MULT, DAMAGE_MULT, SPEED_MULT, CHAPTER_SPEED, EFFECT_MULT, ABILITY_CD_MULT;
    public static final ModConfigSpec.BooleanValue JUMPSCARE, SHAKE, PRESENCE, NARRATIVE_ORDER, ALLIANCES, POCKET, GRIEF,
            WORLD_DESTRUCTION, PERMADEATH, CREATIVE_KILL, DEBUG_CMDS, EDEN_BLOCKS, STRUCTURES, ORE;
    public static final ModConfigSpec.IntValue MAX_MINIONS, MAX_CLONES, PRESENCE_MIN_MINUTES, PRESENCE_MAX_MINUTES, FIGHT_TIMEOUT_SECONDS,
            CUSTODE_L4_MIN_ATTACK, MAGO_L4_MIN_ATTACK, ENTITY_PERSIST, PEARL_HITS, JUMPSCARE_COOLDOWN_MINUTES, BOSS_FIGHT_COOLDOWN_MINUTES;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.push("atmosfera");
        PROFILE = b.comment("Profilo horror: 0 = leggero, 1 = standard, 2 = intenso (cambia solo frequenza/atmosfera, non la forza dei boss)").defineInRange("profilo", 1, 0, 2);
        EVENT_RATE = b.comment("Moltiplicatore della frequenza degli eventi horror").defineInRange("frequenzaEventi", 1.0, 0.1, 5.0);
        JUMPSCARE = b.comment("Permette i jumpscare (suono + titolo)").define("jumpscare", true);
        JUMPSCARE_COOLDOWN_MINUTES = b.comment("Minuti minimi tra due jumpscare").defineInRange("jumpscareCooldownMinuti", 12, 1, 120);
        SHAKE = b.comment("Permette effetti invasivi (nausea, oscurità pulsante)").define("effettiInvasivi", true);
        EFFECT_MULT = b.comment("Moltiplicatore della durata degli effetti").defineInRange("durataEffetti", 1.0, 0.25, 3.0);
        b.pop();
        b.push("entita");
        PRESENCE = b.comment("Le entità compaiono da sole nel mondo (fuori dalle boss fight)").define("presenzaAutonoma", true);
        NARRATIVE_ORDER = b.comment("Rispetta l'ordine narrativo: Osservatore/Steve, Custode, Uomo Magico, Corrotto, Entity 404").define("ordineNarrativo", true);
        CHAPTER_SPEED = b.comment("Velocità di avanzamento dei capitoli (2.0 = il doppio più veloce)").defineInRange("velocitaCapitoli", 1.0, 0.1, 20.0);
        PRESENCE_MIN_MINUTES = b.comment("Minuti minimi tra due apparizioni della stessa entità").defineInRange("apparizioneMinMinuti", 6, 1, 240);
        PRESENCE_MAX_MINUTES = b.comment("Minuti massimi tra due apparizioni della stessa entità").defineInRange("apparizioneMaxMinuti", 18, 2, 480);
        BOSS_FIGHT_COOLDOWN_MINUTES = b.comment("Minuti di pausa dopo una boss fight prima di una nuova sfida").defineInRange("pausaBossMinuti", 10, 0, 240);
        HEALTH_MULT = b.comment("Moltiplicatore salute").defineInRange("salute", 1.0, 0.2, 5.0);
        DAMAGE_MULT = b.comment("Moltiplicatore danni").defineInRange("danni", 1.0, 0.1, 5.0);
        SPEED_MULT = b.comment("Moltiplicatore velocità").defineInRange("velocita", 1.0, 0.5, 2.0);
        ABILITY_CD_MULT = b.comment("Moltiplicatore dei cooldown delle abilità (più alto = più lente)").defineInRange("cooldownAbilita", 1.0, 0.25, 4.0);
        MAX_MINIONS = b.comment("Massimo di mostri evocati per boss").defineInRange("maxMostri", 10, 1, 40);
        MAX_CLONES = b.comment("Massimo di cloni per boss").defineInRange("maxCloni", 4, 0, 12);
        ENTITY_PERSIST = b.comment("Secondi massimi di una boss fight (poi termina)").defineInRange("persistenzaBoss", 1500, 120, 7200);
        FIGHT_TIMEOUT_SECONDS = ENTITY_PERSIST;
        ALLIANCES = b.comment("Permette alleanze (Corrotto, Steve, clone di Entity 404)").define("alleanze", true);
        b.pop();
        b.push("armi");
        CUSTODE_L4_MIN_ATTACK = b.comment("Attacco minimo per ferire il Custode livello 4 (8 = spada di netherite)").defineInRange("custodeL4Attacco", 8, 1, 30);
        MAGO_L4_MIN_ATTACK = b.comment("Attacco minimo per ferire l'Arcimago (7 = spada di diamante)").defineInRange("magoL4Attacco", 7, 1, 30);
        PEARL_HITS = b.comment("Perle valide necessarie contro il Custode livello 5").defineInRange("perleNecessarie", 10, 1, 30);
        EDEN_BLOCKS = b.comment("Il Frutto dell'Eden annulla gli effetti negativi del mod").define("edenProtegge", true);
        b.pop();
        b.push("mondo");
        STRUCTURES = b.comment("Genera le strutture del mod").define("strutture", true);
        ORE = b.comment("Genera il Minerale Spettrale").define("minerale", true);
        POCKET = b.comment("Abilita la dimensione tascabile di Entity 404").define("dimensione404", true);
        GRIEF = b.comment("Le esplosioni e le abilità possono rompere blocchi (di default NO)").define("distruzioneBlocchi", false);
        b.pop();
        b.push("pericolose");
        WORLD_DESTRUCTION = b.comment("Distruzione narrativa del mondo se scade il timer del livello 7 (non cancella mai il salvataggio)").define("distruzioneNarrativa", false);
        PERMADEATH = b.comment("Morte permanente narrativa del Dio dell'Oscurità (spettatore finché non recuperato con /horror recupera)").define("mortePermanenteNarrativa", false);
        CREATIVE_KILL = b.comment("Fase post-distruzione: Entity 404 può uccidere anche in Creativa").define("uccidiInCreativa", false);
        DEBUG_CMDS = b.comment("Comandi di debug /horror summon, capitolo, reset per tutti (altrimenti solo in Creativa)").define("comandiDebug", false);
        b.pop();
        SPEC = b.build();
    }
    private Config() {}
    public static double mult(ModConfigSpec.DoubleValue v) { return v.get(); }
    public static int profile(net.minecraft.world.entity.player.Player p) {
        int c = Progress.ctr(p, "profile");
        return c == 0 ? PROFILE.get() : c - 1;
    }
    public static double rate(net.minecraft.world.entity.player.Player p) {
        double f = switch (profile(p)) { case 0 -> 0.5; case 2 -> 1.8; default -> 1.0; };
        return f * EVENT_RATE.get();
    }
}
