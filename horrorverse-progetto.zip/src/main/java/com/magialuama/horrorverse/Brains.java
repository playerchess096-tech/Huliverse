package com.magialuama.horrorverse;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/** Smistamento per modalità e comportamento di PRESENZA autonoma (fuori dalle boss fight). */
public final class Brains {
    private Brains() {}

    public static void tick(HorrorBoss b, ServerLevel lv) {
        switch (b.mode) {
            case HorrorBoss.FIGHT -> b.fightLogic(lv);
            case HorrorBoss.CHOICE -> choiceTick(b, lv);
            default -> presence(b, lv);
        }
    }
    public static void onStart(HorrorBoss b, ServerLevel lv, ServerPlayer p) { Fights.onStart(b, lv, p); }
    public static void fight(HorrorBoss b, ServerLevel lv, ServerPlayer p) { Fights.fight(b, lv, p); }

    // ------------------------------------------------------------ utilità
    public static boolean canFight(ServerPlayer p, ServerLevel lv, Kind k) {
        if (lv.getDifficulty() == Difficulty.PEACEFUL) return false;
        if (Config.NARRATIVE_ORDER.get() && Progress.chapter(p) < k.chapter) return false;
        int last = Progress.ctr(p, "lastfight"), now = Math.max(1, Progress.minutes(p));
        return last == 0 || now - last >= Config.BOSS_FIGHT_COOLDOWN_MINUTES.get();
    }
    public static int nextLevel(ServerPlayer p, Kind k) {
        int cap = k == Kind.CUSTODE ? 4 : k.maxLevel;
        return Math.max(1, Math.min(cap, Progress.level(p, k) + 1));
    }
    public static int trust(Player p) { int raw = Progress.ctr(p, "trust"); return raw == 0 ? 20 : raw - 101; }
    public static void setTrust(Player p, int v) { Progress.setCtr(p, "trust", Math.max(-100, Math.min(100, v)) + 101); }
    private static ServerPlayer nearest(ServerLevel lv, HorrorBoss b, double r) {
        Player n = lv.getNearestPlayer(b.getX(), b.getY(), b.getZ(), r, e -> !e.isSpectator());
        return n instanceof ServerPlayer sp ? sp : null;
    }

    static final String[] SIGHT_ADV = {"osservatore_primo_sguardo", "steve_primo_incontro", "custode_avvistamento", "mago_avvistamento", "corrotto_incontro", "e404_avvistamento"};
    static void sighting(HorrorBoss b, ServerPlayer p) {
        int n = Progress.addCtr(p, "sight." + b.kind.id, 1);
        Fx.grant(p, SIGHT_ADV[b.kind.ordinal()]);
        switch (b.kind) {
            case OSSERVATORE -> { if (n == 1) Lore.unlock(p, "oss.1"); if (n == 3) Lore.unlock(p, "oss.2"); if (n == 5) Lore.unlock(p, "oss.3"); }
            case STEVE -> { if (n == 1) Lore.unlock(p, "ste.1"); }
            case CUSTODE -> { if (n == 1) Lore.unlock(p, "cus.1"); }
            case MAGO -> { if (n == 1) Lore.unlock(p, "mag.1"); }
            case CORROTTO -> { if (n == 1) Lore.unlock(p, "cor.1"); }
            case ENTITY404 -> { if (n == 1) Lore.unlock(p, "e404.1"); }
        }
        if (Progress.flag(p, "sg.oss") && Progress.flag(p, "sg.ste") && Progress.flag(p, "sg.cus") && Progress.flag(p, "sg.mag") && Progress.flag(p, "sg.cor") && Progress.flag(p, "sg.404")) Fx.grant(p, "tutte_le_entita");
        Progress.setFlag(p, "sg." + b.kind.id.substring(0, 3), true);
    }
    static void vanish(HorrorBoss b, ServerLevel lv, ServerPlayer p, boolean sighted) {
        Fx.particles(lv, ParticleTypes.SMOKE, b.getX(), b.getY() + 1.0, b.getZ(), 30, 0.3, 0.8, 0.3, 0.05);
        if (p != null) Fx.sound(lv, p.getX(), p.getY(), p.getZ(), ModSounds.STATIC_BURST.get(), 0.4f, 0.8f);
        if (sighted && p != null) {
            sighting(b, p);
            if (b.gaze > 20) Fx.grant(p, "osservatore_non_guardare");
        }
        b.discard();
    }
    static void watcher(HorrorBoss b, ServerLevel lv, ServerPlayer p, double d, double minDist, double gazeLimit) {
        b.setNoAi(true); b.face(p);
        if (Fx.looking(p, b, 0.92)) b.gaze += 1.0; else b.gaze = Math.max(0.0, b.gaze - 0.4);
        if (b.gaze > gazeLimit || d < minDist) vanish(b, lv, p, true);
    }

    // ------------------------------------------------------------ presenza
    private static void presence(HorrorBoss b, ServerLevel lv) {
        ServerPlayer p = nearest(lv, b, 96.0);
        if (p == null) { if (b.lifeTicks > 400) b.discard(); return; }
        int maxLife = switch (b.kind) { case OSSERVATORE -> 2400; case CUSTODE, MAGO -> 3000; case CORROTTO, STEVE -> 7200; case ENTITY404 -> 1200; };
        if (b.lifeTicks > maxLife) { vanish(b, lv, p, b.kind == Kind.STEVE || b.kind == Kind.CORROTTO); return; }
        double d = b.distanceTo(p);
        b.setVariant(b.kind == Kind.CORROTTO ? (trust(p) > 20 ? 0 : (trust(p) > -60 ? 1 : 2)) : 0);
        switch (b.kind) {
            case OSSERVATORE -> {
                watcher(b, lv, p, d, 12.0, 45.0);
                if (b.lifeTicks % 120 == 0) Fx.sound(lv, p.getX(), p.getY(), p.getZ(), ModSounds.FOOTSTEPS.get(), 0.25f, 0.9f);
            }
            case CUSTODE -> custode(b, lv, p, d);
            case MAGO -> mago(b, lv, p, d);
            case CORROTTO -> corrotto(b, lv, p, d);
            case STEVE -> steve(b, lv, p, d);
            case ENTITY404 -> e404(b, lv, p, d);
        }
    }

    private static void custode(HorrorBoss b, ServerLevel lv, ServerPlayer p, double d) {
        if (b.lifeTicks % 160 == 0 && b.getRandom().nextInt(3) == 0) { Vec3 v = Fx.ring(lv, p.position(), 18.0, 30.0); Fx.bolt(lv, v.x, v.y, v.z); }
        boolean spared = Progress.flag(p, "custode.spared");
        if (!spared && Progress.level(p, Kind.CUSTODE) < 4 && Progress.ctr(p, "sight.custode") >= 3 && d < 10.0 && canFight(p, lv, Kind.CUSTODE)) {
            b.setNoAi(false); b.startFight(p, lv); return;
        }
        watcher(b, lv, p, d, 9.0, 70.0);
    }
    private static void mago(HorrorBoss b, ServerLevel lv, ServerPlayer p, double d) {
        b.setNoAi(true); b.face(p);
        if (b.lifeTicks % 20 == 0) Fx.particles(lv, ParticleTypes.ENCHANT, b.getX(), b.getY() + 1.0, b.getZ(), 15, 1.2, 0.8, 1.2, 0.1);
        if (d < 8.0 && Progress.ctr(p, "sight.uomo_magico") >= 2 && !Progress.flag(p, "mago.pact") && canFight(p, lv, Kind.MAGO)) {
            b.say(p, Lore.taunt(b.getRandom(), Kind.MAGO, b.lvl())); b.setNoAi(false); b.startFight(p, lv); return;
        }
        if (d < 3.5 || (Fx.looking(p, b, 0.95) && ++b.gaze > 80)) vanish(b, lv, p, true);
    }
    private static void corrotto(HorrorBoss b, ServerLevel lv, ServerPlayer p, double d) {
        int tr = trust(p);
        b.getLookControl().setLookAt(p, 30.0f, 30.0f);
        if (d > 6.0 && b.lifeTicks % 10 == 0) b.getNavigation().moveTo(p, 0.9);
        if (b.lifeTicks == 20) sighting(b, p);
        if (b.lifeTicks % 400 == 0 && tr >= 0) b.say(p, tr > 50 ? "Mi fa piacere stare con te." : "Ciao... posso restare qui?");
        if (tr <= -40 && canFight(p, lv, Kind.CORROTTO)) { b.say(p, Lore.taunt(b.getRandom(), Kind.CORROTTO, b.lvl())); b.startFight(p, lv); return; }
        if (tr >= 80 && Config.ALLIANCES.get()) { Progress.setFlag(p, "corrotto.ally", true); Fx.grant(p, "corrotto_alleato"); helper(b, lv, p, 6.0f); }
    }
    private static void steve(HorrorBoss b, ServerLevel lv, ServerPlayer p, double d) {
        b.getLookControl().setLookAt(p, 30.0f, 30.0f);
        if (b.lifeTicks == 20) sighting(b, p);
        boolean truce = Progress.flag(p, "steve.truce") && Config.ALLIANCES.get();
        if (truce) { if (d > 7.0 && b.lifeTicks % 10 == 0) b.getNavigation().moveTo(p, 1.0); helper(b, lv, p, 6.0f); return; }
        if (d > 22.0 && b.lifeTicks % 20 == 0) b.getNavigation().moveTo(p, 0.8);
        else if (d < 9.0 && b.lifeTicks % 20 == 0) { Vec3 away = b.position().subtract(p.position()).normalize().scale(8.0).add(b.position()); b.getNavigation().moveTo(away.x, away.y, away.z, 0.7); }
        if (b.lifeTicks % 2400 == 1200 && !Fx.looking(p, b, 0.6)) {          // lascia un regalo quando non lo guardi
            ItemStack gift = switch (b.getRandom().nextInt(4)) { case 0 -> new ItemStack(Items.BREAD, 4); case 1 -> new ItemStack(Items.TORCH, 8); case 2 -> new ItemStack(Items.ARROW, 8); default -> new ItemStack(Items.APPLE, 2); };
            Containers.dropItemStack(lv, b.getX(), b.getY() + 0.5, b.getZ(), gift);
            Fx.bar(p, "Steve ha lasciato qualcosa per terra.");
        }
        int meet = Progress.ctr(p, "meet.steve");
        if (d < 12.0 && b.lifeTicks > 600 && meet >= 2 + Progress.level(p, Kind.STEVE) * 2 && canFight(p, lv, Kind.STEVE)) {
            b.say(p, "Una prova. Niente di personale."); b.startFight(p, lv);
        }
    }
    private static void e404(HorrorBoss b, ServerLevel lv, ServerPlayer p, double d) {
        if (b.lifeTicks % 30 == 0) { Fx.particles(lv, Fx.GREEN, b.getX(), b.getY() + 1.0, b.getZ(), 12, 0.4, 0.9, 0.4, 0.05); Fx.sound(lv, b.getX(), b.getY(), b.getZ(), ModSounds.GLITCH.get(), 0.3f, 1.0f); }
        if (d < 14.0 && Progress.ctr(p, "sight.entity_404") >= 2 && Progress.chapter(p) >= 5 && canFight(p, lv, Kind.ENTITY404)) {
            b.say(p, Lore.taunt(b.getRandom(), Kind.ENTITY404, b.lvl())); b.setNoAi(false); b.startFight(p, lv); return;
        }
        watcher(b, lv, p, d, 10.0, 30.0);
    }

    /** Alleato (Corrotto amichevole / Steve in tregua): attacca i mostri ostili vicini al giocatore. */
    private static void helper(HorrorBoss b, ServerLevel lv, ServerPlayer p, float dmg) {
        if (b.lifeTicks % 20 != 0) return;
        AABB box = p.getBoundingBox().inflate(12.0);
        List<Mob> foes = lv.getEntitiesOfClass(Mob.class, box, m -> m.getType().getCategory() == MobCategory.MONSTER && m.isAlive() && !(m instanceof HorrorBoss) && !(m instanceof Minion));
        if (foes.isEmpty()) return;
        Mob t = foes.get(0);
        b.getNavigation().moveTo(t, 1.2);
        if (b.distanceToSqr(t) < 9.0) { Fx.swing(b); Fx.hurt(t, b.damageSources().mobAttack(b), dmg); }
    }

    /** Colpo ricevuto durante la presenza. */
    public static void presenceHit(HorrorBoss b, ServerPlayer p, LivingIncomingDamageEvent e) {
        e.setCanceled(true);
        ServerLevel lv = (ServerLevel) b.level();
        if (p == null) return;
        switch (b.kind) {
            case OSSERVATORE, ENTITY404, CUSTODE -> vanish(b, lv, p, true);
            case CORROTTO -> {
                setTrust(p, trust(p) - 35);
                b.say(p, "Perché...? Cosa ti ho fatto?");
                Fx.grant(p, "corrotto_ferito");
                if (trust(p) <= -40 && canFight(p, lv, Kind.CORROTTO)) b.startFight(p, lv);
            }
            case STEVE -> {
                if (canFight(p, lv, Kind.STEVE)) { b.say(p, "Va bene. Una prova, allora."); b.startFight(p, lv); }
                else { b.say(p, "Ehi! Calmo."); b.tpNear(lv, p, 20.0); }
            }
            case MAGO -> { if (canFight(p, lv, Kind.MAGO)) { b.say(p, "Insolente!"); b.setNoAi(false); b.startFight(p, lv); } else vanish(b, lv, p, true); }
        }
    }

    // ------------------------------------------------------------ scelta del Custode (livello 4)
    private static void choiceTick(HorrorBoss b, ServerLevel lv) {
        b.fightTick++;
        ServerPlayer p = b.focusPlayer(lv);
        b.setNoAi(true);
        if (b.fightTick % 40 == 0) Fx.particles(lv, ParticleTypes.END_ROD, b.getX(), b.getY() + 1.0, b.getZ(), 4, 0.3, 0.7, 0.3, 0.01);
        if (p == null || b.fightTick > 6000) {
            if (p != null) Fx.say(p, Kind.CUSTODE, "Non decidi? Allora andrò via. Ci rivedremo.");
            b.discard();
        }
    }
    public static void choose(HorrorBoss b, ServerLevel lv, ServerPlayer p, boolean spare) {
        if (b.kind != Kind.CUSTODE || b.mode != HorrorBoss.CHOICE) return;
        Progress.setLevel(p, Kind.CUSTODE, 4);
        Fx.grant(p, "custode_supremo");
        Lore.unlock(p, "cus.4");
        if (spare) {
            Progress.setFlag(p, "custode.spared", true);
            Fx.grant(p, "custode_risparmiato"); Lore.unlock(p, "cus.5");
            Rewards.give(p, "frammento_occhio_bianco", 3);
            Fx.say(p, Kind.CUSTODE, "Mio fratello avrebbe fatto lo stesso... Ascolta: il Rituale non è una porta. È un limite. Non oltrepassarlo.");
        } else {
            Progress.setFlag(p, "custode.dead", true);
            Fx.grant(p, "custode_ucciso");
            Rewards.give(p, "spada_pallida", 1); Rewards.give(p, "occhio_bianco", 1);
            Fx.info(p, ChatFormatting.GRAY, "Il Custode si dissolve. Il rituale proibito non avrà più nessuno a ricordarlo.");
        }
        Fx.particles(lv, ParticleTypes.END_ROD, b.getX(), b.getY() + 1.0, b.getZ(), 60, 0.5, 1.0, 0.5, 0.1);
        b.discard();
    }
}
