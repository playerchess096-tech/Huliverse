package com.magialuama.horrorverse;

import java.util.*;
import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;

/** Lore del mondo (dal testo dell'autore) e battute delle entità. */
public final class Lore {
    private Lore() {}
    public record Entry(Kind kind, String title, String text) {}
    public static final LinkedHashMap<String, Entry> ENTRIES = new LinkedHashMap<>();
    private static void e(String id, Kind k, String t, String s) { ENTRIES.put(id, new Entry(k, t, s)); }
    static {
        e("oss.1", Kind.OSSERVATORE, "Primo sguardo", "«Non sono io che sono arrivato. Sei tu che sei entrato.» Qualcuno ti guarda da lontano e sparisce se lo fissi.");
        e("oss.2", Kind.OSSERVATORE, "Il mondo ricorda", "Il mondo sembra conservare la memoria di ogni tuo passo. E qualcuno la legge.");
        e("oss.3", Kind.OSSERVATORE, "Da molto prima", "Forse ti osservava già prima della tua prima casa, prima della prima notte. Non c'è modo di saperlo.");
        e("oss.4", Kind.OSSERVATORE, "Oscurità primordiale", "Una forma umanoide dagli occhi bianchi, fatta della stessa oscurità che c'era prima del mondo. Non spiega chi sia. Si diverte.");
        e("oss.5", Kind.OSSERVATORE, "Il gioco dell'attesa", "Alterna lunghe assenze a brevi apparizioni. Ogni tuo dubbio è un piccolo trionfo per lui.");
        e("ste.1", Kind.STEVE, "Un altro sopravvissuto", "Compare lontano dalla base, lascia piccoli doni e non dice una parola di troppo. Non è un nemico.");
        e("ste.2", Kind.STEVE, "Inviato o ultimo", "Forse è stato inviato a salvare l'umanità. Forse è l'ultimo essere umano rimasto dopo una guerra o una catastrofe.");
        e("ste.3", Kind.STEVE, "Ciò che resta", "Il mondo potrebbe essere ciò che resta dopo la scomparsa degli uomini. Qualcuno ha messo Steve al centro di tutto.");
        e("ste.4", Kind.STEVE, "Le due voci", "Le due entità dell'End Poem potrebbero averlo collocato qui, e tu vivi la storia attraverso un dispositivo. Oppure è solo un sogno. Nessuna risposta è confermata.");
        e("ste.5", Kind.STEVE, "Le prove", "Le sue prove non sono odio: sono l'unico modo che conosce per dirti 'sii pronto'. Chi supera la tregua trova un compagno.");
        e("cus.1", Kind.CUSTODE, "Occhi bianchi", "Figure immobili tra gli alberi, fulmini che non dovrebbero esserci. Ti misura prima di parlarti.");
        e("cus.2", Kind.CUSTODE, "Un fratello", "Nei suoi rituali compare un fratello perso in battaglia. Non è arrivato in tempo. Da allora è solo.");
        e("cus.3", Kind.CUSTODE, "Gli Occhi Bianchi", "Era un giocatore, un tempo. Ottenne il potere di una forza antica: gli Occhi Bianchi.");
        e("cus.4", Kind.CUSTODE, "Herobrine o Custode", "Nel suo universo non divenne Steve: divenne Herobrine, il Custode. Cercò vendetta per il fratello, uccise tutti e rimase solo.");
        e("cus.5", Kind.CUSTODE, "La mano tesa", "Risparmiarlo non è debolezza. È ciò che nessuno gli aveva mai concesso.");
        e("cus.6", Kind.CUSTODE, "Il limite", "Il Rituale Proibito non è una porta: è un limite. Oltrepassarlo ha un prezzo, e lui lo sa.");
        e("mag.1", Kind.MAGO, "Rune e libri", "Rune incise sui tronchi, libri senza autore, enigmi lasciati a metà: qualcuno sta sperimentando.");
        e("mag.2", Kind.MAGO, "Prima di Steve", "Uno stregone vissuto prima di Steve. Voleva solo evitare la fatica di vivere: cercava scorciatoie.");
        e("mag.3", Kind.MAGO, "L'avidità", "La magia gli ha dato ogni comodità e gli ha tolto il resto. È diventato avido, acido, instabile.");
        e("mag.4", Kind.MAGO, "Baba Yaga", "Ha l'aria di una vecchia strega delle fiabe, ma le sue colpe sono soltanto sue.");
        e("mag.5", Kind.MAGO, "Non del tutto malvagio", "Non è un mostro: è un uomo che ha smesso di ricordare quando la magia era curiosità e non pigrizia.");
        e("cor.1", Kind.CORROTTO, "Un viaggiatore", "Viene da un altro universo e ti saluta come un amico. È squisito, gentile, vuole solo compagnia.");
        e("cor.2", Kind.CORROTTO, "Ferite vecchie", "Altre persone gli hanno fatto del male prima che cambiasse universo. Non lo dimentica, ma non vuole mostrarlo.");
        e("cor.3", Kind.CORROTTO, "Segnali", "Silenzi improvvisi, ombre che arrivano prima di lui. Quando lo ferisci, qualcosa in lui si incrina.");
        e("cor.4", Kind.CORROTTO, "Degenerazione", "La corruzione non è un interruttore: è una ferita che si allarga ogni volta che qualcuno lo tratta male.");
        e("cor.5", Kind.CORROTTO, "Dio dell'Oscurità", "Il Dio dell'Oscurità è ciò che resta di una persona quando nessuno la tratta più da persona.");
        e("e404.1", Kind.ENTITY404, "Numeri verdi", "Numeri verdi in chat, un oggetto che non ricordi di aver spostato, un'ombra verde che dura un secondo.");
        e("e404.2", Kind.ENTITY404, "La skin", "Un ex dipendente di Mojang spaventava i giocatori con una skin. Poi un licenziamento, un ban, un gioco disinstallato.");
        e("e404.3", Kind.ENTITY404, "Il virus", "Un virus ha corrotto la skin, rendendola verde come Entity 303. Non ha inventato la rabbia: l'ha ereditata.");
        e("e404.4", Kind.ENTITY404, "Sadismo", "Entra nei mondi Survival e gioca con le tue emozioni. Si diverte a vederti soffrire.");
        e("e404.5", Kind.ENTITY404, "Sempre più vicino", "Ogni apparizione è più personale, più pericolosa, più difficile da contenere.");
        e("e404.6", Kind.ENTITY404, "Oltre i limiti", "La sua forma finale infrange i limiti del mondo. Nemmeno la Creativa è al sicuro.");
    }

    public static void unlock(ServerPlayer p, String id) {
        if (!ENTRIES.containsKey(id) || Progress.flag(p, "lore." + id)) return;
        Progress.setFlag(p, "lore." + id, true);
        Fx.info(p, ChatFormatting.GOLD, "✦ Nuova pagina nel Diario del Mondo: " + ENTRIES.get(id).title());
        if (Progress.addCtr(p, "lorecount", 1) >= ENTRIES.size()) Fx.grant(p, "lettore_diario");
    }
    public static void diary(ServerPlayer p) {
        Fx.info(p, ChatFormatting.GOLD, "══ Diario del Mondo ══");
        int n = 0;
        for (Map.Entry<String, Entry> en : ENTRIES.entrySet()) {
            if (!Progress.flag(p, "lore." + en.getKey())) continue;
            n++;
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(en.getValue().kind().nameIt + " — " + en.getValue().title() + ": ").withStyle(en.getValue().kind().chat)
                    .append(net.minecraft.network.chat.Component.literal(en.getValue().text()).withStyle(ChatFormatting.GRAY)));
        }
        if (n == 0) Fx.info(p, ChatFormatting.GRAY, "Le pagine sono ancora vuote. Qualcuno ti sta osservando, ma non l'ha ancora scritto.");
        else Fx.info(p, ChatFormatting.DARK_GRAY, "(" + n + "/" + ENTRIES.size() + " pagine)");
    }

    // ---------- battute
    private static final Map<String, String[]> TAUNTS = new HashMap<>();
    static {
        TAUNTS.put("custode.1", new String[]{"Dimostra di essere degno.", "Non è la forza che cerco.", "Questo è solo un decimo di ciò che sono."});
        TAUNTS.put("custode.2", new String[]{"Toccami, se riesci.", "Mio fratello era più veloce di te.", "Sopravvivere non basta."});
        TAUNTS.put("custode.3", new String[]{"Il fulmine non perdona.", "Anch'io avevo un fratello. Anche tu l'avrai perso?", "Senti il peso dello scettro?"});
        TAUNTS.put("custode.4", new String[]{"Sono rimasto solo. Io sono il Custode.", "Uccidi o risparmia: nessuno mi ha mai lasciato scegliere.", "Gli Occhi Bianchi vedono tutto."});
        TAUNTS.put("custode.5", new String[]{"Hai violato il limite.", "Non c'è ritorno da qui.", "Ora capisci perché ero solo?"});
        TAUNTS.put("corrotto.1", new String[]{"Non… non voltarti.", "Mi dispiace. Non volevo.", "Perché mi guardi così?"});
        TAUNTS.put("corrotto.2", new String[]{"Stai peggiorando le cose.", "Il buio c'era prima di me.", "Avevo solo chiesto un amico."});
        TAUNTS.put("corrotto.3", new String[]{"Guarda cosa mi hai fatto.", "Le mie mani non sono più mie.", "Perché tutti mi fanno questo?"});
        TAUNTS.put("corrotto.4", new String[]{"Ti avevo avvisato.", "Prendo ciò che è tuo. Come hanno fatto a me.", "Non ti fidare di ciò che vedi."});
        TAUNTS.put("corrotto.5", new String[]{"Io sono il buio. Voi mi avete fatto così.", "La tua anima è mia.", "Purificami, se ne hai il coraggio."});
        TAUNTS.put("entity_404.1", new String[]{"lol. ti sei spaventato?", "Benvenuto nel mio mondo.", "Errore 404: la tua pace non è stata trovata."});
        TAUNTS.put("entity_404.2", new String[]{"Questa pelle era un regalo. Poi me l'hanno tolta.", "Ti piace il verde?", "Non fidarti di quelle luci."});
        TAUNTS.put("entity_404.3", new String[]{"La piaga si diffonde. Ti piace?", "Hanno disinstallato un uomo. Io sono ciò che resta.", "Mi diverto, sai."});
        TAUNTS.put("entity_404.4", new String[]{"Guardami.", "Ora sai chi sono.", "Soffri. Era questo che volevo."});
        TAUNTS.put("entity_404.5", new String[]{"Il mio cucciolo ha fame.", "Non ti lascerò uscire.", "Sei nella mia tana."});
        TAUNTS.put("entity_404.6", new String[]{"Convochi i boss? Io li possiedo.", "Sempre più difficile da contenere, vero?", "Il cielo è mio."});
        TAUNTS.put("entity_404.7", new String[]{"Il mondo finisce qui.", "Non hai più regole.", "Hai cinque statue. Io ho il tempo."});
        TAUNTS.put("uomo_magico.1", new String[]{"Una prova, giovane. Solo una prova.", "Perché faticare, quando puoi incantare?", "Non guardare le mie mani."});
        TAUNTS.put("uomo_magico.2", new String[]{"Cosa è vero? Cosa è reale?", "Ho fatto tutto questo per non alzarmi dal letto.", "Indovina quale sono io."});
        TAUNTS.put("uomo_magico.3", new String[]{"Le rune sono mie. Tutte mie.", "Avidità? Chiamala comodità.", "Interrompi il rito e ne pagherai il prezzo."});
        TAUNTS.put("uomo_magico.4", new String[]{"Ogni energia ha un prezzo, e io l'ho già pagato.", "Il tuo acciaio non ha memoria. La mia magia sì.", "Cadi."});
        TAUNTS.put("uomo_magico.5", new String[]{"Io SONO la magia.", "Distruggi il bastone e distruggerai anche me.", "Cinque rune. Cinque sciocchezze."});
        TAUNTS.put("steve.1", new String[]{"...", "Ho lasciato qualcosa per te.", "Non sono il tuo nemico."});
        TAUNTS.put("steve.2", new String[]{"Hai usato di nuovo lo stesso trucco.", "Questa è una prova, non una guerra.", "Non sei l'unico che impara."});
        TAUNTS.put("steve.3", new String[]{"Hai costruito bene. Vediamo se sai difenderlo.", "Questa volta ero preparato.", "Il mondo non perdona chi non è pronto."});
        TAUNTS.put("steve.4", new String[]{"Non basta avere una spada migliore.", "Sei diventato più forte. Anch'io.", "Trova i miei depositi, se puoi."});
        TAUNTS.put("steve.5", new String[]{"Sopravvivenza. Strategia. Combattimento.", "Se hai la mia stima, lo vedrò alla fine.", "Qualcuno doveva essere pronto."});
        TAUNTS.put("osservatore.1", new String[]{"Non sono io che sono arrivato. Sei tu che sei entrato.", "...", "Ti ho visto."});
    }
    public static String taunt(RandomSource r, Kind k, int level) {
        String[] a = TAUNTS.get(k.id + "." + level);
        if (a == null) a = TAUNTS.get(k.id + ".1");
        return a == null ? "..." : a[r.nextInt(a.length)];
    }
    public static String levelName(Kind k, int l) {
        return switch (k) {
            case CUSTODE -> new String[]{"", "Il Guardiano", "La Prova del Contatto", "Lo Scettro Elettrico", "Il Custode Supremo", "Il Rituale Proibito"}[Math.min(l, 5)];
            case CORROTTO -> new String[]{"", "Il Viaggiatore", "L'Oscurità Crescente", "La Corruzione", "Il Corrotto Indebolito", "Il Dio dell'Oscurità"}[Math.min(l, 5)];
            case ENTITY404 -> new String[]{"", "Il Troll", "La Skin Corrotta", "La Piaga", "Il Demone Verde", "Il Cucciolo di Entity 404", "Il Signore della Piaga", "L'Apocalisse Verde"}[Math.min(l, 7)];
            case MAGO -> new String[]{"", "L'Apprendista", "Il Mago delle Illusioni", "Il Signore degli Incantesimi", "L'Arcimago", "Il Dio della Magia"}[Math.min(l, 5)];
            case STEVE -> new String[]{"", "Lo Sconosciuto", "Il Sopravvissuto", "Il Maestro di Minecraft", "Il Veterano", "Il Giocatore Perfetto"}[Math.min(l, 5)];
            case OSSERVATORE -> "Lo Sguardo";
        };
    }
}
