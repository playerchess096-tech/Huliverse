package com.magialuama.horrorverse;

import java.util.EnumMap;
import java.util.function.Supplier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    private ModEntities() {}
    public static final Supplier<EntityType<HorrorBoss>> CUSTODE = boss("custode", Kind.CUSTODE, 0.6f, 1.95f);
    public static final Supplier<EntityType<HorrorBoss>> CORROTTO = boss("corrotto", Kind.CORROTTO, 0.6f, 1.95f);
    public static final Supplier<EntityType<HorrorBoss>> ENTITY404 = boss("entity_404", Kind.ENTITY404, 0.6f, 1.95f);
    public static final Supplier<EntityType<HorrorBoss>> MAGO = boss("uomo_magico", Kind.MAGO, 0.6f, 1.95f);
    public static final Supplier<EntityType<HorrorBoss>> STEVE = boss("steve", Kind.STEVE, 0.6f, 1.95f);
    public static final Supplier<EntityType<HorrorBoss>> OSSERVATORE = boss("osservatore", Kind.OSSERVATORE, 0.6f, 1.95f);
    public static final EnumMap<MinionType, Supplier<EntityType<Minion>>> MINIONS = new EnumMap<>(MinionType.class);

    static {
        for (MinionType t : MinionType.values()) {
            MINIONS.put(t, Reg.ENTITIES.registerEntityType(t.id, (type, lv) -> new Minion(type, lv, t), MobCategory.MONSTER,
                    b -> b.sized(t.w, t.h).clientTrackingRange(10)));
        }
    }

    private static Supplier<EntityType<HorrorBoss>> boss(String id, Kind k, float w, float h) {
        return Reg.ENTITIES.registerEntityType(id, (type, lv) -> new HorrorBoss(type, lv, k), MobCategory.MONSTER,
                b -> b.sized(w, h).clientTrackingRange(12).fireImmune());
    }
    public static EntityType<HorrorBoss> of(Kind k) {
        return switch (k) { case CUSTODE -> CUSTODE.get(); case CORROTTO -> CORROTTO.get(); case ENTITY404 -> ENTITY404.get();
            case MAGO -> MAGO.get(); case STEVE -> STEVE.get(); case OSSERVATORE -> OSSERVATORE.get(); };
    }
    public static void init() { }
}
