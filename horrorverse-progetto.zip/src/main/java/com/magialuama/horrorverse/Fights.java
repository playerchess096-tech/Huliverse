package com.magialuama.horrorverse;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * Copioni delle boss fight. Contatori generici di HorrorBoss (a, b, c, d, phase) per livello:
 * Custode L1 a=ondata | L2 a=contatti | L5 a=sequenza, b=perle valide, c=fine occhi fantasma
 * Corrotto L3-L5 a=artefatti usati, c=anima (L5), d=finestra finale | Entity404 L1 a=ondata,b=tick,c=fine | L3 a=piaga,d=sfida,b=scadenza,c=colpi
 * Entity404 L6 d=bonus (0/1/2), c=fiducia clone | L7 a=statue, c=timer | Mago a=rune/generatori, b=scadenza | Steve a=depositi, b=ultima fuga, c=scudo, d=fuga fino a
 */
final class Fights {
    private Fights() {}

    // ================================================================= utilità
    static void vanilla(HorrorBoss b, ServerLevel lv, ServerPlayer p, EntityType<? extends Mob> t, int n) {
        for (int i = 0; i < n; i++) {
            if (b.minions.size() >= Config.MAX_MINIONS.get()) return;
            Mob m = t.create(lv, EntitySpawnReason.EVENT);
            if (m == null) continue;
            Vec3 v = Fx.ring(lv, p.position(), 6.0, 11.0);
            m.setPos(v.x, v.y, v.z); m.setTarget(p); lv.addFreshEntity(m); b.minions.add(m.getUUID());
        }
    }
    static int place(HorrorBoss b, ServerLevel lv, ServerPlayer p, Block blk, int n, double rmin, double rmax) {
        int placed = 0;
        for (int tries = 0; tries < 80 && placed < n; tries++) {
            Vec3 v = Fx.ring(lv, p.position(), rmin, rmax);
            BlockPos bp = BlockPos.containing(v.x, v.y, v.z);
            if (lv.getBlockState(bp).isAir() && !lv.getBlockState(bp.below()).isAir() && lv.getFluidState(bp).isEmpty()) {
                lv.setBlock(bp, blk.defaultBlockState(), 3); b.marks.add(bp); placed++;
            }
        }
        return placed;
    }
    static String dir(Vec3 from, BlockPos to) {
        double dx = to.getX() + 0.5 - from.x, dz = to.getZ() + 0.5 - from.z;
        if (Math.abs(dx) > Math.abs(dz)) return dx > 0 ? "est" : "ovest";
        return dz > 0 ? "sud" : "nord";
    }
    static void meteors(HorrorBoss b, ServerLevel lv, ServerPlayer p, int n, double dmg) {
        for (int i = 0; i < n; i++) { Vec3 v = Fx.ring(lv, p.position(), 0.0, 7.0); b.pending.add(new double[]{v.x, v.y, v.z, b.fightTick + 40, dmg}); }
    }
    static void corrupt(ServerPlayer p, int n) {
        int done = 0;
        for (int tries = 0; tries < 40 && done < n; tries++) {
            ItemStack s = p.getInventory().getItem(p.getRandom().nextInt(36));
            if (s.isEmpty() || Fx.marked(s, "hv_corrupt") || s.is(ModItems.ARTEFATTO_ANTIOSCURITA.get()) || s.is(ModItems.CRISTALLO_PURIFICAZIONE.get())) continue;
            Fx.mark(s, "hv_corrupt"); done++;
        }
        Fx.afflict(p, ModEffects.CORRUZIONE, (int) (600 * Config.EFFECT_MULT.get()), 0);
        if (done > 0) Fx.info(p, ChatFormatting.DARK_PURPLE, "Qualcosa nel tuo zaino si è oscurato e non risponde più. Serve la purificazione.");
    }
    static void steal(HorrorBoss b, ServerPlayer p) {
        for (int tries = 0; tries < 20; tries++) {
            ItemStack s = p.getInventory().getItem(p.getRandom().nextInt(9));
            if (s.isEmpty() || Fx.marked(s, "hv_locked") || s.is(ModItems.ARTEFATTO_ANTIOSCURITA.get())) continue;
            Fx.mark(s, "hv_locked"); b.setItemSlot(EquipmentSlot.MAINHAND, s.copy());
            Fx.info(p, ChatFormatting.DARK_PURPLE, "Ti ha sottratto «" + s.getHoverName().getString() + "»: resta bloccato finché lo scontro non finisce.");
            return;
        }
    }
    static void decoys(ServerPlayer p) {
        int n = 0;
        for (int i = 0; i < 36 && n < 8; i++) if (p.getInventory().getItem(i).isEmpty()) { p.getInventory().setItem(i, new ItemStack(ModItems.OCCHIO_FANTASMA.get())); n++; }
    }
    static void givePearls(ServerPlayer p) {
        int have = 0;
        for (int i = 0; i < 36; i++) { ItemStack s = p.getInventory().getItem(i); if (Fx.marked(s, "hv_pearl")) have += s.getCount(); }
        if (have >= 2) return;
        ItemStack s = new ItemStack(Items.ENDER_PEARL, 2 - have); Fx.mark(s, "hv_pearl"); Fx.give(p, s);
        Fx.info(p, ChatFormatting.WHITE, "Il Custode ti ha lasciato due perle valide: colpiscilo mentre è fermo.");
    }
    static void depots(HorrorBoss b, ServerLevel lv, ServerPlayer p, int n) {
        for (int i = 0, ok = 0; i < 60 && ok < n; i++) {
            Vec3 v = Fx.ring(lv, p.position(), 22.0, 40.0);
            BlockPos bp = BlockPos.containing(v.x, v.y, v.z);
            if (!lv.getBlockState(bp).isAir() || lv.getBlockState(bp.below()).isAir()) continue;
            lv.setBlock(bp, Blocks.CHEST.defaultBlockState(), 3);
            BlockEntity be = lv.getBlockEntity(bp);
            if (be instanceof Container c) { c.setItem(0, new ItemStack(Items.IRON_INGOT, 6)); c.setItem(1, new ItemStack(Items.COOKED_BEEF, 6)); c.setItem(2, new ItemStack(Items.ENDER_PEARL, 2)); c.setItem(3, new ItemStack(Items.GOLDEN_APPLE, 1)); }
            b.depots.add(bp); ok++;
        }
        b.a = b.depots.size();
    }
    static int intact(HorrorBoss b, ServerLevel lv) { int n = 0; for (BlockPos d : b.depots) if (lv.getBlockState(d).is(Blocks.CHEST)) n++; return n; }

    // ================================================================= avvio
    static void onStart(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        int L = b.lvl();
        switch (b.kind) {
            case CUSTODE -> {
                if (L == 1) b.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.WOODEN_SWORD));
                if (L >= 3) b.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.SCETTRO_ELETTRICO.get()));
                if (L == 5) { Fx.title(p, "IL LIMITE È STATO VIOLATO", "Non c'è ritorno."); givePearls(p); }
            }
            case MAGO -> {
                b.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.BASTONE_MAGO.get()));
                if (L == 3) { b.a = place(b, lv, p, ModBlocks.RUNA_PILASTRO.get(), 3, 9.0, 14.0); b.say(p, "Tre rune alimentano la mia magia. Trovale, se osi."); }
                if (L == 4) { b.a = place(b, lv, p, ModBlocks.GENERATORE_ARCANO.get(), 3, 8.0, 13.0); b.say(p, "La mia energia non finisce mai."); }
                if (L == 5) { b.a = place(b, lv, p, ModBlocks.RUNA_PILASTRO.get(), 5, 9.0, 15.0); b.say(p, "Cinque rune antiche. Cinque tentazioni."); }
            }
            case STEVE -> {
                b.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(L == 1 ? Items.WOODEN_SWORD : L == 2 ? Items.IRON_SWORD : L == 3 ? Items.DIAMOND_SWORD : Items.NETHERITE_SWORD));
                if (L >= 2) b.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
                if (L == 3) depots(b, lv, p, 1);
                if (L == 4) { depots(b, lv, p, 3); b.say(p, "Ho nascosto le mie scorte. Distruggile prima che mi prepari."); }
                if (L == 5) b.phase = 0;
            }
            case ENTITY404 -> {
                if (L == 5) {
                    b.minion(lv, MinionType.CUCCIOLO_CORROTTO, p.getX() + 6, Fx.groundY(lv, p.getX() + 6, p.getZ()), p.getZ());
                    for (int i = 0; i < 3; i++) { Vec3 v = Fx.ring(lv, p.position(), 9.0, 13.0); b.minion(lv, MinionType.SENTINELLA_VERDE, v.x, v.y, v.z); }
                }
                if (L == 7) { b.c = 14400; lv.getServer().setWeatherParameters(0, 24000, true, true); Fx.title(p, "APOCALISSE VERDE", "Cinque Statue del Destino. Dodici minuti."); }
            }
            default -> { }
        }
    }

    // ================================================================= tick
    static void fight(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        if (b.fightTick % 600 == 300 && b.kind != Kind.STEVE) b.sayRandom(p);
        switch (b.kind) {
            case CUSTODE -> custode(b, lv, p);
            case CORROTTO -> corrotto(b, lv, p);
            case ENTITY404 -> e404(b, lv, p);
            case MAGO -> mago(b, lv, p);
            case STEVE -> steve(b, lv, p);
            default -> b.end(false, p);
        }
    }

    // ------------------------------------------------------------------ CUSTODE
    private static void custode(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        int L = b.lvl(), t = b.fightTick;
        float hp = b.getHealth() / b.getMaxHealth();
        switch (L) {
            case 1 -> {
                if (b.a == 0 && t > 40) { b.a = 1; b.wave(lv, p, MinionType.ZOMBIE_BIANCO, 3); }
                else if (b.a == 1 && hp < 0.66f) { b.a = 2; b.wave(lv, p, MinionType.ZOMBIE_BIANCO, 4); }
                else if (b.a == 2 && hp < 0.33f) { b.a = 3; b.wave(lv, p, MinionType.ZOMBIE_BIANCO, 5); }
                if (b.every(90)) b.tpNear(lv, p, 6.0);
                b.chase(p, 1.1); b.melee(p, 2.5, 20);
            }
            case 2 -> {
                b.face(p);
                if (b.every(100)) b.tpNear(lv, p, 8.0);
                if (b.alive(lv, MinionType.ZOMBIE_BIANCO) < 1 && b.every(200)) b.wave(lv, p, MinionType.ZOMBIE_BIANCO, 1);
                if (b.every(160) && Config.SHAKE.get()) Fx.afflict(p, MobEffects.DARKNESS, 60, 0);
                if (t % 20 == 0) Fx.bar(p, "Contatti validi: " + b.a + "/3 — clic destro sul Custode");
                if (b.a >= 3) b.end(true, p);
            }
            case 3 -> {
                if (b.phase == 0 && hp < 0.5f) { b.phase = 1; Fx.bolt(lv, b.getX(), b.getY(), b.getZ()); b.say(p, "Lo scettro si risveglia!"); }
                int f = b.phase + 1;
                if (b.every(70 / f)) b.strike(lv, p, 4.0f);
                if (b.every(160)) { MinionType[] ts = {MinionType.CAVALIERE_FULMINE, MinionType.GUARDIANO_PALLIDO, MinionType.ZOMBIE_BIANCO}; b.wave(lv, p, ts[b.getRandom().nextInt(3)], 1 + f); }
                if (b.every(240)) b.zone(lv, p.getX(), p.getY(), p.getZ(), 3.5, 120, 2.0);
                if (b.every(200)) Fx.afflict(p, MobEffects.SLOWNESS, 80, 0);
                if (b.every(140)) b.tpBehind(lv, p, 3.0);
                b.chase(p, 1.0 + 0.1 * f); b.melee(p, 2.5, 20);
            }
            case 4 -> {
                if (b.phase == 0 && hp < 0.66f) { b.phase = 1; vanilla(b, lv, p, EntityTypes.SKELETON, 3); b.say(p, "Ancora."); }
                if (b.phase == 1 && hp < 0.33f) { b.phase = 2; vanilla(b, lv, p, EntityTypes.ZOMBIE, 4); b.say(p, "Gli Occhi Bianchi vedono tutto."); }
                if (b.every(60 - 10 * b.phase)) b.strike(lv, p, 5.0f);
                if (b.every(400)) { vanilla(b, lv, p, EntityTypes.SPIDER, 2); b.wave(lv, p, MinionType.CAVALIERE_FULMINE, 1); }
                if (b.every(150)) b.beam(lv, p, 4.0f, ParticleTypes.ELECTRIC_SPARK);
                if (b.every(220)) b.zone(lv, p.getX(), p.getY(), p.getZ(), 4.0, 140, 2.5);
                if (b.every(170)) b.tpBehind(lv, p, 2.5);
                if (b.every(250)) Fx.afflict(p, MobEffects.WEAKNESS, 100, 0);
                b.chase(p, 1.15); b.melee(p, 2.6, 18);
            }
            default -> {   // L5: perle dell'End
                int seq = t % 260;
                if (t % 20 == 0) Fx.bar(p, "Perle valide: " + b.b + "/" + Config.PEARL_HITS.get() + (b.a == 2 ? "  — COLPISCILO ORA" : ""));
                if (seq == 0) { b.a = 1; b.window = false; b.sayRandom(p); }
                if (b.a == 1 && seq % 25 == 0 && seq < 150) { b.tpNear(lv, p, 7.0); Fx.particles(lv, ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 30, 1, 1, 1, 0.5); }
                if (seq == 150) { b.a = 2; b.tpNear(lv, p, 6.0); b.setWindow(lv, 100); givePearls(p); }
                if (b.a == 2) { b.getNavigation().stop(); b.face(p); }
                if (seq == 250) b.a = 0;
                if (b.every(300)) vanilla(b, lv, p, EntityTypes.ENDERMAN, 3);
                if (b.every(420)) { decoys(p); b.c = t + 200; Fx.info(p, ChatFormatting.WHITE, "Il tuo zaino si riempie di occhi che non esistono..."); }
                if (b.c > 0 && t > b.c) { Fx.removeDecoys(p); b.c = 0; }
                if (b.every(330)) Fx.push(p, 0.0, 1.1, 0.0);
                if (b.every(500)) b.wave(lv, p, MinionType.OMBRA_CUSTODE, 2);
                if (b.every(200)) b.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
                if (t % 200 == 100) b.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
                if (b.every(180)) b.strike(lv, p, 3.0f);
                if (b.a != 2) b.melee(p, 2.6, 24);
                if (b.b >= Config.PEARL_HITS.get()) { Fx.removeDecoys(p); b.end(true, p); }
            }
        }
    }
    static void touch(HorrorBoss b, ServerPlayer p) {
        ServerLevel lv = (ServerLevel) b.level();
        if (b.tickCount - b.lastHit < 30) return;     // contatto continuo = un solo contatto
        b.lastHit = b.tickCount; b.a++;
        Fx.particles(lv, ParticleTypes.END_ROD, b.getX(), b.getY() + 1.0, b.getZ(), 30, 0.4, 0.8, 0.4, 0.1);
        Fx.sound(lv, b.getX(), b.getY(), b.getZ(), ModSounds.BELL_TOLL.get(), 0.8f, 1.2f);
        if (b.a < 3) { b.say(p, "Uno... " + (b.a == 1 ? "ancora due." : "ancora uno.")); b.tpNear(lv, p, 10.0); }
    }
    static void pearlHit(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        b.b++;
        Fx.sound(lv, b.getX(), b.getY(), b.getZ(), ModSounds.TELEPORT_BLIP.get(), 1.0f, 0.6f);
        Fx.particles(lv, ParticleTypes.PORTAL, b.getX(), b.getY() + 1, b.getZ(), 40, 0.5, 1, 0.5, 0.5);
        Fx.bar(p, "Perla valida! " + b.b + "/" + Config.PEARL_HITS.get());
    }

    // ------------------------------------------------------------------ CORROTTO
    private static void corrotto(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        int L = b.lvl(), t = b.fightTick;
        b.setVariant(L >= 5 ? 2 : 1);
        switch (L) {
            case 1, 2 -> {
                int dur = L == 1 ? 1800 : 2400;
                b.getNavigation().stop(); b.face(p);
                if (b.every(40) && b.alive(lv, MinionType.STATUA_VIVENTE) < (L == 1 ? 3 : 4)) { Vec3 v = Fx.ring(lv, p.position(), 12.0, 18.0); b.minion(lv, MinionType.STATUA_VIVENTE, v.x, v.y, v.z); }
                if (b.every(200) && Config.SHAKE.get()) Fx.afflict(p, MobEffects.DARKNESS, 100, 0);
                if (L == 2) {
                    if (b.every(120)) { Vec3 v = Fx.ring(lv, p.position(), 3.0, 9.0); b.tempBlock(lv, BlockPos.containing(v.x, v.y, v.z), ModBlocks.BLOCCO_OSCURO.get().defaultBlockState()); }
                    if (lv.getBlockState(p.blockPosition().below()).is(ModBlocks.BLOCCO_OSCURO.get()) && t % 20 == 0) Fx.afflict(p, MobEffects.WITHER, 60, 0);
                    if (b.every(160)) { Vec3 v = Fx.ring(lv, p.position(), 10.0, 18.0); Fx.particles(lv, ParticleTypes.SQUID_INK, v.x, v.y + 1.5, v.z, 10, 0.3, 0.2, 0.3, 0.0); Fx.sound(lv, v.x, v.y, v.z, ModSounds.WHISPER_B.get(), 0.7f, 0.8f); }
                    if (b.every(500) && b.alive(lv, MinionType.OCCHIO_ERRANTE) < 2) b.wave(lv, p, MinionType.OCCHIO_ERRANTE, 1);
                }
                if (t % 20 == 0) Fx.bar(p, "Sopravvivi: " + Math.max(0, (dur - t) / 20) + " s — le statue si muovono quando non le guardi");
                if (t >= dur) b.end(true, p);
            }
            case 3 -> {
                b.chase(p, 0.95); b.melee(p, 2.5, 30);
                if (b.every(300)) corrupt(p, 2);
                if (b.every(220)) b.wave(lv, p, b.getRandom().nextBoolean() ? MinionType.OMBRA_DIVORATRICE : MinionType.CAVALIERE_OSCURO, 1);
                if (b.every(120) && b.alive(lv, MinionType.STATUA_VIVENTE) < 2) b.wave(lv, p, MinionType.STATUA_VIVENTE, 1);
                if (b.every(500) && !b.window) b.say(p, "L'artefatto... usalo quando sono vicino!");
                if (t % 20 == 0) Fx.bar(p, b.window ? "VULNERABILE!" : "Usa l'Artefatto Anti-Oscurità vicino a lui");
            }
            case 4 -> {
                b.chase(p, 1.2); b.melee(p, 2.5, 18);
                if (t % 500 == 100) b.setWindow(lv, 160);
                if (b.every(300)) steal(b, p);
                if (b.every(80) && !b.window) b.beam(lv, p, 4.0f, ParticleTypes.SOUL_FIRE_FLAME);
                if (b.every(450)) b.wave(lv, p, MinionType.CLONE_INCOMPLETO, Math.min(2, Config.MAX_CLONES.get()));
                if (t > 2400) { b.say(p, "Mi stanchi. Me ne vado."); b.end(false, p); }
            }
            default -> {
                if (b.every(20)) {
                    if (b.distanceTo(p) < 24.0) b.c += 2 + (Fx.looking(p, b, 0.8) ? 1 : 0);
                    Fx.bar(p, "Anima: " + b.c + "%  —  Artefatti usati: " + b.a + "/2");
                }
                if (b.c >= 100) soulLost(b, lv, p);
                if (b.every(400)) { Vec3 v = Fx.ring(lv, p.position(), 2.0, 5.0); net.minecraft.world.Containers.dropItemStack(lv, v.x, v.y + 1, v.z, new ItemStack(ModItems.MELA_OSCURA.get())); Fx.info(p, ChatFormatting.DARK_PURPLE, "Una mela oscura è rotolata ai tuoi piedi. Non mangiarla."); }
                if (b.every(90)) b.beam(lv, p, 5.0f, ParticleTypes.SOUL_FIRE_FLAME);
                if (b.every(500)) b.wave(lv, p, MinionType.FRAMMENTO_ANIMA, 3);
                if (b.every(700)) corrupt(p, 1);
                if (b.a >= 2 && b.d == 0) { b.d = 1; b.setWindow(lv, 500); b.say(p, "Ora! Colpiscilo!"); }
                if (b.d == 1 && !b.window) { b.a = 0; b.d = 0; }
                b.chase(p, 1.25); b.melee(p, 2.6, 16);
            }
        }
    }
    static void artifact(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        int L = b.lvl();
        Fx.purify(p);
        Fx.particles(lv, ParticleTypes.END_ROD, b.getX(), b.getY() + 1.0, b.getZ(), 50, 0.6, 1.0, 0.6, 0.2);
        if (L == 3) { b.setWindow(lv, 300); b.a++; b.say(p, "Quella luce... brucia!"); }
        else if (L == 4) { b.setWindow(lv, 140); b.say(p, "Smettila!"); }
        else if (L >= 5) {
            if (p.getRandom().nextFloat() < 0.25f) b.say(p, "L'oscurità divora l'artefatto.");
            else { b.c = Math.max(0, b.c - 35); b.a++; b.say(p, "No... non così..."); }
        }
    }
    private static void soulLost(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        if (Config.PERMADEATH.get()) {
            Progress.setFlag(p, "corrotto.lost", true);
            p.setGameMode(net.minecraft.world.level.GameType.SPECTATOR);
            Fx.title(p, "ANIMA ASSORBITA", "Servirà un rituale per tornare (/horror recupera)");
        } else {
            Fx.afflict(p, MobEffects.WEAKNESS, 6000, 1); Fx.afflict(p, MobEffects.SLOWNESS, 3000, 0);
            Fx.title(p, "ANIMA CORROTTA", "Il Dio dell'Oscurità ti ha lasciato vivere... per ora");
        }
        b.end(false, p);
    }

    // ------------------------------------------------------------------ ENTITY 404
    private static void waveN(HorrorBoss b, ServerLevel lv, ServerPlayer p, int n) {
        b.a = n; b.b = b.fightTick;
        switch (n) { case 1 -> b.wave(lv, p, MinionType.ZOMBIE_VERDE, 4); case 2 -> b.wave(lv, p, MinionType.SCHELETRO_CORROTTO, 3); default -> b.wave(lv, p, MinionType.CREEPER_INFETTO, 3); }
    }
    private static void e404(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        int L = b.lvl(), t = b.fightTick;
        b.setVariant(0);
        switch (L) {
            case 1 -> {
                b.face(p);
                if (b.every(100)) b.tpNear(lv, p, 12.0);
                if (b.a == 0 && t > 40) waveN(b, lv, p, 1);
                else if (b.a >= 1 && b.a <= 2 && b.aliveAll(lv) == 0 && t - b.b > 80) waveN(b, lv, p, b.a + 1);
                else if (b.a == 3 && b.aliveAll(lv) == 0) { if (b.c == 0) b.c = t + 300; else if (t > b.c) { b.say(p, "Uffa. Ti ho annoiato abbastanza."); b.end(true, p); } }
                if (b.every(400)) { BlockPos feet = p.blockPosition(); b.tempBlock(lv, feet, Blocks.COBWEB.defaultBlockState()); b.say(p, "Oops."); }
                if (t % 20 == 0) Fx.bar(p, "Ondata " + Math.max(1, b.a) + "/3");
            }
            case 2 -> {
                b.face(p);
                if (b.every(140)) b.tpNear(lv, p, 10.0);
                if (b.every(10)) Fx.particles(lv, Fx.GREEN, p.getX(), p.getY() + 0.5, p.getZ(), 6, 1.5, 0.3, 1.5, 0.02);
                if (b.every(400)) b.wave(lv, p, MinionType.CLONE_IMPERFETTO, Math.min(2, Config.MAX_CLONES.get()));
                if (b.every(240) && b.c < 6) { b.c++; Fx.info(p, ChatFormatting.GREEN, "404 " + (100 + p.getRandom().nextInt(900)) + " 404"); Fx.sound(lv, p.getX(), p.getY(), p.getZ(), ModSounds.GLITCH.get(), 0.6f, 1.0f); }
                if (b.every(500)) { Vec3 v = Fx.ring(lv, p.position(), 14.0, 22.0); Fx.particles(lv, Fx.GREEN, v.x, v.y + 1, v.z, 30, 0.4, 1.0, 0.4, 0.05); }
                if (t % 20 == 0) Fx.bar(p, "Resisti: " + Math.max(0, (3000 - t) / 20) + " s");
                if (t >= 3000) { b.say(p, "Interessante. Sei più duro di quanto pensassi."); b.end(true, p); }
            }
            case 3 -> {
                if (b.every(100) && b.a < 10) b.a++;
                if (b.every(60)) Fx.particles(lv, Fx.GREEN, p.getX(), p.getY() + 0.5, p.getZ(), 4 + b.a * 3, 4.0, 0.5, 4.0, 0.02);
                if (b.every(200)) b.wave(lv, p, MinionType.ZOMBIE_VERDE, 1 + b.a / 4);
                if (b.every(40) && b.a >= 4) Fx.afflict(p, ModEffects.PIAGA, 120, 0);
                if (b.every(400)) theft(b, lv, p);
                if (t % 600 == 300) b.setWindow(lv, 200);
                if (b.a >= 6 && b.d == 0) { b.d = 1; b.b = t + 600; b.c = 0; b.say(p, "Sfida: colpiscimi 5 volte con una spada di ferro, in 30 secondi."); }
                if (b.d == 1 && t > b.b) { b.d = 2; b.a = Math.min(10, b.a + 3); b.say(p, "Troppo lento."); }
                if (b.every(20)) Fx.bar(p, "Piaga: " + b.a + "/10" + (b.d == 1 ? "   Sfida: " + b.c + "/5" : ""));
                b.chase(p, 1.1); b.melee(p, 2.5, 20);
            }
            case 4 -> {
                b.setVariant(1);
                b.chase(p, 1.2); b.melee(p, 2.6, 16);
                if (b.every(120) && b.alive(lv, MinionType.TENTACOLO_VIVENTE) < 3) { Vec3 v = Fx.ring(lv, p.position(), 4.0, 8.0); b.minion(lv, MinionType.TENTACOLO_VIVENTE, v.x, v.y, v.z); }
                if (b.every(240)) { Vec3 v = Fx.ring(lv, p.position(), 2.0, 5.0); net.minecraft.world.Containers.dropItemStack(lv, v.x, v.y + 1, v.z, new ItemStack(ModItems.CARNE_VERDE.get())); }
                if (b.every(300) && Config.SHAKE.get()) Fx.afflict(p, MobEffects.NAUSEA, 100, 0);
                if (b.every(400)) steal(b, p);
                if (t % 500 == 250) b.setWindow(lv, 140);
                if (b.every(180)) b.tpBehind(lv, p, 2.5);
                if (b.every(20)) Fx.bar(p, "Colpi validi: " + b.hitCount + "/3" + (b.window ? "  — ORA!" : ""));
            }
            case 5 -> {
                b.setVariant(1); b.face(p); b.getNavigation().stop();
                if (b.cageUntil > 0 && t > b.cageUntil) { uncage(b, lv); b.cageUntil = 0; }
                if (b.every(600)) cage(b, lv, p);
                if (b.every(300)) Fx.afflict(p, MobEffects.HUNGER, 200, 1);
                if (b.every(200)) Fx.afflict(p, ModEffects.CORRUZIONE, 300, 0);
                if (b.every(250)) b.tpNear(lv, p, 14.0);
                if (t > 100 && b.alive(lv, MinionType.CUCCIOLO_CORROTTO) == 0 && b.alive(lv, MinionType.SENTINELLA_VERDE) == 0) { b.say(p, "No! Il mio cucciolo..."); b.end(true, p); }
                if (p.getHealth() <= 4.0f && b.cageUntil > 0 && Config.POCKET.get()) { b.say(p, "Vieni a vedere la mia tana."); Pocket.enter(p, lv); b.end(false, p); }
                if (b.every(20)) Fx.bar(p, "Cucciolo: " + b.alive(lv, MinionType.CUCCIOLO_CORROTTO) + "  Sentinelle: " + b.alive(lv, MinionType.SENTINELLA_VERDE));
            }
            case 6 -> {
                b.setVariant(1);
                if (b.d == 1) {   // livello bonus: il clone vendicativo
                    b.face(p); b.getNavigation().stop(); b.window = false;
                    if (b.alive(lv, MinionType.CLONE_VENDICATIVO) == 0 || Progress.flag(p, "clone.ally")) { b.d = 2; b.setHealth(b.getMaxHealth() * 0.4f); b.say(p, "Va bene. Finiamola."); Fx.grant(p, "e404_clone_sconfitto"); }
                    else if (t > b.b) { b.d = 2; limbPenalty(p); b.setHealth(b.getMaxHealth() * 0.6f); }
                    else if (t % 20 == 0) Fx.bar(p, "Il clone ascolta le tue parole... (scrivi in chat) — fiducia " + b.c + "%");
                    return;
                }
                b.chase(p, 1.3); b.melee(p, 2.8, 14);
                if (b.every(100)) meteors(b, lv, p, 2, 6.0);
                if (b.every(900) && b.alive(lv, MinionType.DEMONE_MAGGIORE) < 3) b.wave(lv, p, MinionType.DEMONE_MAGGIORE, 1);
                if (b.every(500)) b.wave(lv, p, MinionType.CLONE_IMPERFETTO, Math.min(4, Config.MAX_CLONES.get()));
                if (b.every(700)) absorb(b, lv, p);
                if (t % 700 == 400) b.setWindow(lv, 150);
                if (b.every(250)) b.tpBehind(lv, p, 2.5);
                if (b.every(300)) steal(b, p);
                if (b.every(20)) Fx.bar(p, "Colpi validi: " + b.hitCount + (b.window ? "  — ORA!" : ""));
            }
            default -> {   // L7: Apocalisse Verde
                b.setVariant(1);
                b.c--;
                if (b.every(20)) {
                    int n = 0; for (BlockPos sp : b.statues) if (lv.getBlockState(sp).is(ModBlocks.STATUA_DESTINO.get())) n++;
                    b.a = Math.min(5, n);
                    Fx.bar(p, "Apocalisse: " + (b.c / 1200) + ":" + String.format("%02d", (b.c / 20) % 60) + "   Statue: " + b.a + "/5   Colpi: " + b.hitCount);
                }
                b.chase(p, 1.3); b.melee(p, 2.8, 14);
                int interval = Math.max(20, 80 - 12 * b.a);
                if (t % interval == 0) b.beam(lv, p, 6.0f, Fx.GREEN);
                if (b.every(120)) meteors(b, lv, p, 2, 7.0);
                for (int i = b.alive(lv, MinionType.SENTINELLA_VERDE); i < 3 && b.every(200); i++) { Vec3 v = Fx.ring(lv, p.position(), 9.0, 14.0); b.minion(lv, MinionType.SENTINELLA_VERDE, v.x, v.y, v.z); }
                if (b.every(300)) b.wave(lv, p, MinionType.DEMONE_MINORE, 2);
                if (b.every(600)) corrupt(p, 1);
                if (b.c <= 0) timeUp(b, lv, p);
            }
        }
    }
    private static void theft(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        BlockPos o = p.blockPosition();
        for (BlockPos q : BlockPos.betweenClosed(o.offset(-12, -4, -12), o.offset(12, 4, 12))) {
            if (!lv.getBlockState(q).is(Blocks.CHEST)) continue;
            if (lv.getBlockEntity(q) instanceof Container c) {
                for (int i = 0; i < c.getContainerSize(); i++) {
                    ItemStack s = c.getItem(i);
                    if (!s.isEmpty()) { b.stolen.add(s.copy()); b.setItemSlot(EquipmentSlot.MAINHAND, s.copy()); c.setItem(i, ItemStack.EMPTY); Fx.info(p, ChatFormatting.GREEN, "La Piaga ha svuotato un baule vicino. Gli oggetti torneranno alla fine dello scontro."); return; }
                }
            }
        }
    }
    private static void cage(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        BlockPos o = p.blockPosition();
        for (int dx = -1; dx <= 1; dx++) for (int dy = 0; dy <= 2; dy++) for (int dz = -1; dz <= 1; dz++) {
            if (dx == 0 && dz == 0 && dy < 2) continue;
            if (Math.abs(dx) == 1 || Math.abs(dz) == 1 || dy == 2) b.tempBlock(lv, o.offset(dx, dy, dz), ModBlocks.CUBO_VERDE.get().defaultBlockState());
        }
        b.cageUntil = b.fightTick + 160;
        Fx.info(p, ChatFormatting.GREEN, "Cubi verdi indistruttibili ti circondano! Resisti.");
    }
    private static void uncage(HorrorBoss b, ServerLevel lv) {
        for (int i = b.tempPos.size() - 1; i >= 0; i--) {
            if (b.tempBlk.get(i) == ModBlocks.CUBO_VERDE.get()) { if (lv.getBlockState(b.tempPos.get(i)).is(ModBlocks.CUBO_VERDE.get())) lv.removeBlock(b.tempPos.get(i), false); b.tempPos.remove(i); b.tempBlk.remove(i); }
        }
    }
    private static void absorb(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        List<Mob> others = lv.getEntitiesOfClass(Mob.class, b.getBoundingBox().inflate(80.0), m -> BuiltInRegistries.ENTITY_TYPE.wrapAsHolder(m.getType()).is(Tags.EntityTypes.BOSSES) && m.isAlive());
        for (Mob m : others) { m.setTarget(p); m.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.GLOWING, 200, 0)); }
        if (!others.isEmpty()) b.say(p, "Anche i boss degli altri mondi mi obbediscono.");
    }
    private static void limbPenalty(ServerPlayer p) {
        Fx.afflict(p, MobEffects.MINING_FATIGUE, 6000, 2); Fx.afflict(p, MobEffects.WEAKNESS, 6000, 1);
        Fx.info(p, ChatFormatting.DARK_GREEN, "Hai 'perso' un braccio (solo narrativamente): effetti temporanei, il tuo corpo non cambia.");
    }
    private static void timeUp(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        if (Config.WORLD_DESTRUCTION.get()) {
            Progress.setFlag(p, "world.destroyed", true);
            Fx.title(p, "IL MONDO È FINITO", "Narrativamente. Il salvataggio è intatto.");
            Fx.afflict(p, MobEffects.DARKNESS, 600, 0);
            b.say(p, "Il tempo è scaduto.");
            if (Config.CREATIVE_KILL.get()) { p.hurt(lv.damageSources().genericKill(), 1000.0f); }
        } else b.say(p, "Il tempo è scaduto... ma oggi mi annoio. Tornerò.");
        b.end(false, p);
    }
    /** Bonus: il clone vendicativo viene evocato quando il giocatore infligge troppo danno in poco tempo. */
    static void startBonus(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        b.d = 1; b.c = 0; b.b = b.fightTick + 1800; b.window = false;
        Progress.setFlag(p, "clone.ally", false);
        Vec3 v = Fx.ring(lv, p.position(), 6.0, 9.0);
        b.minion(lv, MinionType.CLONE_VENDICATIVO, v.x, v.y, v.z);
        b.say(p, "Troppo danno, troppo in fretta. Ti presento la mia copia... più umana di me.");
        Fx.title(p, "LIVELLO BONUS", "Il Clone Vendicativo");
        Fx.grant(p, "e404_clone");
    }

    // ------------------------------------------------------------------ MAGO
    private static void mago(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        int L = b.lvl(), t = b.fightTick;
        float hp = b.getHealth() / b.getMaxHealth();
        Fx.particles(lv, ParticleTypes.WITCH, b.getX(), b.getY() + 1.0, b.getZ(), 2, 0.4, 0.8, 0.4, 0.02);
        switch (L) {
            case 1 -> {
                b.face(p);
                if (b.every(60)) b.beam(lv, p, 3.0f, ParticleTypes.WITCH);
                if (b.every(100)) b.tpNear(lv, p, 7.0);
                if (b.every(150) && Config.SHAKE.get()) Fx.afflict(p, MobEffects.DARKNESS, 50, 0);
                if (b.every(80)) Fx.sound(lv, p.getX() + 3, p.getY(), p.getZ() - 3, ModSounds.FOOTSTEPS.get(), 0.5f, 1.0f);
                if (hp < 0.3f) { b.say(p, "Basta. Hai superato la prova."); b.end(true, p); }
            }
            case 2 -> {
                b.face(p);
                if (b.every(150) && b.alive(lv, MinionType.SPETTRO_ILLUSORIO) < 4) b.wave(lv, p, MinionType.SPETTRO_ILLUSORIO, 2);
                if (b.every(120)) { b.setWindow(lv, 40); b.beam(lv, p, 4.0f, ParticleTypes.ENCHANT); }
                if (b.every(90)) b.tpNear(lv, p, 8.0);
                if (b.every(200)) Fx.sound(lv, p.getX() - 4, p.getY(), p.getZ() + 4, ModSounds.WHISPER_A.get(), 0.6f, 1.0f);
            }
            case 3 -> {
                b.face(p);
                if (b.every(70)) b.beam(lv, p, 4.0f, ParticleTypes.WITCH);
                if (b.every(300)) curse(p);
                if (b.every(200) && !b.marks.isEmpty()) b.say(p, "Una runa vibra a " + dir(p.position(), b.marks.get(0)) + ".");
                if (b.every(110)) b.tpNear(lv, p, 8.0);
                if (b.every(250)) b.wave(lv, p, MinionType.GUARDIANO_ARCANO, 1);
                for (BlockPos mp : b.marks) if (b.every(20)) Fx.particles(lv, ParticleTypes.ENCHANT, mp.getX() + 0.5, mp.getY() + 1.2, mp.getZ() + 0.5, 8, 0.3, 0.6, 0.3, 0.3);
                if (b.every(20)) Fx.bar(p, "Rune attive: " + b.a + " — rompile per renderlo vulnerabile");
            }
            case 4 -> {
                b.face(p);
                if (b.every(70)) b.beam(lv, p, 5.0f, ParticleTypes.WITCH);
                if (b.every(120)) b.tpNear(lv, p, 8.0);
                if (b.every(300) && b.a > 0) b.heal(b.getMaxHealth() * 0.05f);
                if (b.every(400)) { Fx.afflict(p, MobEffects.LEVITATION, 40, 0); b.say(p, "La gravità è una questione di opinioni."); }
                if (b.every(500)) b.wave(lv, p, MinionType.ECO_VIVENTE, 2);
                if (b.every(20)) Fx.bar(p, b.a > 0 ? "Generatori arcani: " + b.a + " (rompili per esaurire la sua energia)" : "Energia esaurita! Colpiscilo");
            }
            default -> {
                b.face(p);
                if (b.every(60)) b.beam(lv, p, 5.0f, ParticleTypes.ENCHANT);
                if (b.every(100)) b.tpNear(lv, p, 9.0);
                if (b.phase == 0) {
                    if (b.every(600)) { for (BlockPos mp : b.marks) lv.removeBlock(mp, false); b.marks.clear(); b.a = place(b, lv, p, ModBlocks.RUNA_PILASTRO.get(), b.a, 9.0, 16.0); b.say(p, "Le rune cambiano posto."); }
                    if (b.every(300)) curse(p);
                    if (b.a <= 0) {
                        b.phase = 1; b.b = t + 1200; b.say(p, "Il bastone... NO!");
                        BlockPos c = BlockPos.containing(b.getX(), Fx.groundY(lv, b.getX(), b.getZ()), b.getZ());
                        lv.setBlock(c, ModBlocks.PIEDISTALLO_BASTONE.get().defaultBlockState(), 3); b.marks.add(c);
                        b.wave(lv, p, MinionType.GUARDIANO_ARCANO, 2);
                    }
                    if (b.every(20)) Fx.bar(p, "Rune antiche: " + b.a + "/5");
                } else {
                    if (b.every(250)) b.wave(lv, p, MinionType.ELEMENTALE_VIOLA, 1);
                    if (b.every(20)) Fx.bar(p, "Distruggi il bastone sul piedistallo! " + Math.max(0, (b.b - t) / 20) + " s");
                    if (t > b.b) { b.say(p, "Troppo tardi per te."); b.end(false, p); }
                }
            }
        }
    }
    private static void curse(ServerPlayer p) {
        switch (p.getRandom().nextInt(3)) {
            case 0 -> Fx.afflict(p, MobEffects.SLOWNESS, 120, 1);
            case 1 -> Fx.afflict(p, ModEffects.MALEDIZIONE_RUNICA, 200, 0);
            default -> Fx.afflict(p, MobEffects.BLINDNESS, 50, 0);
        }
        Fx.bar(p, "Una maledizione ti colpisce...");
    }
    static void runeBroken(HorrorBoss b, ServerLevel lv, ServerPlayer p, BlockPos pos) {
        b.marks.remove(pos); b.a = Math.max(0, b.a - 1);
        Fx.particles(lv, ParticleTypes.ENCHANT, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5, 40, 0.5, 0.8, 0.5, 0.5);
        Fx.sound(lv, pos.getX(), pos.getY(), pos.getZ(), ModSounds.RUNE_CHIME.get(), 1.0f, 0.8f);
        if (b.a == 0 && b.lvl() != 5) b.say(p, "Le rune... sono perdute. Sono vulnerabile!");
    }
    static void pedestalBroken(HorrorBoss b, ServerLevel lv, ServerPlayer p) { b.say(p, "Il bastone è... in pezzi."); b.end(true, p); }

    // ------------------------------------------------------------------ STEVE
    private static void steve(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        int L = b.lvl(), t = b.fightTick;
        float hp = b.getHealth() / b.getMaxHealth();
        if (t % 40 == 0) { ItemStack h = p.getMainHandItem(); boolean ranged = h.is(Items.BOW) || h.is(Items.CROSSBOW) || h.is(Items.TRIDENT); b.mem.merge(ranged ? "ranged" : "melee", 1, Integer::sum); }
        boolean vsRanged = b.mem.getOrDefault("ranged", 0) > b.mem.getOrDefault("melee", 0);
        if (t % 500 == 250) b.sayRandom(p);
        if (L == 1) {
            b.chase(p, 1.0); b.melee(p, 2.4, 24);
            if (hp < 0.5f) { b.say(p, "Va bene, hai fegato. Ti lascio queste."); b.end(true, p); }
            return;
        }
        if (L == 5 && b.phase < 2) { steveTrials(b, lv, p); return; }
        if (b.d > t) {                                  // si ritira per curarsi
            Vec3 away = b.position().subtract(p.position()).normalize().scale(10.0).add(b.position());
            if (t % 10 == 0) b.getNavigation().moveTo(away.x, away.y, away.z, 1.3);
            if (t % 20 == 0) b.heal(3.0f);
            return;
        }
        if (hp < 0.3f && t - b.b > 600) { b.b = t; b.d = t + 200; b.say(p, "Mi ritiro un attimo."); return; }
        if (t % 100 == 0) b.c = t + 40;                 // scudo alzato per 2 secondi
        if (L == 2 && hp < 0.6f && b.phase == 0) {
            b.phase = 1; Vec3 dir = p.position().subtract(b.position()).normalize();
            for (int k = -1; k <= 1; k++) for (int y = 0; y <= 1; y++)
                b.tempBlock(lv, BlockPos.containing(b.getX() + dir.x * 2 + dir.z * k, b.getY() + y, b.getZ() + dir.z * 2 - dir.x * k), Blocks.COBBLESTONE.defaultBlockState());
            b.say(p, "Barricata.");
        }
        if (L >= 3 && b.every(220)) { b.tpBehind(lv, p, 3.0); Fx.sound(lv, b.getX(), b.getY(), b.getZ(), ModSounds.TELEPORT_BLIP.get(), 0.8f, 1.0f); }
        if (L >= 4) {
            if (b.every(20)) { b.a = intact(b, lv); if (b.a > 0 && b.every(40)) b.heal(1.5f * b.a); }
            if (b.every(600) && !b.depots.isEmpty()) { for (BlockPos dp : b.depots) if (lv.getBlockState(dp).is(Blocks.CHEST)) { b.say(p, "Un deposito a " + dir(p.position(), dp) + ", a circa " + (int) Math.sqrt(p.distanceToSqr(dp.getX(), dp.getY(), dp.getZ())) + " blocchi."); break; } }
            if (b.every(300)) { Vec3 v = Fx.ring(lv, p.position(), 2.0, 6.0); b.zone(lv, v.x, v.y, v.z, 2.5, 100, 3.0); }
            if (b.every(20)) Fx.bar(p, "Depositi di Steve ancora intatti: " + b.a);
        }
        double dist = b.distanceTo(p);
        if (!vsRanged && dist < 6.0 && L >= 3 && b.every(15)) {      // tiene le distanze dai combattenti in mischia
            Vec3 away = b.position().subtract(p.position()).normalize().scale(6.0).add(b.position()); b.getNavigation().moveTo(away.x, away.y, away.z, 1.2);
        } else b.chase(p, 1.1 + 0.05 * L);
        if (dist > 7.0 && b.every(60 - 4 * L) && b.hasLineOfSight(p)) {
            Fx.beam(lv, b.getEyePosition(), p.getEyePosition(), ParticleTypes.CRIT);
            boolean still = p.getDeltaMovement().horizontalDistanceSqr() < 0.01;
            if (still || b.getRandom().nextBoolean()) Fx.hurt(p, lv.damageSources().mobAttack(b), 3.0f + L);
        }
        b.melee(p, 2.5, 20);
    }
    private static final String[] NEED = {"cobblestone", "iron_ingot", "bread"};
    private static final int[] NEED_N = {32, 12, 10};
    private static void steveTrials(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        int t = b.fightTick;
        b.getNavigation().stop(); b.face(p);
        if (b.phase == 0) {
            if (b.every(160)) vanilla(b, lv, p, EntityTypes.ZOMBIE, 3);
            if (b.every(260)) vanilla(b, lv, p, EntityTypes.SKELETON, 2);
            if (b.every(400)) Fx.afflict(p, MobEffects.HUNGER, 200, 1);
            if (t % 20 == 0) Fx.bar(p, "Prova 1/3 — Sopravvivenza: " + Math.max(0, (2000 - t) / 20) + " s");
            if (t >= 2000) { b.phase = 1; b.cleanup((ServerLevel) b.level()); b.say(p, "Prova 2: strategia. Portami 32 pietrisco, 12 lingotti di ferro e 10 pane (clic destro su di me)."); }
        } else {
            if (t % 20 == 0) Fx.bar(p, "Prova 2/3 — Risorse: " + b.mem.getOrDefault("n.cobblestone", 0) + "/32 pietrisco, " + b.mem.getOrDefault("n.iron_ingot", 0) + "/12 ferro, " + b.mem.getOrDefault("n.bread", 0) + "/10 pane");
            boolean all = true;
            for (int i = 0; i < NEED.length; i++) if (b.mem.getOrDefault("n." + NEED[i], 0) < NEED_N[i]) all = false;
            if (all) {
                b.phase = 2; b.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD)); b.setHealth(b.getMaxHealth());
                b.say(p, "Prova 3: combattimento. Niente trucchi. Ricordo ogni cosa che hai fatto."); Fx.title(p, "Prova 3/3", "Combattimento finale");
            }
        }
    }
    static void stevePay(HorrorBoss b, ServerPlayer p, ItemStack s) {
        if (b.kind != Kind.STEVE || b.lvl() != 5 || b.phase != 1) return;
        for (int i = 0; i < NEED.length; i++) {
            if (!s.is(net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(net.minecraft.resources.Identifier.withDefaultNamespace(NEED[i])))) continue;
            int have = b.mem.getOrDefault("n." + NEED[i], 0), take = Math.min(s.getCount(), NEED_N[i] - have);
            if (take > 0) { s.shrink(take); b.mem.put("n." + NEED[i], have + take); Fx.bar(p, "Steve accetta " + take + "."); }
            return;
        }
    }
    static void depotBroken(HorrorBoss b, ServerLevel lv, ServerPlayer p) {
        Fx.bar(p, "Deposito distrutto!");
        if (intact(b, lv) <= 1) b.say(p, "Le mie scorte... Beh. Vediamo cosa sai fare davvero.");
    }

    // ================================================================= ganci per Vuln
    /** Gestione speciale prima delle regole generali: ritorna true se il colpo è stato gestito. */
    static boolean preHit(HorrorBoss b, ServerPlayer p, LivingIncomingDamageEvent e) {
        if (b.kind == Kind.ENTITY404 && b.lvl() == 3 && b.d == 1 && p.getMainHandItem().is(Items.IRON_SWORD)) {
            e.setCanceled(true);
            if (b.tickCount - b.lastHit >= 8) {
                b.lastHit = b.tickCount; b.c++; Fx.bar(p, "Sfida della spada di ferro: " + b.c + "/5");
                if (b.c >= 5) b.defeat(p);
            }
            return true;
        }
        return false;
    }
    static void onValidHit(HorrorBoss b, ServerPlayer p, Vuln.W w, boolean special) {
        ServerLevel lv = (ServerLevel) b.level();
        if (b.kind == Kind.STEVE && b.every(1)) { b.mem.merge("hits", 1, Integer::sum); }
        if (b.kind == Kind.ENTITY404 && b.lvl() == 6 && b.d == 0 && special) {
            if (b.fightTick - b.burstStart > 100) { b.burstStart = b.fightTick; b.burstN = 0; }
            if (++b.burstN >= 4) startBonus(b, lv, p);
        }
    }
}
