package com.magialuama.horrorverse;

import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.item.equipment.ArmorType;
import net.neoforged.neoforge.registries.DeferredItem;

public final class ModItems {
    private ModItems() {}
    public static final DeferredItem<Item> LAMA_ANTIVIRUS = Reg.item("lama_antivirus", p -> new Item(p.sword(Mats.SPETTRALE, 3.0f, -2.4f).rarity(Rarity.RARE)));
    public static final DeferredItem<Item> LAMA_QUARANTENA = Reg.item("lama_quarantena", p -> new Item(p.sword(Mats.SPETTRALE, 5.0f, -2.2f).rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> SPADA_PALLIDA = Reg.item("spada_pallida", p -> new Item(p.sword(Mats.SPETTRALE, 4.0f, -2.4f).rarity(Rarity.RARE)));
    public static final DeferredItem<Item> SPADA_RUNICA = Reg.item("spada_runica", p -> new Item(p.sword(Mats.SPETTRALE, 3.0f, -2.4f).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<Item> FALCE_MIETITORE = Reg.item("falce_mietitore", p -> new Item(p.sword(Mats.SPETTRALE, 4.0f, -2.6f).rarity(Rarity.RARE)));
    public static final DeferredItem<Item> SCETTRO_ELETTRICO = Reg.item("scettro_elettrico", p -> new Item(p.stacksTo(1).rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> BASTONE_MAGO = Reg.item("bastone_mago", p -> new Item(p.stacksTo(1).rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> SPADA_SPETTRALE = Reg.item("spada_spettrale", p -> new Item(p.sword(Mats.SPETTRALE, 3.0f, -2.4f)));
    public static final DeferredItem<Item> PICCONE_SPETTRALE = Reg.item("piccone_spettrale", p -> new Item(p.pickaxe(Mats.SPETTRALE, 1.0f, -2.8f)));
    public static final DeferredItem<Item> ASCIA_SPETTRALE = Reg.item("ascia_spettrale", p -> new Item(p.axe(Mats.SPETTRALE, 5.0f, -3.0f)));
    public static final DeferredItem<Item> PALA_SPETTRALE = Reg.item("pala_spettrale", p -> new Item(p.shovel(Mats.SPETTRALE, 1.5f, -3.0f)));
    public static final DeferredItem<Item> ZAPPA_SPETTRALE = Reg.item("zappa_spettrale", p -> new Item(p.hoe(Mats.SPETTRALE, -3.0f, 0.0f)));
    public static final DeferredItem<Item> ELMO_ANTIVIRUS = Reg.item("elmo_antivirus", p -> new Item(p.humanoidArmor(Mats.ANTIVIRUS, ArmorType.HELMET)));
    public static final DeferredItem<Item> CORAZZA_ANTIVIRUS = Reg.item("corazza_antivirus", p -> new Item(p.humanoidArmor(Mats.ANTIVIRUS, ArmorType.CHESTPLATE)));
    public static final DeferredItem<Item> GAMBALI_ANTIVIRUS = Reg.item("gambali_antivirus", p -> new Item(p.humanoidArmor(Mats.ANTIVIRUS, ArmorType.LEGGINGS)));
    public static final DeferredItem<Item> STIVALI_ANTIVIRUS = Reg.item("stivali_antivirus", p -> new Item(p.humanoidArmor(Mats.ANTIVIRUS, ArmorType.BOOTS)));
    public static final DeferredItem<Item> FRAMMENTO_SPETTRALE = Reg.item("frammento_spettrale", p -> new Item(p));
    public static final DeferredItem<Item> LINGOTTO_SPETTRALE = Reg.item("lingotto_spettrale", p -> new Item(p));
    public static final DeferredItem<Item> FRAMMENTO_VERDE = Reg.item("frammento_verde", p -> new Item(p));
    public static final DeferredItem<Item> NUCLEO_CORROTTO = Reg.item("nucleo_corrotto", p -> new Item(p.rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<Item> CRISTALLO_LUCE = Reg.item("cristallo_luce", p -> new Item(p));
    public static final DeferredItem<Item> FRAMMENTO_OCCHIO_BIANCO = Reg.item("frammento_occhio_bianco", p -> new Item(p));
    public static final DeferredItem<Item> OCCHIO_BIANCO = Reg.item("occhio_bianco", p -> new Item(p.rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> RUNA_ANTICA = Reg.item("runa_antica", p -> new Item(p.rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<Item> ARTEFATTO_ANTIOSCURITA = Reg.item("artefatto_antioscurita", p -> new Item(p.rarity(Rarity.RARE)));
    public static final DeferredItem<Item> CRISTALLO_PURIFICAZIONE = Reg.item("cristallo_purificazione", p -> new Item(p.rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<Item> FIALA_CONTENIMENTO = Reg.item("fiala_contenimento", p -> new Item(p.rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<Item> PERLA_RITUALE = Reg.item("perla_rituale", p -> new Item(p.rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> OCCHIO_FANTASMA = Reg.item("occhio_fantasma", p -> new Item(p.stacksTo(1)));
    public static final DeferredItem<Item> CHIAVE_DIMENSIONE = Reg.item("chiave_dimensione", p -> new Item(p.stacksTo(1).rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> DIARIO_MONDO = Reg.item("diario_mondo", p -> new Item(p.stacksTo(1)));
    public static final DeferredItem<Item> FRUTTO_EDEN = Reg.item("frutto_eden", p -> new Item(p.rarity(Rarity.EPIC).food(new FoodProperties.Builder().nutrition(8).saturationModifier(1.2f).alwaysEdible().build())));
    public static final DeferredItem<Item> MELA_OSCURA = Reg.item("mela_oscura", p -> new Item(p.food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.3f).alwaysEdible().build())));
    public static final DeferredItem<Item> PANE_PALLIDO = Reg.item("pane_pallido", p -> new Item(p.food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.7f).build())));
    public static final DeferredItem<Item> ZUPPA_OMBRA = Reg.item("zuppa_ombra", p -> new Item(p.stacksTo(16).food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.8f).build())));
    public static final DeferredItem<Item> BACCHE_SPETTRALI = Reg.item("bacche_spettrali", p -> new Item(p.food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.4f).build())));
    public static final DeferredItem<Item> CARNE_VERDE = Reg.item("carne_verde", p -> new Item(p.food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.2f).alwaysEdible().build())));
    public static final DeferredItem<Item> BISCOTTO_RUNICO = Reg.item("biscotto_runico", p -> new Item(p.food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.3f).build())));
    public static final DeferredItem<Item> UOVO_CUSTODE = Reg.item("uovo_custode", p -> new SpawnEggItem(p.spawnEgg(ModEntities.CUSTODE.get())));
    public static final DeferredItem<Item> UOVO_CORROTTO = Reg.item("uovo_corrotto", p -> new SpawnEggItem(p.spawnEgg(ModEntities.CORROTTO.get())));
    public static final DeferredItem<Item> UOVO_ENTITY_404 = Reg.item("uovo_entity_404", p -> new SpawnEggItem(p.spawnEgg(ModEntities.ENTITY404.get())));
    public static final DeferredItem<Item> UOVO_UOMO_MAGICO = Reg.item("uovo_uomo_magico", p -> new SpawnEggItem(p.spawnEgg(ModEntities.MAGO.get())));
    public static final DeferredItem<Item> UOVO_STEVE = Reg.item("uovo_steve", p -> new SpawnEggItem(p.spawnEgg(ModEntities.STEVE.get())));
    public static final DeferredItem<Item> UOVO_OSSERVATORE = Reg.item("uovo_osservatore", p -> new SpawnEggItem(p.spawnEgg(ModEntities.OSSERVATORE.get())));
    public static void init() { }
}
