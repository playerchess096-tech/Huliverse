package com.magialuama.horrorverse;

import java.util.function.Function;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

/** Renderer unico per tutte le entità umanoidi del mod (boss e mostri). */
public class HRenderer<T extends Mob> extends HumanoidMobRenderer<T, HorrorRenderState, HorrorModel> {
    private final Function<T, Identifier> texFn;

    public HRenderer(EntityRendererProvider.Context ctx, ModelLayerLocation layer, Function<T, Identifier> texFn) {
        super(ctx, new HorrorModel(ctx.bakeLayer(layer)), 0.5F);
        this.texFn = texFn;
    }
    @Override public HorrorRenderState createRenderState() { return new HorrorRenderState(); }
    @Override public void extractRenderState(T entity, HorrorRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.tex = texFn.apply(entity);
    }
    @Override public Identifier getTextureLocation(HorrorRenderState state) { return state.tex; }
}
