# -*- coding: utf-8 -*-
"""Specifiche dei contenuti: unica fonte per Java (registri), risorse e lingue."""
MOD = 'horrorverse'

# (id, it, en, espressione Java con p = Item.Properties, icona)
ITEMS = [
 # --- armi
 ('lama_antivirus','Spada Antivirus','Antivirus Sword','new Item(p.sword(Mats.SPETTRALE, 3.0f, -2.4f).rarity(Rarity.RARE))','sword:#8dff6a:#1f9d3a:#2b2b2b'),
 ('lama_quarantena','Lama Quarantena','Quarantine Blade','new Item(p.sword(Mats.SPETTRALE, 5.0f, -2.2f).rarity(Rarity.EPIC))','sword:#e6ffb0:#5fd35f:#101010'),
 ('spada_pallida','Spada Pallida','Pale Sword','new Item(p.sword(Mats.SPETTRALE, 4.0f, -2.4f).rarity(Rarity.RARE))','sword:#f4f4f4:#9a9a9a:#222222'),
 ('spada_runica','Spada Runica','Runic Sword','new Item(p.sword(Mats.SPETTRALE, 3.0f, -2.4f).rarity(Rarity.UNCOMMON))','sword:#c9a0ff:#6a3fc7:#d8b04a'),
 ('falce_mietitore','Falce del Mietitore','Reaper Scythe','new Item(p.sword(Mats.SPETTRALE, 4.0f, -2.6f).rarity(Rarity.RARE))','scythe:#cfcfcf:#6f6f6f:#4a3320'),
 ('scettro_elettrico','Scettro Elettrico','Electric Scepter','new Item(p.stacksTo(1).rarity(Rarity.EPIC))','staff:#fff27a:#6b5a2a'),
 ('bastone_mago','Bastone dell\'Uomo Magico','Magic Man Staff','new Item(p.stacksTo(1).rarity(Rarity.EPIC))','staff:#b98cff:#4a2f1a'),
 # --- set spettrale
 ('spada_spettrale','Spada Spettrale','Spectral Sword','new Item(p.sword(Mats.SPETTRALE, 3.0f, -2.4f))','sword:#cfe8ff:#7aa7d6:#4a3b2a'),
 ('piccone_spettrale','Piccone Spettrale','Spectral Pickaxe','new Item(p.pickaxe(Mats.SPETTRALE, 1.0f, -2.8f))','pick:#cfe8ff:#7aa7d6:#4a3b2a'),
 ('ascia_spettrale','Ascia Spettrale','Spectral Axe','new AxeItem(Mats.SPETTRALE, 5.0f, -3.0f, p)','axe:#cfe8ff:#7aa7d6:#4a3b2a'),
 ('pala_spettrale','Pala Spettrale','Spectral Shovel','new ShovelItem(Mats.SPETTRALE, 1.5f, -3.0f, p)','shovel:#cfe8ff:#7aa7d6:#4a3b2a'),
 ('zappa_spettrale','Zappa Spettrale','Spectral Hoe','new HoeItem(Mats.SPETTRALE, -3.0f, 0.0f, p)','hoe:#cfe8ff:#7aa7d6:#4a3b2a'),
 # --- armatura anti-Entity 404
 ('elmo_antivirus','Elmo Antivirus','Antivirus Helmet','new Item(p.humanoidArmor(Mats.ANTIVIRUS, ArmorType.HELMET))','helmet:#7dff8a:#1e7a34'),
 ('corazza_antivirus','Corazza Antivirus','Antivirus Chestplate','new Item(p.humanoidArmor(Mats.ANTIVIRUS, ArmorType.CHESTPLATE))','chest:#7dff8a:#1e7a34'),
 ('gambali_antivirus','Gambali Antivirus','Antivirus Leggings','new Item(p.humanoidArmor(Mats.ANTIVIRUS, ArmorType.LEGGINGS))','legs:#7dff8a:#1e7a34'),
 ('stivali_antivirus','Stivali Antivirus','Antivirus Boots','new Item(p.humanoidArmor(Mats.ANTIVIRUS, ArmorType.BOOTS))','boots:#7dff8a:#1e7a34'),
 # --- materiali
 ('frammento_spettrale','Frammento Spettrale','Spectral Shard','new Item(p)','shard:#9fd0ff'),
 ('lingotto_spettrale','Lingotto Spettrale','Spectral Ingot','new Item(p)','ingot:#bfe0ff:#5f8fc4'),
 ('frammento_verde','Frammento Verde','Green Shard','new Item(p)','shard:#3cff5a'),
 ('nucleo_corrotto','Nucleo Corrotto','Corrupted Core','new Item(p.rarity(Rarity.UNCOMMON))','orb:#3cff5a:#0b1a0f'),
 ('cristallo_luce','Cristallo di Luce','Light Crystal','new Item(p)','gem:#fff3a0'),
 ('frammento_occhio_bianco','Frammento dell\'Occhio Bianco','White Eye Shard','new Item(p)','shard:#f5f5f5'),
 ('occhio_bianco','Occhio Bianco','White Eye','new Item(p.rarity(Rarity.EPIC))','eye:#ffffff'),
 ('runa_antica','Runa Antica','Ancient Rune','new Item(p.rarity(Rarity.UNCOMMON))','rune:#b98cff'),
 # --- oggetti funzionali
 ('artefatto_antioscurita','Artefatto Anti-Oscurità','Anti-Darkness Artifact','new Item(p.rarity(Rarity.RARE))','artifact:#ffe066'),
 ('cristallo_purificazione','Cristallo di Purificazione','Purification Crystal','new Item(p.rarity(Rarity.UNCOMMON))','gem:#aef3ff'),
 ('fiala_contenimento','Fiala di Contenimento','Containment Vial','new Item(p.rarity(Rarity.UNCOMMON))','vial:#5dff7a'),
 ('perla_rituale','Perla del Rituale','Ritual Pearl','new Item(p.rarity(Rarity.EPIC))','pearl:#7a2bff'),
 ('occhio_fantasma','Occhio Fantasma','Phantom Eye','new Item(p.stacksTo(1))','eye:#cfcfcf'),
 ('chiave_dimensione','Chiave Dimensionale 404','Dimensional Key 404','new Item(p.stacksTo(1).rarity(Rarity.EPIC))','key:#3cff5a'),
 ('diario_mondo','Diario del Mondo','World Diary','new Item(p.stacksTo(1))','book:#6b3f2a'),
 # --- cibi
 ('frutto_eden','Frutto dell\'Eden','Fruit of Eden','new Item(p.rarity(Rarity.EPIC).food(new FoodProperties.Builder().nutrition(8).saturationModifier(1.2f).alwaysEdible().build()))','apple:#ffd24a:#fff0b0'),
 ('mela_oscura','Mela Oscura','Dark Apple','new Item(p.food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.3f).alwaysEdible().build()))','apple:#3b1b5e:#7a4bb0'),
 ('pane_pallido','Pane Pallido','Pale Bread','new Item(p.food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.7f).build()))','bread:#e8e2cf'),
 ('zuppa_ombra','Zuppa dell\'Ombra','Shadow Stew','new Item(p.stacksTo(16).food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.8f).build()))','bowl:#2a1f3d'),
 ('bacche_spettrali','Bacche Spettrali','Spectral Berries','new Item(p.food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.4f).build()))','berries:#7fd3ff'),
 ('carne_verde','Carne Verde','Green Meat','new Item(p.food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.2f).alwaysEdible().build()))','meat:#3cff5a'),
 ('biscotto_runico','Biscotto Runico','Runic Cookie','new Item(p.food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.3f).build()))','cookie:#b98cff'),
 # --- uova di generazione
 ('uovo_custode','Uovo: Custode','Spawn Egg: Custodian','new SpawnEggItem(p.spawnEgg(ModEntities.CUSTODE.get()))','egg:#f2f2f2:#1a1a1a'),
 ('uovo_corrotto','Uovo: Corrotto','Spawn Egg: Corrupted','new SpawnEggItem(p.spawnEgg(ModEntities.CORROTTO.get()))','egg:#1a1a1a:#8a2bff'),
 ('uovo_entity_404','Uovo: Entity 404','Spawn Egg: Entity 404','new SpawnEggItem(p.spawnEgg(ModEntities.ENTITY404.get()))','egg:#0a2a10:#3cff5a'),
 ('uovo_uomo_magico','Uovo: Uomo Magico','Spawn Egg: Magic Man','new SpawnEggItem(p.spawnEgg(ModEntities.MAGO.get()))','egg:#3b1c7a:#d9a441'),
 ('uovo_steve','Uovo: Steve','Spawn Egg: Steve','new SpawnEggItem(p.spawnEgg(ModEntities.STEVE.get()))','egg:#1fa8a1:#4b3fa8'),
 ('uovo_osservatore','Uovo: Osservatore','Spawn Egg: Observer','new SpawnEggItem(p.spawnEgg(ModEntities.OSSERVATORE.get()))','egg:#050505:#ffffff'),
]

# (id, it, en, proprietà Java, stile texture, drop 'self' o 'item:min:max', strumento)
BLOCKS = [
 ('blocco_oscuro','Blocco Oscuro','Dark Block','BlockBehaviour.Properties.of().strength(2.0f, 6.0f).sound(SoundType.DEEPSLATE)','dark','self','pickaxe'),
 ('cubo_verde','Cubo Verde','Green Cube','BlockBehaviour.Properties.of().strength(-1.0f, 3600000.0f).sound(SoundType.AMETHYST).lightLevel(s -> 9)','cube','none',None),
 ('runa_pilastro','Pilastro Runico','Rune Pillar','BlockBehaviour.Properties.of().strength(4.0f, 12.0f).sound(SoundType.STONE).lightLevel(s -> 8)','rune','self','pickaxe'),
 ('generatore_arcano','Generatore Arcano','Arcane Generator','BlockBehaviour.Properties.of().strength(4.0f, 12.0f).sound(SoundType.AMETHYST).lightLevel(s -> 10)','arcane','self','pickaxe'),
 ('piedistallo_bastone','Piedistallo del Bastone','Staff Pedestal','BlockBehaviour.Properties.of().strength(5.0f, 20.0f).sound(SoundType.STONE).lightLevel(s -> 12)','pedestal','none','pickaxe'),
 ('statua_destino','Statua del Destino','Statue of Destiny','BlockBehaviour.Properties.of().strength(5.0f, 30.0f).requiresCorrectToolForDrops().sound(SoundType.STONE).lightLevel(s -> 6)','destiny','self','pickaxe'),
 ('cuore_404','Cuore di Entity 404','Entity 404 Heart','BlockBehaviour.Properties.of().strength(8.0f, 100.0f).sound(SoundType.SLIME_BLOCK).lightLevel(s -> 15)','heart','none','pickaxe'),
 ('blocco_organico','Blocco Organico','Organic Block','BlockBehaviour.Properties.of().strength(1.0f, 3.0f).sound(SoundType.SLIME_BLOCK)','organic','self','pickaxe'),
 ('minerale_spettrale','Minerale Spettrale','Spectral Ore','BlockBehaviour.Properties.of().strength(3.0f, 3.0f).requiresCorrectToolForDrops().sound(SoundType.STONE)','ore','frammento_spettrale:1:2','pickaxe'),
 ('pietra_rituale','Pietra Rituale','Ritual Stone','BlockBehaviour.Properties.of().strength(2.0f, 8.0f).sound(SoundType.STONE)','ritual','self','pickaxe'),
 ('traccia_osservatore','Traccia dell\'Osservatore','Observer Trace','BlockBehaviour.Properties.of().strength(0.5f, 1.0f).sound(SoundType.SCULK).lightLevel(s -> 4)','trace','none',None),
 ('occhio_osservatore','Occhio dell\'Osservatore','Observer Eye','BlockBehaviour.Properties.of().strength(1.0f, 1.0f).sound(SoundType.SCULK).lightLevel(s -> 15)','eyeblock','none',None),
]

# (id, it, en, categoria, colore, descrizione effetto)
EFFECTS = [
 ('corruzione','Corruzione','Corruption','HARMFUL','4B1B6E'),
 ('scudo_eden','Scudo dell\'Eden','Eden Shield','BENEFICIAL','FFD24A'),
 ('sguardo','Sguardo','Gaze','HARMFUL','DDDDDD'),
 ('piaga','Piaga','Plague','HARMFUL','3CFF5A'),
 ('maledizione_runica','Maledizione Runica','Runic Curse','HARMFUL','8A4FFF'),
 ('purezza','Purezza','Purity','BENEFICIAL','AEF3FF'),
]

# tratti: CHASE TELEPORT STATUE SHY RANGED EXPLODE AMBUSH ILLUSION SUMMON SLOW FLY NEUTRAL ROOTED DRAIN
# (id, it, en, w, h, hp, dmg, speed, scale, tratti, stile, palette[base,accento,occhi,dettaglio], drop 'item:chance:min:max;...')
MINIONS = [
 # Custode
 ('zombie_bianco','Zombie dagli Occhi Bianchi','White-Eyed Zombie',0.6,1.95,36,7,0.30,1.0,['CHASE'],'zombie',['8e9a95','3a3f4a','ffffff','262a33'],'frammento_occhio_bianco:0.15:1:1'),
 ('guardiano_pallido','Guardiano Pallido','Pale Guardian',0.7,2.0,60,8,0.22,1.1,['CHASE'],'armor',['c9ccd2','8d9199','ffffff','5b5f66'],'frammento_occhio_bianco:0.25:1:1'),
 ('cavaliere_fulmine','Cavaliere del Fulmine','Lightning Knight',0.6,1.95,50,6,0.27,1.0,['CHASE','RANGED'],'armor',['3a4a6b','ffe14a','ffff9a','1c2438'],'cristallo_luce:0.2:1:1'),
 ('sentinella_end','Sentinella dell\'End','End Sentinel',0.6,2.3,40,6,0.25,1.1,['CHASE','TELEPORT'],'shadow',['150f22','7a2bff','e8c0ff','2a1a40'],'perla_rituale:0.02:1:1'),
 ('imitatore_bianco','Imitatore Bianco','White Imitator',0.6,1.95,30,5,0.28,1.0,['AMBUSH','CHASE'],'faceless',['d9d9d9','8a8a8a','ffffff','3a3a3a'],''),
 ('ombra_custode','Ombra del Custode','Custodian Shadow',0.6,1.95,24,5,0.32,1.0,['TELEPORT','SHY','CHASE'],'shadow',['060606','2a2a2a','ffffff','101010'],''),
 # Corrotto
 ('statua_vivente','Statua Vivente','Living Statue',0.7,2.0,120,16,0.34,1.05,['STATUE'],'stone',['7d7d85','55555c','c9a0ff','3b3b42'],'cristallo_luce:0.3:1:1'),
 ('occhio_errante','Occhio Errante','Wandering Eye',0.5,0.9,14,4,0.25,0.5,['FLY','CHASE'],'eye',['120a1a','ffffff','8a2bff','2a1440'],''),
 ('ombra_divoratrice','Ombra Divoratrice','Devouring Shadow',0.6,1.95,40,7,0.30,1.0,['CHASE','SHY'],'shadow',['08040e','2b1646','8a2bff','150a24'],''),
 ('cavaliere_oscuro','Cavaliere Oscuro','Dark Knight',0.65,2.0,70,9,0.26,1.05,['CHASE'],'armor',['23202e','5a3f8a','8a2bff','100e16'],'cristallo_luce:0.15:1:1'),
 ('clone_incompleto','Clone Incompleto','Incomplete Clone',0.6,1.95,30,5,0.30,1.0,['CHASE'],'faceless',['1a1a1a','8a2bff','ffffff','2a2a2a'],''),
 ('frammento_anima','Frammento d\'Anima','Soul Fragment',0.4,0.9,10,0,0.22,0.5,['FLY','CHASE','DRAIN'],'ghost',['7fa8ff','dbe8ff','ffffff','3a4a7a'],''),
 # Entity 404
 ('zombie_verde','Zombie Verde','Green Zombie',0.6,1.95,30,5,0.30,1.0,['CHASE'],'zombie',['2f9b3b','1a5a2a','ccff66','0e2a14'],'frammento_verde:0.35:1:2'),
 ('scheletro_corrotto','Scheletro Corrotto','Corrupted Skeleton',0.6,1.99,24,4,0.28,1.0,['RANGED','CHASE'],'bones',['b9d9b0','3cff5a','3cff5a','2a4a30'],'frammento_verde:0.35:1:2'),
 ('creeper_infetto','Creeper Infetto','Infected Creeper',0.6,1.7,20,0,0.32,1.0,['EXPLODE','CHASE'],'zombie',['1f7a2e','0b3a14','ccff66','06200a'],'frammento_verde:0.5:1:2'),
 ('tentacolo_vivente','Tentacolo Vivente','Living Tentacle',0.7,2.4,50,8,0.0,1.2,['ROOTED'],'tentacle',['2a8a3a','7dff8a','ccff66','0e3a1a'],'frammento_verde:0.5:1:3'),
 ('sentinella_verde','Sentinella Verde','Green Sentinel',0.8,2.6,80,10,0.0,1.3,['ROOTED','RANGED'],'mech',['3a4a3f','3cff5a','3cff5a','1a241c'],'nucleo_corrotto:0.3:1:1'),
 ('demone_minore','Demone Minore','Lesser Demon',0.6,1.95,90,9,0.28,1.0,['CHASE'],'demon',['2a4a2e','0a0a0a','3cff5a','ffffff'],'frammento_verde:0.5:1:3'),
 ('demone_maggiore','Demone Maggiore','Greater Demon',0.9,2.7,300,14,0.27,1.4,['CHASE','SUMMON'],'demon',['1b3a22','050505','3cff5a','ffffff'],'nucleo_corrotto:0.8:1:1'),
 ('cucciolo_corrotto','Cucciolo Corrotto','Corrupted Pup',0.6,1.6,220,10,0.30,0.9,['CHASE','DRAIN','SLOW'],'tentacle',['1f6a2e','ccff66','ff3b3b','0a2a10'],'nucleo_corrotto:0.9:1:2'),
 ('bestia_meteorica','Bestia Meteorica','Meteor Beast',1.0,2.6,260,12,0.25,1.6,['FLY','RANGED'],'demon',['3a1a10','ff7a1a','ffd24a','100805'],'nucleo_corrotto:0.7:1:1'),
 ('clone_imperfetto','Clone Imperfetto','Imperfect Clone',0.6,1.95,40,6,0.30,1.0,['CHASE'],'faceless',['1a3a1e','3cff5a','3cff5a','0a1a0e'],'frammento_verde:0.3:1:1'),
 ('clone_vendicativo','Clone Vendicativo','Vengeful Clone',0.6,1.95,400,13,0.30,1.0,['CHASE'],'demon',['2f6a3a','050505','3cff5a','ffffff'],'nucleo_corrotto:1.0:1:2'),
 # Uomo Magico
 ('golem_runico','Golem Runico','Runic Golem',0.9,2.6,150,12,0.20,1.3,['CHASE'],'stone',['6a5a8a','b98cff','b98cff','2a2040'],'runa_antica:0.2:1:1'),
 ('spettro_illusorio','Spettro Illusorio','Illusory Specter',0.6,1.95,1,0,0.30,1.0,['ILLUSION','CHASE'],'ghost',['b98cff','e8d8ff','ffffff','6a3fc7'],''),
 ('guardiano_arcano','Guardiano Arcano','Arcane Guardian',0.65,2.0,90,8,0.24,1.05,['CHASE'],'armor',['4a2f8a','d9a441','e8d8ff','2a1a50'],'runa_antica:0.15:1:1'),
 ('corvo_mago','Corvo del Mago','Mage Raven',0.4,0.7,6,1,0.30,0.4,['FLY','NEUTRAL'],'raven',['0c0c12','3a2a5a','ffd24a','1a1a24'],'frammento_spettrale:0.5:1:1'),
 ('elementale_viola','Elementale Viola','Violet Elemental',0.7,2.0,40,7,0.26,1.1,['FLY','RANGED'],'ghost',['8a4fff','d9b8ff','ffffff','4a2a99'],'runa_antica:0.2:1:1'),
 ('cavaliere_rune','Cavaliere delle Rune','Rune Knight',0.65,2.0,80,10,0.27,1.05,['CHASE'],'armor',['5a3fa8','d9a441','e8d8ff','2a1a50'],'runa_antica:0.2:1:1'),
 ('eco_vivente','Eco Vivente','Living Echo',0.6,1.95,40,5,0.30,1.0,['CHASE'],'ghost',['9fd0ff','e8f4ff','ffffff','4a6a8a'],''),
 # Steve
 ('sentinella_meccanica','Sentinella Meccanica','Mechanical Sentinel',0.7,2.0,60,6,0.0,1.1,['ROOTED','RANGED'],'mech',['8a8f96','ffd24a','ff3b3b','3a3d42'],'frammento_spettrale:0.3:1:1'),
 ('golem_difesa','Golem da Difesa','Defense Golem',0.9,2.7,140,12,0.22,1.3,['CHASE'],'armor',['9aa0a8','5a6068','ffd24a','3a3d42'],'lingotto_spettrale:0.2:1:1'),
 ('cacciatore_corazzato','Cacciatore Corazzato','Armored Hunter',0.6,1.95,80,8,0.30,1.0,['CHASE'],'armor',['b8bcc4','6a6e76','ff3b3b','3a3d42'],'lingotto_spettrale:0.15:1:1'),
 ('drone_ricognizione','Drone di Ricognizione','Recon Drone',0.4,0.7,10,0,0.30,0.4,['FLY','NEUTRAL'],'mech',['a8adb4','6a6e76','3cff5a','3a3d42'],''),
 # Mondo
 ('viandante_senza_volto','Viandante Senza Volto','Faceless Wanderer',0.6,1.95,20,0,0.25,1.0,['SHY','NEUTRAL'],'faceless',['5a5a5a','2a2a2a','2a2a2a','1a1a1a'],''),
 ('cacciatore_notturno','Cacciatore Notturno','Night Hunter',0.6,1.95,40,7,0.33,1.0,['CHASE'],'robed',['0e0e16','2a2a3a','ff3b3b','050508'],'frammento_spettrale:0.3:1:1'),
 ('predatore_silenzioso','Predatore Silenzioso','Silent Predator',0.6,1.95,50,8,0.30,1.0,['AMBUSH','SHY','CHASE'],'shadow',['0a0a0a','202020','ffffff','050505'],''),
 ('cavaliere_spezzato','Cavaliere Spezzato','Broken Knight',0.65,2.0,60,8,0.26,1.0,['CHASE'],'armor',['7a6a5a','4a3a2a','ff7a3a','2a2018'],'lingotto_spettrale:0.1:1:1'),
 ('il_mietitore','Il Mietitore','The Reaper',0.7,2.1,200,12,0.28,1.15,['CHASE','TELEPORT'],'robed',['1a1a22','8a8a96','ff3b3b','07070a'],'falce_mietitore:0.5:1:1'),
 ('regina_statue','La Regina delle Statue','Queen of Statues',0.8,2.3,260,10,0.25,1.2,['CHASE','SUMMON'],'stone',['9a9aa4','c9a0ff','c9a0ff','4a4a52'],'cristallo_luce:1.0:2:4'),
 ('colosso_runico','Il Colosso Runico','The Runic Colossus',1.2,3.4,320,14,0.18,1.8,['CHASE','RANGED'],'stone',['5a4a7a','b98cff','b98cff','1f1830'],'runa_antica:1.0:2:3'),
]

# suoni: (id, descrizione). I file sono generati da gen_audio.py
SOUNDS = [
 'heartbeat','footsteps','whisper_a','whisper_b','whisper_c','drone_low','door_creak','thunder_far',
 'jumpscare','glitch','static_burst','bell_toll','rune_chime','magic_cast','teleport_blip','statue_grind',
 'victory_sting','defeat_sting','ambient_night_a','ambient_night_b',
 'theme_custode','theme_corrotto','theme_404','theme_mago','theme_steve','theme_osservatore',
]
