# -*- coding: utf-8 -*-
"""Genera registri Java, texture, modelli, lingue, ricette, achievement e worldgen del mod. Uso: python3 tools/gen.py"""
import os, json, shutil, sys
sys.path.insert(0, os.path.dirname(__file__))
import gen_spec as S, gen_art as G
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
JAVA = ROOT + '/src/main/java/com/magialuama/horrorverse'
A = ROOT + '/src/main/resources/assets/horrorverse'
D = ROOT + '/src/main/resources/data/horrorverse'
SK = os.path.join(os.path.dirname(__file__), 'skins_src')

def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f: f.write(text)
def wj(path, obj): w(path, json.dumps(obj, ensure_ascii=False, indent=1) + '\n')
def img(path, im): os.makedirs(os.path.dirname(path), exist_ok=True); im.save(path)
def up(s): return s.upper()
def jstr(s): return s.replace('\\', '\\\\').replace('"', '\\"')

# ============================================================ Java
HEAD = 'package com.magialuama.horrorverse;\n\n'
items = ['import net.minecraft.world.food.FoodProperties;', 'import net.minecraft.world.item.*;', 'import net.minecraft.world.item.equipment.ArmorType;', 'import net.neoforged.neoforge.registries.DeferredItem;']
src = HEAD + '\n'.join(items) + '\n\npublic final class ModItems {\n    private ModItems() {}\n'
for (i, it, en, expr, icon) in S.ITEMS:
    src += '    public static final DeferredItem<Item> %s = Reg.item("%s", p -> %s);\n' % (up(i), i, expr)
src += '    public static void init() { }\n}\n'
w(JAVA + '/ModItems.java', src)

src = HEAD + 'import net.minecraft.world.item.BlockItem;\nimport net.minecraft.world.level.block.Block;\nimport net.minecraft.world.level.block.SoundType;\nimport net.minecraft.world.level.block.state.BlockBehaviour;\nimport net.neoforged.neoforge.registries.DeferredBlock;\nimport net.neoforged.neoforge.registries.DeferredItem;\n\npublic final class ModBlocks {\n    private ModBlocks() {}\n'
for (i, it, en, props, tex, drop, tool) in S.BLOCKS:
    src += '    public static final DeferredBlock<Block> %s = block("%s", %s);\n' % (up(i), i, props)
src += '''    private static DeferredBlock<Block> block(String id, BlockBehaviour.Properties p) {
        DeferredBlock<Block> b = Reg.BLOCKS.registerSimpleBlock(id, p);
        DeferredItem<BlockItem> i = Reg.ITEMS.registerSimpleBlockItem(id, b);
        Reg.TAB_ITEMS.add(i); Reg.BY_ID.put(id, i);
        return b;
    }
    public static void init() { }
}
'''
w(JAVA + '/ModBlocks.java', src)

src = HEAD + 'import net.minecraft.world.effect.MobEffect;\nimport net.minecraft.world.effect.MobEffectCategory;\nimport net.neoforged.neoforge.registries.DeferredHolder;\n\npublic final class ModEffects {\n    private ModEffects() {}\n'
for (i, it, en, cat, col) in S.EFFECTS:
    src += '    public static final DeferredHolder<MobEffect, MarkerEffect> %s = Reg.EFFECTS.register("%s", () -> new MarkerEffect(MobEffectCategory.%s, 0x%s));\n' % (up(i), i, cat, col)
src += '    public static void init() { }\n}\n'
w(JAVA + '/ModEffects.java', src)

src = HEAD + 'import net.minecraft.sounds.SoundEvent;\nimport net.neoforged.neoforge.registries.DeferredHolder;\n\npublic final class ModSounds {\n    private ModSounds() {}\n'
for s_ in S.SOUNDS: src += '    public static final DeferredHolder<SoundEvent, SoundEvent> %s = Reg.sound("%s");\n' % (up(s_), s_)
src += '''    public static DeferredHolder<SoundEvent, SoundEvent> theme(Kind k) {
        return switch (k) {
            case CUSTODE -> THEME_CUSTODE; case CORROTTO -> THEME_CORROTTO; case ENTITY404 -> THEME_404;
            case MAGO -> THEME_MAGO; case STEVE -> THEME_STEVE; case OSSERVATORE -> THEME_OSSERVATORE;
        };
    }
    public static void init() { }
}
'''
w(JAVA + '/ModSounds.java', src)

src = HEAD + 'import java.util.Arrays;\nimport java.util.EnumSet;\n\n/** Mostri del mod (generato da tools/gen.py). I comportamenti dipendono dai tratti. */\npublic enum MinionType {\n'
rows = []
for (i, it, en, wd, ht, hp, dmg, sp, sc, tr, style, pal, drops) in S.MINIONS:
    t = ', '.join('Trait.' + x for x in tr)
    rows.append('    %s("%s", "%s", %sf, %sf, %d, %sf, %s, %sf, "%s"%s)' % (up(i), i, jstr(it), wd, ht, hp, dmg, sp, sc, drops, (', ' + t) if t else ''))
src += ',\n'.join(rows) + ';\n\n'
src += '''    public enum Trait { CHASE, TELEPORT, STATUE, SHY, RANGED, EXPLODE, AMBUSH, ILLUSION, SUMMON, SLOW, FLY, NEUTRAL, ROOTED, DRAIN }
    public final String id, nameIt, drops;
    public final float w, h, dmg, scale;
    public final int hp;
    public final double speed;
    public final EnumSet<Trait> traits;
    MinionType(String id, String nameIt, float w, float h, int hp, float dmg, double speed, float scale, String drops, Trait... tr) {
        this.id = id; this.nameIt = nameIt; this.w = w; this.h = h; this.hp = hp; this.dmg = dmg; this.speed = speed; this.scale = scale; this.drops = drops;
        this.traits = tr.length == 0 ? EnumSet.noneOf(Trait.class) : EnumSet.copyOf(Arrays.asList(tr));
    }
}
'''
w(JAVA + '/MinionType.java', src)

# ============================================================ texture
for (i, it, en, expr, icon) in S.ITEMS: img(A + '/textures/item/%s.png' % i, G.icon(icon))
for (i, it, en, props, tex, drop, tool) in S.BLOCKS: img(A + '/textures/block/%s.png' % i, G.block_tex(tex, i))
for (i, it, en, cat, col) in S.EFFECTS: img(A + '/textures/mob_effect/%s.png' % i, G.effect_icon(col, i))
for m in S.MINIONS: img(A + '/textures/entity/minion/%s.png' % m[0], G.paint_mob(m[10], m[11], m[0]))
for n in ('custode', 'e404_a', 'e404_b', 'corrotto_0', 'corrotto_1'): shutil.copy(SK + '/%s.png' % n, A + '/textures/entity/%s.png' % n)
c1 = Image.open(SK + '/corrotto_1.png').convert('RGBA'); c2 = c1.copy(); px = c2.load()
for y in range(64):
    for x in range(64):
        r_, g_, b_, a_ = px[x, y]
        if a_:
            purple = b_ > r_ + 20 and b_ > g_ + 20
            px[x, y] = (min(255, int(r_ * 0.9) + 20), int(g_ * 0.45), min(255, int(b_ * 1.2) + 30), a_) if purple else (int(r_ * 0.45), int(g_ * 0.35), int(b_ * 0.55), a_)
for ex, ey in ((9, 11), (10, 11)): pass
img(A + '/textures/entity/corrotto_2.png', c2)
for l in range(1, 6): img(A + '/textures/entity/steve_%d.png' % l, G.steve_skin(l))
img(A + '/textures/entity/osservatore.png', G.observer_skin())
img(A + '/textures/entity/mago.png', G.wizard_skin())
img(A + '/textures/entity/equipment/humanoid/antivirus.png', G.armor_layer(1))
img(A + '/textures/entity/equipment/humanoid_leggings/antivirus.png', G.armor_layer(2))
img(A + '/textures/gui/advancements/backgrounds/horror.png', G.adv_bg())
wj(A + '/equipment/antivirus.json', {"layers": {"humanoid": [{"texture": "horrorverse:antivirus"}], "humanoid_leggings": [{"texture": "horrorverse:antivirus"}]}})

# ============================================================ modelli / blockstate / item definitions
TOOLS = ('sword', 'pick', 'axe', 'shovel', 'hoe', 'scythe', 'staff')
for (i, it, en, expr, icon) in S.ITEMS:
    parent = 'minecraft:item/handheld' if icon.split(':')[0] in TOOLS else 'minecraft:item/generated'
    wj(A + '/models/item/%s.json' % i, {"parent": parent, "textures": {"layer0": "horrorverse:item/%s" % i}})
    wj(A + '/items/%s.json' % i, {"model": {"type": "minecraft:model", "model": "horrorverse:item/%s" % i}})
for (i, it, en, props, tex, drop, tool) in S.BLOCKS:
    wj(A + '/blockstates/%s.json' % i, {"variants": {"": {"model": "horrorverse:block/%s" % i}}})
    wj(A + '/models/block/%s.json' % i, {"parent": "minecraft:block/cube_all", "textures": {"all": "horrorverse:block/%s" % i}})
    wj(A + '/items/%s.json' % i, {"model": {"type": "minecraft:model", "model": "horrorverse:block/%s" % i}})
    if drop == 'self':
        loot = {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": "horrorverse:%s" % i}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]}
    elif drop == 'none': loot = None
    else:
        item, lo, hi = drop.split(':')
        loot = {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": "horrorverse:%s" % item, "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": int(lo), "max": int(hi)}}]}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]}
    if loot: wj(D + '/loot_table/blocks/%s.json' % i, loot)
wj(ROOT + '/src/main/resources/data/minecraft/tags/block/mineable/pickaxe.json', {"values": ["horrorverse:%s" % b[0] for b in S.BLOCKS if b[6] == 'pickaxe']})
wj(ROOT + '/src/main/resources/data/minecraft/tags/block/needs_iron_tool.json', {"values": ["horrorverse:minerale_spettrale", "horrorverse:statua_destino"]})
wj(D + '/tags/item/repairs_antivirus.json', {"values": ["horrorverse:nucleo_corrotto"]})
wj(D + '/tags/item/repairs_spettrale.json', {"values": ["horrorverse:lingotto_spettrale"]})

# ============================================================ ricette
def shaped(out, pattern, key, n=1): return {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern, "key": key, "result": {"id": out, "count": n}}
def shapeless(out, ing, n=1): return {"type": "minecraft:crafting_shapeless", "category": "misc", "ingredients": ing, "result": {"id": out, "count": n}}
H = lambda x: 'horrorverse:' + x
M = lambda x: 'minecraft:' + x
R = {
 'lingotto_spettrale': shapeless(H('lingotto_spettrale'), [H('frammento_spettrale')] * 4),
 'spada_spettrale': shaped(H('spada_spettrale'), ['L', 'L', 'S'], {'L': H('lingotto_spettrale'), 'S': M('stick')}),
 'piccone_spettrale': shaped(H('piccone_spettrale'), ['LLL', ' S ', ' S '], {'L': H('lingotto_spettrale'), 'S': M('stick')}),
 'ascia_spettrale': shaped(H('ascia_spettrale'), ['LL', 'LS', ' S'], {'L': H('lingotto_spettrale'), 'S': M('stick')}),
 'pala_spettrale': shaped(H('pala_spettrale'), ['L', 'S', 'S'], {'L': H('lingotto_spettrale'), 'S': M('stick')}),
 'zappa_spettrale': shaped(H('zappa_spettrale'), ['LL', ' S', ' S'], {'L': H('lingotto_spettrale'), 'S': M('stick')}),
 'lama_antivirus': shaped(H('lama_antivirus'), ['FNF', ' D ', ' S '], {'F': H('frammento_verde'), 'N': H('nucleo_corrotto'), 'D': M('diamond'), 'S': M('stick')}),
 'lama_quarantena': shaped(H('lama_quarantena'), ['NIN', 'NLN', ' S '], {'N': H('nucleo_corrotto'), 'I': M('netherite_ingot'), 'L': H('lama_antivirus'), 'S': M('stick')}),
 'elmo_antivirus': shaped(H('elmo_antivirus'), ['NFN', 'F F'], {'N': H('nucleo_corrotto'), 'F': H('frammento_verde')}),
 'corazza_antivirus': shaped(H('corazza_antivirus'), ['F F', 'NFN', 'FFF'], {'N': H('nucleo_corrotto'), 'F': H('frammento_verde')}),
 'gambali_antivirus': shaped(H('gambali_antivirus'), ['FNF', 'N N', 'F F'], {'N': H('nucleo_corrotto'), 'F': H('frammento_verde')}),
 'stivali_antivirus': shaped(H('stivali_antivirus'), ['F F', 'N N'], {'N': H('nucleo_corrotto'), 'F': H('frammento_verde')}),
 'artefatto_antioscurita': shapeless(H('artefatto_antioscurita'), [H('cristallo_luce')] * 3 + [M('diamond'), M('glowstone')]),
 'cristallo_purificazione': shapeless(H('cristallo_purificazione'), [H('cristallo_luce'), M('amethyst_shard'), M('quartz')]),
 'fiala_contenimento': shapeless(H('fiala_contenimento'), [M('glass_bottle'), H('frammento_verde'), H('frammento_verde'), M('slime_ball')]),
 'perla_rituale': shapeless(H('perla_rituale'), [M('ender_pearl'), H('frammento_occhio_bianco'), H('frammento_occhio_bianco'), M('ender_eye')]),
 'chiave_dimensione': shapeless(H('chiave_dimensione'), [H('nucleo_corrotto'), H('nucleo_corrotto'), M('ender_eye'), M('obsidian')]),
 'diario_mondo': shapeless(H('diario_mondo'), [M('book'), M('feather'), M('black_dye')]),
 'statua_destino': shaped(H('statua_destino'), [' N ', 'OGO', 'ODO'], {'N': H('nucleo_corrotto'), 'O': M('obsidian'), 'G': M('gold_ingot'), 'D': M('diamond')}),
 'frutto_eden': shaped(H('frutto_eden'), ['AAA', 'AAA', 'AAA'], {'A': M('golden_apple')}),
 'pane_pallido': shapeless(H('pane_pallido'), [M('wheat')] * 3 + [M('bone_meal')]),
 'zuppa_ombra': shapeless(H('zuppa_ombra'), [M('bowl'), M('black_dye'), M('beetroot'), M('carrot')]),
 'bacche_spettrali': shapeless(H('bacche_spettrali'), [M('sweet_berries'), M('sweet_berries'), H('frammento_spettrale')]),
 'biscotto_runico': shapeless(H('biscotto_runico'), [M('wheat'), M('wheat'), M('cocoa_beans'), H('runa_antica')], 4),
 'spada_runica': shaped(H('spada_runica'), ['R', 'R', 'S'], {'R': H('runa_antica'), 'S': M('stick')}),
}
for k, v in R.items(): wj(D + '/recipe/%s.json' % k, v)

# ============================================================ worldgen
FEAT = [('altare_custode', 300, 'surface_structures'), ('torre_mago', 450, 'surface_structures'), ('santuario_corrotto', 400, 'surface_structures'),
        ('rifugio_steve', 300, 'surface_structures'), ('torre_osservatore', 600, 'surface_structures'), ('landa_cinerea', 120, 'vegetal_decoration'), ('macchia_corrotta', 160, 'vegetal_decoration')]
for (f, chance, step) in FEAT:
    wj(D + '/worldgen/configured_feature/%s.json' % f, {"type": "horrorverse:%s" % f, "config": {}})
    wj(D + '/worldgen/placed_feature/%s.json' % f, {"feature": "horrorverse:%s" % f, "placement": [{"type": "minecraft:rarity_filter", "chance": chance}, {"type": "minecraft:in_square"}, {"type": "minecraft:heightmap", "heightmap": "WORLD_SURFACE_WG"}, {"type": "minecraft:biome"}]})
    wj(D + '/neoforge/biome_modifier/%s.json' % f, {"type": "neoforge:add_features", "biomes": "#minecraft:is_overworld", "features": "horrorverse:%s" % f, "step": step})
ore_state = {"Name": "horrorverse:minerale_spettrale"}
wj(D + '/worldgen/configured_feature/minerale_spettrale.json', {"type": "minecraft:ore", "config": {"size": 6, "discard_chance_on_air_exposure": 0.0, "targets": [
    {"target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:stone_ore_replaceables"}, "state": ore_state},
    {"target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:deepslate_ore_replaceables"}, "state": ore_state}]}})
wj(D + '/worldgen/placed_feature/minerale_spettrale.json', {"feature": "horrorverse:minerale_spettrale", "placement": [{"type": "minecraft:count", "count": 5}, {"type": "minecraft:in_square"},
    {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": -48}, "max_inclusive": {"absolute": 40}}}, {"type": "minecraft:biome"}]})
wj(D + '/neoforge/biome_modifier/minerale_spettrale.json', {"type": "neoforge:add_features", "biomes": "#minecraft:is_overworld", "features": "horrorverse:minerale_spettrale", "step": "underground_ores"})

# ============================================================ suoni
sj = {}
for s_ in S.SOUNDS: sj[s_] = {"sounds": [{"name": "horrorverse:%s" % s_, **({"stream": True} if s_.startswith(('theme_', 'ambient_')) else {})}]}
wj(A + '/sounds.json', sj)

# ============================================================ achievement
ADV = [  # id, parent, icona, cornice, titolo it, desc it, titolo en, desc en
 ('radice', None, 'horrorverse:diario_mondo', 'task', 'Universo Horror', 'Qualcuno ti osserva. Un diario è comparso nel tuo inventario.', 'Horror Universe', 'Someone is watching you. A diary appeared in your inventory.'),
 ('osservatore_primo_sguardo', 'radice', 'horrorverse:occhio_fantasma', 'task', 'Non sono io che sono arrivato', 'Hai visto l\'Osservatore in lontananza.', 'I Did Not Arrive', 'You saw the Observer in the distance.'),
 ('osservatore_non_guardare', 'osservatore_primo_sguardo', 'minecraft:ender_eye', 'goal', 'Sparire sotto lo sguardo', 'Hai fissato l\'Osservatore finché non è scomparso.', 'Vanishing Under the Gaze', 'You stared at the Observer until it vanished.'),
 ('osservatore_tracce', 'osservatore_primo_sguardo', 'horrorverse:traccia_osservatore', 'goal', 'Le tue stesse orme', 'Hai trovato le tre tracce dei tuoi passi.', 'Your Own Footsteps', 'You found the three traces of your steps.'),
 ('osservatore_interrotto', 'osservatore_tracce', 'minecraft:clock', 'goal', 'Evento interrotto', 'Hai interrotto ciò che l\'Osservatore stava compiendo.', 'Event Interrupted', 'You interrupted what the Observer was completing.'),
 ('osservatore_torre', 'osservatore_interrotto', 'horrorverse:occhio_bianco', 'challenge', 'Il posto da cui vede tutto', 'Sei salito sulla Torre dell\'Osservatore.', 'Where It Sees Everything', 'You climbed the Observer\'s Tower.'),
 ('steve_primo_incontro', 'radice', 'minecraft:bread', 'task', 'Un altro sopravvissuto', 'Hai incontrato Steve.', 'Another Survivor', 'You met Steve.'),
 ('steve_scambio', 'steve_primo_incontro', 'minecraft:emerald', 'task', 'Scambio onesto', 'Hai scambiato un oggetto con Steve.', 'Fair Trade', 'You traded an item with Steve.'),
 ('steve_sconosciuto', 'steve_scambio', 'minecraft:wooden_sword', 'task', 'Lo Sconosciuto', 'Hai superato la prima prova di Steve.', 'The Stranger', 'You passed Steve\'s first test.'),
 ('steve_sopravvissuto', 'steve_sconosciuto', 'minecraft:iron_sword', 'task', 'Il Sopravvissuto', 'Hai battuto Steve armato di ferro.', 'The Survivor', 'You beat Steve in iron gear.'),
 ('steve_maestro', 'steve_sopravvissuto', 'minecraft:diamond_sword', 'goal', 'Il Maestro di Minecraft', 'Hai battuto Steve livello 3.', 'The Minecraft Master', 'You beat level 3 Steve.'),
 ('steve_veterano', 'steve_maestro', 'minecraft:netherite_sword', 'goal', 'Il Veterano', 'Hai distrutto le scorte di Steve e l\'hai battuto.', 'The Veteran', 'You broke Steve\'s depots and beat him.'),
 ('steve_perfetto', 'steve_veterano', 'minecraft:netherite_chestplate', 'challenge', 'Il Giocatore Perfetto', 'Hai superato le tre prove di Steve.', 'The Perfect Player', 'You passed Steve\'s three trials.'),
 ('steve_tregua', 'steve_perfetto', 'minecraft:totem_of_undying', 'challenge', 'Tregua tra sopravvissuti', 'Steve ora è dalla tua parte.', 'Truce Between Survivors', 'Steve is now on your side.'),
 ('custode_avvistamento', 'radice', 'horrorverse:frammento_occhio_bianco', 'task', 'Occhi bianchi tra gli alberi', 'Hai avvistato il Custode.', 'White Eyes in the Trees', 'You spotted the Custodian.'),
 ('custode_prima_prova', 'custode_avvistamento', 'minecraft:wooden_sword', 'task', 'La prima prova', 'Hai sconfitto il Guardiano.', 'The First Test', 'You defeated the Guardian.'),
 ('custode_contatto', 'custode_prima_prova', 'minecraft:feather', 'task', 'Tocca il vuoto', 'Hai toccato il Custode tre volte.', 'Touch the Void', 'You touched the Custodian three times.'),
 ('custode_scettro', 'custode_contatto', 'horrorverse:scettro_elettrico', 'goal', 'Il peso dello scettro', 'Hai sconfitto il Custode dello Scettro.', 'The Scepter\'s Weight', 'You defeated the Scepter Custodian.'),
 ('frutto_eden', 'custode_scettro', 'horrorverse:frutto_eden', 'goal', 'Il frutto proibito', 'Hai mangiato il Frutto dell\'Eden.', 'The Forbidden Fruit', 'You ate the Fruit of Eden.'),
 ('custode_supremo', 'custode_scettro', 'horrorverse:spada_pallida', 'goal', 'Il Custode Supremo', 'Hai sconfitto il Custode Supremo.', 'The Supreme Custodian', 'You defeated the Supreme Custodian.'),
 ('custode_risparmiato', 'custode_supremo', 'minecraft:white_dye', 'challenge', 'La mano tesa', 'Hai risparmiato il Custode.', 'The Open Hand', 'You spared the Custodian.'),
 ('custode_ucciso', 'custode_supremo', 'horrorverse:occhio_bianco', 'challenge', 'Solo, di nuovo', 'Hai ucciso il Custode per sempre.', 'Alone, Again', 'You killed the Custodian for good.'),
 ('custode_rituale', 'custode_supremo', 'horrorverse:perla_rituale', 'challenge', 'Il limite violato', 'Hai superato il Rituale Proibito.', 'The Limit Crossed', 'You survived the Forbidden Ritual.'),
 ('mago_avvistamento', 'radice', 'horrorverse:runa_antica', 'task', 'Rune sui tronchi', 'Hai incontrato l\'Uomo Magico.', 'Runes on the Trees', 'You met the Magic Man.'),
 ('mago_patto', 'mago_avvistamento', 'minecraft:gold_ingot', 'task', 'Un patto avido', 'Hai stretto un patto con l\'Uomo Magico.', 'A Greedy Pact', 'You made a pact with the Magic Man.'),
 ('mago_apprendista', 'mago_avvistamento', 'minecraft:stick', 'task', 'L\'Apprendista', 'Hai superato la prova dell\'Apprendista.', 'The Apprentice', 'You passed the Apprentice\'s test.'),
 ('mago_illusioni', 'mago_apprendista', 'minecraft:glass', 'task', 'Non credere ai tuoi occhi', 'Hai smascherato le illusioni.', 'Do Not Trust Your Eyes', 'You saw through the illusions.'),
 ('mago_rune', 'mago_illusioni', 'horrorverse:runa_pilastro', 'goal', 'Tre rune spezzate', 'Hai spezzato le rune del Signore degli Incantesimi.', 'Three Broken Runes', 'You broke the Spell Lord\'s runes.'),
 ('mago_arcimago', 'mago_rune', 'horrorverse:generatore_arcano', 'goal', 'L\'Arcimago', 'Hai esaurito l\'energia dell\'Arcimago.', 'The Archmage', 'You drained the Archmage.'),
 ('mago_dio', 'mago_arcimago', 'horrorverse:bastone_mago', 'challenge', 'Il bastone infranto', 'Hai distrutto il bastone del Dio della Magia.', 'The Broken Staff', 'You destroyed the Magic God\'s staff.'),
 ('corrotto_incontro', 'radice', 'horrorverse:cristallo_luce', 'task', 'Un viaggiatore gentile', 'Hai incontrato il Corrotto.', 'A Kind Traveler', 'You met the Corrupted.'),
 ('corrotto_amico', 'corrotto_incontro', 'minecraft:poppy', 'task', 'Un nuovo amico', 'Hai fatto un regalo al Corrotto.', 'A New Friend', 'You gave the Corrupted a gift.'),
 ('corrotto_alleato', 'corrotto_amico', 'minecraft:golden_apple', 'challenge', 'Una persona squisita', 'Il Corrotto si fida di te e combatte al tuo fianco.', 'An Exquisite Person', 'The Corrupted trusts you and fights at your side.'),
 ('corrotto_ferito', 'corrotto_incontro', 'horrorverse:mela_oscura', 'task', 'Qualcosa si incrina', 'Hai ferito il Corrotto.', 'Something Cracks', 'You hurt the Corrupted.'),
 ('corrotto_statue', 'corrotto_ferito', 'horrorverse:blocco_oscuro', 'task', 'Non voltarti', 'Hai sopravvissuto alle statue.', 'Don\'t Look Away', 'You survived the statues.'),
 ('corrotto_oscurita', 'corrotto_statue', 'minecraft:coal', 'task', 'L\'oscurità crescente', 'Hai sopravvissuto all\'oscurità.', 'Growing Darkness', 'You survived the darkness.'),
 ('corrotto_corruzione', 'corrotto_oscurita', 'horrorverse:artefatto_antioscurita', 'goal', 'La Corruzione', 'Hai usato l\'artefatto contro la corruzione.', 'The Corruption', 'You used the artifact against the corruption.'),
 ('corrotto_indebolito', 'corrotto_corruzione', 'minecraft:wither_rose', 'goal', 'Il Corrotto Indebolito', 'Hai colpito il Corrotto nella finestra giusta.', 'The Weakened Corrupted', 'You struck the Corrupted at the right moment.'),
 ('corrotto_dio', 'corrotto_indebolito', 'minecraft:nether_star', 'challenge', 'Il Dio dell\'Oscurità', 'Hai sconfitto il Dio dell\'Oscurità.', 'God of Darkness', 'You defeated the God of Darkness.'),
 ('corrotto_purificato', 'corrotto_incontro', 'horrorverse:cristallo_purificazione', 'task', 'Purificazione', 'Hai purificato i tuoi oggetti dall\'oscurità.', 'Purification', 'You purified your items.'),
 ('e404_avvistamento', 'radice', 'minecraft:lime_dye', 'task', '404', 'Hai visto i primi segni di Entity 404.', '404', 'You saw the first signs of Entity 404.'),
 ('e404_troll', 'e404_avvistamento', 'minecraft:cobweb', 'task', 'Il Troll', 'Hai sopravvissuto al Troll.', 'The Troll', 'You survived the Troll.'),
 ('e404_skin', 'e404_troll', 'horrorverse:frammento_verde', 'task', 'La skin corrotta', 'Hai sopravvissuto alla Skin Corrotta.', 'The Corrupted Skin', 'You survived the Corrupted Skin.'),
 ('e404_piaga', 'e404_skin', 'horrorverse:fiala_contenimento', 'goal', 'La Piaga', 'Hai fermato la Piaga.', 'The Plague', 'You stopped the Plague.'),
 ('e404_demone', 'e404_piaga', 'horrorverse:lama_antivirus', 'goal', 'Il Demone Verde', 'Hai colpito il Demone Verde tre volte.', 'The Green Demon', 'You struck the Green Demon three times.'),
 ('e404_cucciolo', 'e404_demone', 'horrorverse:nucleo_corrotto', 'goal', 'Il Cucciolo', 'Hai sconfitto il Cucciolo di Entity 404.', 'The Pup', 'You defeated Entity 404\'s pup.'),
 ('e404_dimensione', 'e404_cucciolo', 'horrorverse:chiave_dimensione', 'goal', 'Oltre i limiti del mondo', 'Sei entrato nella dimensione di Entity 404.', 'Beyond the World', 'You entered Entity 404\'s dimension.'),
 ('e404_cuore', 'e404_dimensione', 'horrorverse:cuore_404', 'challenge', 'Il Cuore spezzato', 'Hai distrutto il Cuore di Entity 404.', 'The Broken Heart', 'You destroyed Entity 404\'s Heart.'),
 ('e404_signore', 'e404_cucciolo', 'horrorverse:lama_quarantena', 'challenge', 'Il Signore della Piaga', 'Hai sconfitto il Signore della Piaga.', 'Lord of the Plague', 'You defeated the Lord of the Plague.'),
 ('e404_clone', 'e404_signore', 'minecraft:player_head', 'task', 'Una copia più umana', 'Hai fatto apparire il Clone Vendicativo.', 'A More Human Copy', 'You summoned the Vengeful Clone.'),
 ('e404_clone_alleato', 'e404_clone', 'minecraft:heart_of_the_sea', 'challenge', 'La vendetta non serve', 'Hai convinto il Clone a smettere di vendicarsi.', 'Vengeance Is Pointless', 'You convinced the Clone to stop.'),
 ('e404_clone_sconfitto', 'e404_clone', 'minecraft:iron_sword', 'goal', 'Il Clone sconfitto', 'Hai sconfitto il Clone Vendicativo.', 'The Clone Defeated', 'You defeated the Vengeful Clone.'),
 ('e404_apocalisse', 'e404_signore', 'horrorverse:statua_destino', 'challenge', 'Fine dell\'Apocalisse Verde', 'Hai fermato l\'Apocalisse Verde.', 'End of the Green Apocalypse', 'You stopped the Green Apocalypse.'),
 ('armatura_antivirus', 'e404_demone', 'horrorverse:elmo_antivirus', 'goal', 'Antivirus completo', 'Indossi l\'armatura Antivirus completa.', 'Full Antivirus', 'You wear the full Antivirus armor.'),
 ('tutte_le_entita', 'radice', 'minecraft:ender_chest', 'goal', 'Il filo della storia', 'Hai incontrato tutte e sei le entità.', 'The Thread of the Story', 'You met all six entities.'),
 ('lettore_diario', 'radice', 'horrorverse:diario_mondo', 'challenge', 'Lettore del Diario', 'Hai sbloccato tutte le pagine del Diario del Mondo.', 'Diary Reader', 'You unlocked every page of the World Diary.'),
 ('jumpscare', 'radice', 'minecraft:skeleton_skull', 'task', 'Te l\'avevo detto', 'Hai preso un bello spavento.', 'I Told You So', 'You got a good scare.'),
 ('fine_storia', 'lettore_diario', 'minecraft:dragon_egg', 'challenge', 'La fine di tutto', 'Osservatore calmato, Steve alleato, Entity 404 sconfitto.', 'The End of Everything', 'Observer calmed, Steve allied, Entity 404 defeated.'),
]
lang_it, lang_en = {}, {}
for (i, p, ic, fr, ti, di, te, de) in ADV:
    d = {"icon": {"id": ic}, "title": {"translate": "advancement.horrorverse.%s.title" % i}, "description": {"translate": "advancement.horrorverse.%s.desc" % i}, "frame": fr, "show_toast": True, "announce_to_chat": True, "hidden": False}
    if p is None: d["background"] = "horrorverse:gui/advancements/backgrounds/horror"; d["announce_to_chat"] = False
    obj = {"display": d, "criteria": {"x": {"trigger": "minecraft:impossible"}}, "requirements": [["x"]]}
    if p: obj["parent"] = "horrorverse:" + p
    wj(D + '/advancement/%s.json' % i, obj)
    lang_it['advancement.horrorverse.%s.title' % i] = ti; lang_it['advancement.horrorverse.%s.desc' % i] = di
    lang_en['advancement.horrorverse.%s.title' % i] = te; lang_en['advancement.horrorverse.%s.desc' % i] = de

# ============================================================ lingue
lang_it['itemGroup.horrorverse'] = 'Horror Universe'; lang_en['itemGroup.horrorverse'] = 'Horror Universe'
for (i, it, en, *_r) in S.ITEMS: lang_it['item.horrorverse.' + i] = it; lang_en['item.horrorverse.' + i] = en
for (i, it, en, *_r) in S.BLOCKS: lang_it['block.horrorverse.' + i] = it; lang_en['block.horrorverse.' + i] = en
for (i, it, en, *_r) in S.EFFECTS: lang_it['effect.horrorverse.' + i] = it; lang_en['effect.horrorverse.' + i] = en
BOSS = {'custode': ('Il Custode dagli Occhi Bianchi', 'The White-Eyed Custodian'), 'corrotto': ('Il Corrotto / Dio dell\'Oscurità', 'The Corrupted / God of Darkness'), 'entity_404': ('Entity 404', 'Entity 404'),
        'uomo_magico': ('L\'Uomo Magico', 'The Magic Man'), 'steve': ('Steve, il Giocatore Impossibile', 'Steve, the Impossible Player'), 'osservatore': ('L\'Osservatore', 'The Observer')}
for k, (a, b) in BOSS.items(): lang_it['entity.horrorverse.' + k] = a; lang_en['entity.horrorverse.' + k] = b
for m in S.MINIONS: lang_it['entity.horrorverse.' + m[0]] = m[1]; lang_en['entity.horrorverse.' + m[0]] = m[2]
wj(A + '/lang/it_it.json', lang_it); wj(A + '/lang/en_us.json', lang_en)
print('generato: %d oggetti, %d blocchi, %d mostri, %d achievement, %d ricette' % (len(S.ITEMS), len(S.BLOCKS), len(S.MINIONS), len(ADV), len(R)))
